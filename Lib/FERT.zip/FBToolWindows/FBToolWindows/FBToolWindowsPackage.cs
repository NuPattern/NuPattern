﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.ComponentModel.Design;
using System.Windows;
using Microsoft.Win32;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.OLE.Interop;
using Microsoft.VisualStudio.Shell;
using System.Windows.Controls;

namespace Microsoft.FeatureExtensionToolWindows
{
    /// <summary>
    /// This is the class that implements the package exposed by this assembly.
    ///
    /// The minimum requirement for a class to be considered a valid package for Visual Studio
    /// is to implement the IVsPackage interface and register itself with the shell.
    /// This package uses the helper classes defined inside the Managed Package Framework (MPF)
    /// to do it: it derives from the Package class that provides the implementation of the 
    /// IVsPackage interface and uses the registration attributes defined in the framework to 
    /// register itself and its components with the shell.
    /// </summary>
    // This attribute tells the PkgDef creation utility (CreatePkgDef.exe) that this class is
    // a package.
    [PackageRegistration(UseManagedResourcesOnly = true)]
    // This attribute is used to register the informations needed to show the this package
    // in the Help/About dialog of Visual Studio.
    [InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
    // This attribute is needed to let the shell know that this package exposes some menus.
    [ProvideMenuResource("Menus.ctmenu", 1)]
    // This attribute registers a tool window exposed by this package.
    [ProvideToolWindow(typeof(FeatureBuilderWorkflowWindow))]
    [ProvideToolWindow(typeof(FeatureBuilderBrowserWindow))]
    [Guid(GuidList.guidFeatureBuilderToolWindowsPkgString)]
    [ProvideAutoLoad(UIContextGuids.NoSolution)]
    [ProvideLoadKey("Standard", "1.0", "FBXTestFX", "Microsoft Corporation", 104)]

    public sealed class FeatureBuilderToolWindowsPackage : Package, IGuidanceWindowsService2
    {
        /// <summary>
        /// Default constructor of the package.
        /// Inside this method you can place any initialization code that does not require 
        /// any Visual Studio service because at this point the package object is created but 
        /// not sited yet inside Visual Studio environment. The place to do all the other 
        /// initialization is the Initialize method.
        /// </summary>
        public FeatureBuilderToolWindowsPackage()
        {
            Trace.WriteLine(string.Format(CultureInfo.CurrentCulture, "Entering constructor for: {0}", this.ToString()));
        }

        public ToolWindowPane ShowGuidanceExplorer(UserControl rootControl, object dataContext, object workflowMediator)
        {
            if (dataContext != null)
            FeatureBuilderWorkflowWindow.DataContextPreload = dataContext;

            ToolWindowPane window = this.FindToolWindow(typeof(FeatureBuilderWorkflowWindow), 0, true);
            if ((null == window) || (null == window.Frame))
            {
                throw new NotSupportedException(Resources.CanNotCreateWindow);
            }

            if (rootControl != null)
            {
                IGuidanceToolWindow gtw = window as IGuidanceToolWindow;

                ((Grid)gtw.RootControl.Content).Children.Add((UIElement)rootControl);
                gtw.DataContext = dataContext;
                ((FeatureBuilderWorkflowWindow) window).WorkflowMediator = workflowMediator;
            }


            var windowFrame = window.Frame as IVsWindowFrame;
            ErrorHandler.ThrowOnFailure(windowFrame.Show());
            return window;
        }

        public ToolWindowPane ShowGuidanceBrowser(UserControl rootControl, object dataContext)
        {
            if (dataContext != null)
                FeatureBuilderBrowserWindow.DataContextPreload = dataContext;

            ToolWindowPane window = this.FindToolWindow(typeof(FeatureBuilderBrowserWindow), 0, true);
            if ((null == window) || (null == window.Frame))
            {
                throw new NotSupportedException(Resources.CanNotCreateWindow);
            }

            object windowContentContent = ((UserControl) window.Content).Content;

            if (rootControl != null)
            {
                IGuidanceToolWindow gtw = window as IGuidanceToolWindow;

                ((Grid)gtw.RootControl.Content).Children.Add((UIElement)rootControl);
                gtw.DataContext = dataContext;
            }

            var windowFrame = (IVsWindowFrame)window.Frame;
            ErrorHandler.ThrowOnFailure(windowFrame.Show());
            return window;
        }
 
        /// <summary>
        /// This function is called when the user clicks the menu item that shows the 
        /// tool window. See the Initialize method to see how the menu item is associated to 
        /// this function using the OleMenuCommandService service and the MenuCommand class.
        /// </summary>
        private void ShowGuidanceWorkflowWindow(object sender, EventArgs e)
        {
            // Get the instance number 0 of this tool window. This window is single instance so this instance
            // is actually the only one.
            // The last flag is set to true so that if the tool window does not exists it will be created.
            ToolWindowPane window = this.FindToolWindow(typeof(FeatureBuilderWorkflowWindow), 0, true);
            if ((null == window) || (null == window.Frame))
            {
                throw new NotSupportedException(Resources.CanNotCreateWindow);
            }
            var windowFrame = (IVsWindowFrame)window.Frame;
            ErrorHandler.ThrowOnFailure(windowFrame.Show());
        }


        /// <summary>
        /// This function is called when the user clicks the menu item that shows the 
        /// tool window. See the Initialize method to see how the menu item is associated to 
        /// this function using the OleMenuCommandService service and the MenuCommand class.
        /// </summary>
        private void ShowGuidanceBrowserWindow(object sender, EventArgs e)
        {
            // Get the instance number 0 of this tool window. This window is single instance so this instance
            // is actually the only one.
            // The last flag is set to true so that if the tool window does not exists it will be created.
            ToolWindowPane window = this.FindToolWindow(typeof(FeatureBuilderBrowserWindow), 0, true);
            if ((null == window) || (null == window.Frame))
            {
                throw new NotSupportedException(Resources.CanNotCreateWindow);
            }
            var windowFrame = (IVsWindowFrame)window.Frame;
            Microsoft.VisualStudio.ErrorHandler.ThrowOnFailure(windowFrame.Show());
        }

        public IGuidanceToolWindow GetGuidanceExplorer()
        {
            return ShowGuidanceExplorer(null, null, null) as IGuidanceToolWindow;
        }

        public IGuidanceToolWindow GetGuidanceBrowser()
        {
            return ShowGuidanceBrowser(null, null) as IGuidanceToolWindow;
        }

        
        /////////////////////////////////////////////////////////////////////////////
        // Overriden Package Implementation
        #region Package Members

        /// <summary>
        /// Initialization of the package; this method is called right after the package is sited, so this is the place
        /// where you can put all the initilaization code that rely on services provided by VisualStudio.
        /// </summary>
        protected override void Initialize()
        {
            Trace.WriteLine (string.Format(CultureInfo.CurrentCulture, "Entering Initialize() of: {0}", this.ToString()));
            base.Initialize();

            var serviceContainer = (IServiceContainer)this;
            serviceContainer.AddService(typeof(IGuidanceWindowsService2), this, true);

            // Add our command handlers for menu (commands must exist in the .vsct file)
            OleMenuCommandService mcs = GetService(typeof(IMenuCommandService)) as OleMenuCommandService;
            if ( null != mcs )
            {
                // Create the command for the tool window
                CommandID toolwndCommandID = new CommandID(GuidList.guidFeatureBuilderToolWindowsCmdSet, (int)PkgCmdIDList.cmdidFBGWE);
                MenuCommand menuToolWin = new MenuCommand(ShowGuidanceWorkflowWindow, toolwndCommandID);
                mcs.AddCommand(menuToolWin);

                // Create the command for the tool window
                CommandID toolwndCommandID2 = new CommandID(GuidList.guidFeatureBuilderToolWindowsCmdSet2, (int)PkgCmdIDList.cmdidFBGWB);
                MenuCommand menuToolWin2 = new MenuCommand(ShowGuidanceBrowserWindow, toolwndCommandID2);
                mcs.AddCommand(menuToolWin2);
            }
        }
        #endregion



    }
 
}
