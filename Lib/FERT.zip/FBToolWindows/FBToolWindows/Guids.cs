﻿// Guids.cs
// MUST match guids.h
using System;

namespace Microsoft.FeatureExtensionToolWindows
{
    static class GuidList
    {
        public const string guidFeatureBuilderToolWindowsPkgString = "3F231B90-7C08-4AA1-BA47-BA0F246263C4";

        public const string guidFeatureBuilderToolWindowsCmdSetString = "379f1c58-0ea8-4604-af8f-92e8ae377067";
        public const string guidFeatureBuilderToolWindowsCmdSetString2 = "B7DEC948-BB79-4421-B047-2A93989C7268";

        public const string guidToolWindowPersistanceString = "167f0a44-f79b-4007-a084-8ecc1457776e";
        public const string guidToolWindowPersistanceString2 = "6A2D1053-BEEB-4FDF-9FB0-133CE1FE6D25";

        public static readonly Guid guidFeatureBuilderToolWindowsCmdSet = new Guid(guidFeatureBuilderToolWindowsCmdSetString);
        public static readonly Guid guidFeatureBuilderToolWindowsCmdSet2 = new Guid(guidFeatureBuilderToolWindowsCmdSetString2);
    };
}