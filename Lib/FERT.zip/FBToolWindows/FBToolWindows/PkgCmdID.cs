﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Microsoft.FeatureExtensionToolWindows
{
    static class PkgCmdIDList
    {

        public const uint cmdidFBGWE = 0x101;
        public const uint cmdidFBGWB = 0x102;


    };
}