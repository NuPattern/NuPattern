﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.FeatureExtensionToolWindows
{
    public interface IGuidanceToolWindow
    {
        object DataContext { get; set; }
        UserControl RootControl { get; }
        ToolWindowPane WindowPane { get; }
    }

    public interface IGuidanceWindowsService2
    {
        ToolWindowPane ShowGuidanceExplorer(UserControl rootControl, object dataContext, object workflowMediator);
        ToolWindowPane ShowGuidanceBrowser(UserControl rootControl, object dataContext);

        IGuidanceToolWindow GetGuidanceExplorer();
        IGuidanceToolWindow GetGuidanceBrowser();
    }

}
