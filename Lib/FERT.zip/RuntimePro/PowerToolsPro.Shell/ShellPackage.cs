﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using EnvDTE;
using Microsoft.VisualStudio.ComponentModelHost;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;
using IVsSingleFileGenerator = Microsoft.VisualStudio.Shell.Interop.IVsSingleFileGenerator;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Shell
{	
    [PackageRegistration(UseManagedResourcesOnly = true)]
    [InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
    [Guid(GuidList.guidPowerTools_ShellPkgString)]
    [ComVisible(true)]
    [ProvideAutoLoad(UIContextGuids.NoSolution)]
    [ProvideService(typeof(IFxrModelingService), ServiceName = "ModelingService")]
    [ProvideService(typeof(IFxrTemplateService), ServiceName = "TemplateService")]
    [ProvideService(typeof(IFxrUriReferenceService), ServiceName = "UriReferenceService")]
    [ProvideService(typeof(ISolution), ServiceName = "Solution")]

    public sealed partial class ShellPackage : Package
    {
        public ShellPackage()
        {
        }

#pragma warning disable 0649
        // Fields are set by MEF
        [Import]
        private IFxrTemplateService templateService;
        [Import]
        private IFxrModelingService modelingService;
        [Import]
        private IFxrUriReferenceService uriReferenceService;
        [Import]
        private ISolution solution;
        [Import(typeof(SVsServiceProvider))]
        private System.IServiceProvider serviceProvider;
#pragma warning restore 0649

        public IFxrTemplateService TemplateService
        {
            get { return SatisfyAndReturn(() => templateService); }
        }

        public IFxrModelingService ModelingService
        {
            get { return SatisfyAndReturn(() => modelingService); }
        }

        public IFxrUriReferenceService UriReferenceService
        {
            get { return SatisfyAndReturn(() => uriReferenceService); }
        }
     
        public ISolution Solution
        {
            get { return SatisfyAndReturn(() => solution); }
        }

        //protected override void Dispose(bool disposing)
        //{
        //    base.Dispose(disposing);
        //}

        // Initialize is not guaranteed to be called by MEF. In my tests
        // it's never called unless someone requests one of the provided 
        // services via IServiceProvider. In MEF cases, class just 
        // gets constructed but never initialized.
        protected override void Initialize()
        {
            base.Initialize();

            this.PublishImportsAsServices();

            VsHelper.Initialize(this.serviceProvider);
        }
        
        private T SatisfyAndReturn<T>(Func<T> getter)
            where T : class
        {
            if (getter() == null)
                SatisfyImports();

            return getter();
        }

        private void SatisfyImports()
        {
            var componentModel = (IComponentModel)GetService(typeof(SComponentModel));
            Debug.Assert(componentModel != null, "Could not locate IComponentModel");
            try
            {
                componentModel.DefaultCompositionService.SatisfyImportsOnce(this);
            }
            catch (Exception e)
            {
                throw new Exception("Compostion error: " + e.Message);
            }
        }

        private void PublishImportsAsServices()
        {
            var container = this as IServiceContainer;

            // Make available via IServiceProvider
            container.AddService(typeof(IFxrModelingService), new ServiceCreatorCallback((c, s) => this.ModelingService), true);
            container.AddService(typeof(IFxrTemplateService), new ServiceCreatorCallback((c, s) => this.TemplateService), true);
            container.AddService(typeof(IFxrUriReferenceService), new ServiceCreatorCallback((c, s) => this.UriReferenceService), true);
            container.AddService(typeof(ISolution), new ServiceCreatorCallback((c, s) => this.Solution), true);
        }
   }
}