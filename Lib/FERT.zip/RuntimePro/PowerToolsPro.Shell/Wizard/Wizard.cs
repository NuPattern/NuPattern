﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Shell.Wizard
{
    /// <summary>
    /// Represents a Wizard
    /// </summary>
    public class Wizard
    {
        private Shell shell;
        private List<Control> pages = new List<Control>();
        private string title = string.Empty;

        /// <summary>
        /// Iniatilizes a new instance of <see cref="Wizard"/>
        /// </summary>
        public Wizard()
        {
            shell = new Shell(this);
        }

        /// <summary>
        /// Gets or sets the title of the Wizard
        /// </summary>
        public string Title
        {
            get { return this.title; }
            set { title = value; }
        }

        public T GetModel<T>(Control page)
        {
            return (T)page.DataContext;
        }

        /// <summary>
        /// Gets the window used by the wizard
        /// </summary>
        public Window Window
        {
            get { return this.shell; }
        }

        private void UpdateTitleToIncludePageNumber()
        {
            if (!string.IsNullOrEmpty(this.title))
            {
                this.shell.Title = this.Title;
            }
        }

        /// <summary>
        /// Returns the first page that matches the T type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public T GetPage<T>()
            where T : Control
        {
            Control page = this.pages.FirstOrDefault(p => p.GetType() == typeof(T));
            return page != null ? (T)page : default(T);
        }

        /// <summary>
        /// Adds a page to the Wizard
        /// </summary>
        /// <param name="page"></param>
        public void AddPage(Control page)
        {
            if (page != null)
            {
                this.pages.Add(page);
            }
        }

        /// <summary>
        /// Shows the wizard
        /// </summary>
        /// <returns>True if the wizard was finished or false if the wizard was cancelled</returns>
        public bool Show()
        {
            if (pages.Count == 0)
            {
                throw new InvalidOperationException("The wizard cannot be shown because it does not contain any pages.");
            }

            SetActivePage(pages.First());

            bool? result = shell.ShowDialog();

            return result.HasValue ? result.Value : false;
        }

        private void SetActivePage(Control page)
        {
            shell.ActivePage = page;
            this.IsNextEnabled = GetNextPage() != null;
            this.IsPreviousEnabled = GetPreviousPage() != null;
            UpdateTitleToIncludePageNumber();
        }

        /// <summary>
        /// Gets the pages of the wizard
        /// </summary>
        public IEnumerable<Control> Pages
        {
            get { return this.pages.AsReadOnly(); }
        }

        /// <summary>
        /// Navigates to the next page of the wizard
        /// </summary>
        internal void Next()
        {
            SetActivePage(GetNextPage());
        }

        /// <summary>
        /// Navigates to the previous page of the wizard
        /// </summary>
        internal void Previous()
        {
            SetActivePage(GetPreviousPage());
        }

        private Control GetPage(int pageNumber)
        {
            if (pageNumber < this.pages.Count && pageNumber >= 0)
            {
                return pages[pageNumber];
            }

            return null;
        }

        private Control GetNextPage()
        {
            return GetPage(this.pages.IndexOf(this.shell.ActivePage) + 1);
        }

        private Control GetPreviousPage()
        {
            return GetPage(this.pages.IndexOf(this.shell.ActivePage) - 1);
        }

        /// <summary>
        /// Finishes the wizard successfully
        /// </summary>
        internal void Finish()
        {
            Close(true);
        }

        /// <summary>
        /// Cancels the wizard
        /// </summary>
        internal void Cancel()
        {
            Close(false);
        }

        private void Close(bool result)
        {
            this.shell.DialogResult = result;
            this.shell.Close();
        }

        #region IWizardService Members

        /// <summary>
        /// See <see cref="IWizardService.IsNextEnabled"/>
        /// </summary>
        public bool IsNextEnabled
        {
            get { return this.shell.IsNextEnabled; }
            set { this.shell.IsNextEnabled = value && GetNextPage() != null; }
        }

        /// <summary>
        /// See <see cref="IWizardService.IsPreviousEnabled"/>
        /// </summary>
        public bool IsPreviousEnabled
        {
            get { return this.shell.IsPreviousEnabled; }
            set { this.shell.IsPreviousEnabled = value && GetPreviousPage() != null; }
        }

        /// <summary>
        /// See <see cref="IWizardService.IsFinishEnabled"/>
        /// </summary>
        public bool IsFinishEnabled
        {
            get { return this.shell.IsFinishEnabled; }
            set { this.shell.IsFinishEnabled = value; }
        }

        /// <summary>
        /// See <see cref="IWizardService.IsCancelEnabled"/>
        /// </summary>
        public bool IsCancelEnabled
        {
            get { return this.shell.IsCancelEnabled; }
            set { this.shell.IsCancelEnabled = value; }
        }

        /// <summary>
        /// See <see cref="IWizardService.ActivePage"/>
        /// </summary>
        public Control ActivePage
        {
            get { return this.shell.ActivePage; }
        }

        #endregion
    }
}