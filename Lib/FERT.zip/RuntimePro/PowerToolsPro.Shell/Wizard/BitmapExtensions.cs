﻿using System;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Shell.Wizard
{
    internal static class BitmapExtensions
    {
        internal static ImageSource GetImageSource(this System.Drawing.Bitmap source)
        {
            return GetImageSource(source, null);
        }
           
        internal static ImageSource GetImageSource(this System.Drawing.Bitmap source , System.Drawing.Color? transparentColor)
        {
            if (transparentColor.HasValue)
            {
                source.MakeTransparent(transparentColor.Value);
            }

            // converts the bitmap to image source
            return Imaging.CreateBitmapSourceFromHBitmap(
                source.GetHbitmap(),
                IntPtr.Zero,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());
        }
    }
}
