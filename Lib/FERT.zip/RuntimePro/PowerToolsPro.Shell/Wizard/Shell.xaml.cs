﻿using System.Windows;
using System.Windows.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Shell.Wizard
{
    /// <summary>
    /// Interaction logic for Shell.xaml
    /// </summary>
    internal partial class Shell : Window
    {
        private Wizard wizard;

        internal Shell(Wizard wizard)
        {
            InitializeComponent();

            this.wizard = wizard;
            this.DataContext = this;
        }

        internal bool IsNextEnabled
        {
            get { return (bool)GetValue(IsNextEnabledProperty); }
            set { SetValue(IsNextEnabledProperty, value); }
        }

        internal static readonly DependencyProperty IsNextEnabledProperty =
            DependencyProperty.Register("IsNextEnabled", typeof(bool), typeof(Shell), new UIPropertyMetadata(true));

        internal bool IsPreviousEnabled
        {
            get { return (bool)GetValue(IsPreviousEnabledProperty); }
            set { SetValue(IsPreviousEnabledProperty, value); }
        }

        internal static readonly DependencyProperty IsPreviousEnabledProperty =
            DependencyProperty.Register("IsPreviousEnabled", typeof(bool), typeof(Shell), new UIPropertyMetadata(true));

        internal bool IsFinishEnabled
        {
            get { return (bool)GetValue(IsFinishEnabledProperty); }
            set { SetValue(IsFinishEnabledProperty, value); }
        }

        internal static readonly DependencyProperty IsFinishEnabledProperty =
            DependencyProperty.Register("IsFinishEnabled", typeof(bool), typeof(Shell), new UIPropertyMetadata(true));

        internal bool IsCancelEnabled
        {
            get { return (bool)GetValue(IsCancelEnabledProperty); }
            set { SetValue(IsCancelEnabledProperty, value); }
        }

        internal static readonly DependencyProperty IsCancelEnabledProperty =
            DependencyProperty.Register("IsCancelEnabled", typeof(bool), typeof(Shell), new UIPropertyMetadata(true));

        internal Control ActivePage
        {
            get { return (Control)GetValue(ActivePageProperty); }
            set { SetValue(ActivePageProperty, value); }
        }

        internal static readonly DependencyProperty ActivePageProperty =
            DependencyProperty.Register("ActivePage", typeof(Control), typeof(Shell), new UIPropertyMetadata(null, new PropertyChangedCallback(OnActivePagePropertyChanged)));

        internal FrameworkElement ActivePageView
        {
            get { return (FrameworkElement)GetValue(ActivePageViewProperty); }
            set { SetValue(ActivePageViewProperty, value); }
        }

        private static void OnActivePagePropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Shell shell = d as Shell;
            Control wizardPage = e.NewValue as Control;

            if (wizardPage != null)
            {
                    shell.ActivePageView = wizardPage;
            }
        }

        internal static readonly DependencyProperty ActivePageViewProperty =
            DependencyProperty.Register("ActivePageView", typeof(FrameworkElement), typeof(Shell), new UIPropertyMetadata(null, new PropertyChangedCallback(OnActivePageViewPropertyChanged)));

        internal static void OnActivePageViewPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
        }

        private void OnPreviousButtonClick(object sender, RoutedEventArgs e)
        {
            this.wizard.Previous();
        }

        private void OnNextButtonClick(object sender, RoutedEventArgs e)
        {
            this.wizard.Next();
        }

        private void OnFinishButtonClick(object sender, RoutedEventArgs e)
        {
            this.wizard.Finish();
        }

        private void OnCancelButtonClick(object sender, RoutedEventArgs e)
        {
            this.wizard.Cancel();
        }
    }
}