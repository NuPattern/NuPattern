﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.ExtensibilityHosting;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;

[assembly: AssemblyTitle("Feature Extension Runtime Pro")]
[assembly: AssemblyProduct("Feature Extension Runtime Pro")]

[assembly: ComVisible(false)]     
[assembly: CLSCompliant(false)]
[assembly: NeutralResourcesLanguage("en-US")]

