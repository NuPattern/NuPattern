using System;
using System.IO;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Shell
{
	/// <summary />
	[AttributeUsage(AttributeTargets.Class, AllowMultiple = true)]
	public class PropertyProcessorAttribute : RegistrationAttribute
	{
		private const string PropertyProcessorRegistryKeyPath = @"TextTemplating\DirectiveProcessors";

		/// <summary />
		public string Name { get; set; }

		/// <summary />
		public string Description { get; set; }

		/// <summary />
		public string Class { get; set; }

		/// <summary />
		public string Assembly { get; set; }

		/// <summary />
		public override void Register(RegistrationAttribute.RegistrationContext context)
		{
			using (Key regKey = context.CreateKey(Path.Combine(PropertyProcessorRegistryKeyPath, this.Name)))
			{
				regKey.SetValue(string.Empty, this.Description);
				regKey.SetValue("Class", this.Class);
				regKey.SetValue("Assembly", this.Assembly);
			}
		}

		/// <summary />
		public override void Unregister(RegistrationAttribute.RegistrationContext context)
		{
		}
	}
}