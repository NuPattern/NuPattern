// This file is used by Code Analysis to maintain SuppressMessage
// attributes that are applied to this project. Project-level
// suppressions either have no target or are given a specific target
// and scoped to a namespace, type, member, etc.
//
// To add a suppression to this file, right-click the message in the
// Error List, point to "Suppress Message(s)", and click "In Project
// Suppression File". You do not need to add suppressions to this
// file manually.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1017:MarkAssembliesWithComVisible")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.GraphTransactionEnlistment.#System.Transactions.IEnlistmentNotification.Commit(System.Transactions.Enlistment)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.GraphTransactionEnlistment.#System.Transactions.IEnlistmentNotification.Prepare(System.Transactions.PreparingEnlistment)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.GraphTransactionEnlistment.#System.Transactions.IEnlistmentNotification.Rollback(System.Transactions.Enlistment)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.GraphTransactionEnlistment.#System.Transactions.IEnlistmentNotification.InDoubt(System.Transactions.Enlistment)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.Layer.PropertyExtension`1.#Microsoft.VisualStudio.ArchitectureTools.Extensibility.Layer.IPropertyExtension.GetPropertyDescriptor()")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.QualifiedIdentifierCollection.#System.Collections.Generic.IEnumerable`1<Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.QualifiedIdentifier>.GetEnumerator()")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.QualifiedIdentifierCollection.#System.Collections.IEnumerable.GetEnumerator()")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.Layer.PropertyExtension`1.#Microsoft.VisualStudio.ArchitectureTools.Extensibility.Layer.IPropertyExtension.GetPropertyDescriptor()")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.QualifiedIdentifierCollection.#System.Collections.Generic.IEnumerable`1<Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.QualifiedIdentifier>.GetEnumerator()")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1033:InterfaceMethodsShouldBeCallableByChildTypes", Scope = "member", Target = "Microsoft.VisualStudio.ArchitectureTools.Extensibility.GraphModel.QualifiedIdentifierCollection.#System.Collections.IEnumerable.GetEnumerator()")]
