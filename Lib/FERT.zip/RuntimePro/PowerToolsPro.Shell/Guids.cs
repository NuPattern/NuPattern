﻿// Guids.cs
// MUST match guids.h
using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Shell
{
	internal static class GuidList
	{
        public const string guidPowerTools_ShellPkgString = "6262D4F6-F6C6-4BE8-85AD-9BC969DF76B0";

		
    
	};
}