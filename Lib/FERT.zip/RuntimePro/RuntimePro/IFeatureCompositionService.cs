﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;
using System.ComponentModel.Composition;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Main interface that allows features to create additional components 
	/// it may need for its operation, that integrate seamlessly with 
	/// the composition infrastructure of the feature extensions runtime and 
	/// Visual Studio.
	/// </summary>
	public interface IFeatureCompositionService : ICompositionService, IDisposable
	{
		// MEF wrappers
		
		void ComposeParts(params object[] attributedParts);

		
		Lazy<T> GetExport<T>();
		Lazy<T> GetExport<T>(string contractName);
		
		Lazy<T, TMetadataView> GetExport<T, TMetadataView>();
		Lazy<T, TMetadataView> GetExport<T, TMetadataView>(string contractName);
		
		T GetExportedValue<T>();
		T GetExportedValue<T>(string contractName);
		
		T GetExportedValueOrDefault<T>();
		T GetExportedValueOrDefault<T>(string contractName);
		
		IEnumerable<T> GetExportedValues<T>();
		IEnumerable<T> GetExportedValues<T>(string contractName);
		
		IEnumerable<Lazy<T>> GetExports<T>();
		IEnumerable<Lazy<T>> GetExports<T>(string contractName);
		
		IEnumerable<Lazy<T, TMetadataView>> GetExports<T, TMetadataView>();
		IEnumerable<Lazy<T, TMetadataView>> GetExports<T, TMetadataView>(string contractName);
	}
}
