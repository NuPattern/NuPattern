﻿using System;
using System.Runtime.Remoting.Messaging;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	internal abstract class InstantiationScope<T> : IDisposable
	{
		private readonly static string TlsKey = typeof(T).FullName;
		private bool contextSet;

		public InstantiationScope()
		{
			if (!IsActive)
			{
				CallContext.LogicalSetData(TlsKey, new object());
				contextSet = true;
			}
		}

		public static bool IsActive
		{
			get { return CallContext.LogicalGetData(TlsKey) != null; }
		}

		public void Dispose()
		{
			if (this.contextSet)
			{
				CallContext.LogicalSetData(TlsKey, null);
			}
		}
	}

	/// <summary>
	/// This scope is only active when the default project that unfolds a feature is being 
	/// instantiated via IFeatureManager API.
	/// </summary>
	internal class DefaultTemplateInstantiationScope : InstantiationScope<DefaultTemplateInstantiationScope>
	{
	}

	/// <summary>
	/// This scope is only active when the modeling project that represents a feature is being 
	/// instantiated via IFeatureManager API.
	/// </summary>
	internal class FeatureInstantiationScope : InstantiationScope<FeatureInstantiationScope>
	{
	}

	/// <summary>
	/// This scope is only active when the modeling project that represents a feature is being 
	/// instantiated via IFeatureManager API. The modeling feature instantiation code 
	/// </summary>
	internal class ModelingFeatureInstantiationScope : InstantiationScope<ModelingFeatureInstantiationScope>
	{
	}
}