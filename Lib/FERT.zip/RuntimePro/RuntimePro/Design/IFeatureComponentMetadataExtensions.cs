﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Design
{
	public static class IFeatureComponentMetadataExtensions
	{
		public static StandardValue AsStandardValue(this IFeatureComponentMetadata metadata)
		{
			return new FeatureStandardValue(
				string.IsNullOrEmpty(metadata.DisplayName) ? metadata.Id : metadata.DisplayName,
				metadata.Id,
				metadata.ExportingType,
				metadata.Description,
				metadata.Category);
		}
	}
}
