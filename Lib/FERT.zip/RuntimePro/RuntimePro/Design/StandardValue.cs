﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Design
{
	public class StandardValue
	{
		public const string DefaultGroupName = "General";

		public StandardValue(string displayText, object value, string description = "", string group = "")
		{
			this.DisplayText = displayText;
			this.Value = value;
			this.Description = string.IsNullOrEmpty(description) ? displayText : description;
			this.Group = group;

			if (string.IsNullOrEmpty(this.Group))
			{
				this.Group = DefaultGroupName; // Use the default group name
			}
		}

		public string Description { get; set; }
		public string DisplayText { get; set; }
		public object Value { get; set; }
		public string Group { get; set; }
	}
}