﻿using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Globalization;
using System.Windows.Forms.Design;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Design
{
	public class StandardValuesEditor : UITypeEditor
	{
		public override bool IsDropDownResizable
		{
			get { return true; }
		}

		public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value)
		{
			var converter = context.PropertyDescriptor.Converter;

			if (!converter.GetStandardValuesSupported(context))
			{
				throw new InvalidOperationException("The converter does not support standard values");
			}

			var windowsFormsService = provider.GetService(typeof(IWindowsFormsEditorService)) as IWindowsFormsEditorService;
			var editorControl = new StandardValuesDropDown(windowsFormsService, converter.GetStandardValues(context));

			// If the user press "Esc" we should return the original value            
			// The result variable should be updated with the result of the drop down operation
			var result = true;
			windowsFormsService.DropDownControl(editorControl);

			if (result)
			{
				var selectedValue = editorControl.SelectedValue;

				if (selectedValue != null &&
					selectedValue.GetType() != context.PropertyDescriptor.PropertyType &&
					converter.CanConvertFrom(context, selectedValue.GetType()))
				{
					selectedValue = converter.ConvertFrom(context, CultureInfo.CurrentCulture, selectedValue);
				}

				return selectedValue ?? value;
			}

			return value;
		}

		public override UITypeEditorEditStyle GetEditStyle(System.ComponentModel.ITypeDescriptorContext context)
		{
			return UITypeEditorEditStyle.DropDown;
		}
	}
}