﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Design
{
	/// <summary>
	/// Attribute to apply to editors that must be used in the 
	/// design solution itself, rather than only through library/MEF.
	/// </summary>
	public class DesignEditorAttribute : Attribute
	{
		public DesignEditorAttribute(Type editorType, Type baseType)
		{
			if (!baseType.IsAssignableFrom(editorType))
				throw new ArgumentException(string.Format(
					CultureInfo.CurrentCulture,
					"Editor type {0} is not derived from the given base type {1}.",
					editorType, baseType));

			this.EditorType = editorType;
			this.BaseType = baseType;
		}

		public Type EditorType { get; private set; }
		public Type BaseType { get; private set; }
	}
}
