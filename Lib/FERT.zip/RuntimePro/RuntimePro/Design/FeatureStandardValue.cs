﻿using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Design
{
	public class FeatureStandardValue : StandardValue
	{
		public FeatureStandardValue(string displayText, object value, Type exportingType, string description = "", string group = "")
			: base(displayText, value, description, group)
		{
			this.ExportingType = exportingType;
		}

		public Type ExportingType { get; private set; }
	}
}