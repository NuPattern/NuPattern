﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Design
{
	/// <summary>
	/// Attribute to apply to converters that must be used in the 
	/// design solution itself, rather than only through library/MEF.
	/// </summary>
	public class DesignTypeConverterAttribute : Attribute
	{
		public DesignTypeConverterAttribute(Type converterType)
		{
			this.ConverterType = converterType;
		}

		public Type ConverterType { get; private set; }
	}
}
