﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class CommandBinding : Binding<IFeatureCommand>
	{
		public CommandBinding(
			IFeatureCompositionService featureComposition,
			string componentTypeId,
			params PropertyBinding[] propertyBindings)
			: base(featureComposition, componentTypeId, propertyBindings)
		{
		}

		public string Name { get; set; }
	}
}