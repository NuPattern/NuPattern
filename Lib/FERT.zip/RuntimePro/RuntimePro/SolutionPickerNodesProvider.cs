﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker;
using System.ComponentModel.Composition;

using System.IO;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;
using System.Drawing;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	[Export(typeof(ISolutionPickerNodesProvider))]
	internal class SolutionPickerNodesProvider : ISolutionPickerNodesProvider
	{
		[Import]
		public IFeatureManager FeatureManager { get; set; }

		[Import]
		public Func<IFeatureRegistration, IFeatureExtension> FeatureFactory;

		public IEnumerable<IHierarchyNode> GetNodes(SolutionPickerFilter filter)
		{
			var featuresNode = new SolutionPickerNode { Name = "Features" };
			featuresNode.SetIconFromBitmap(Resources.Feature);
			featuresNode.Add(GetInstalledFeatureNodes(filter));
			featuresNode.Add(GetInstantiatedFeatureNodes(filter));

			return new IHierarchyNode[] { featuresNode };
		}

		private IHierarchyNode GetInstalledFeatureNodes(SolutionPickerFilter filter)
		{
			var installedFeaturesNode = new SolutionPickerNode { Name = "Installed" };
			installedFeaturesNode.SetIconFromBitmap(Resources.Feature);

			foreach (var featureRegistration in this.FeatureManager.InstalledFeatures)
			{
				var feature = this.FeatureFactory(featureRegistration);

				installedFeaturesNode.Add(GetFeatureNode(filter, feature, featureRegistration.FeatureId));
			}

			return installedFeaturesNode;
		}

		private IHierarchyNode GetInstantiatedFeatureNodes(SolutionPickerFilter filter)
		{
			var instantiatedFeaturesNode = new SolutionPickerNode { Name = "Instantiated" };
			instantiatedFeaturesNode.SetIconFromBitmap(Resources.Feature);

			foreach (var feature in this.FeatureManager.InstantiatedFeatures)
			{
				instantiatedFeaturesNode.Add(GetFeatureNode(filter, feature, feature.FeatureId));
			}

			return instantiatedFeaturesNode;
		}

		private IHierarchyNode GetFeatureNode(SolutionPickerFilter filter, IFeatureExtension feature, string featureName)
		{
			var featureNode = new SolutionPickerNode { Name = featureName };
			featureNode.SetIconFromBitmap(Resources.Feature);

			// Check if we should include t4 templates
			if ((filter.Kind | ItemKind.Item) == filter.Kind &&
				(filter.ApplyFileExtension(".t4") || filter.ApplyFileExtension(".tt")))
			{
				// Search t4 templates in all feature assembly path directories
				var featurePath = Path.GetDirectoryName(feature.GetType().Assembly.Location);
				var templateFiles = new List<string>();
				templateFiles.AddRange(Directory.GetFiles(featurePath, "*.t4", SearchOption.AllDirectories));
				templateFiles.AddRange(Directory.GetFiles(featurePath, "*.tt", SearchOption.AllDirectories));

				foreach (var templateFile in templateFiles)
				{
					var parentPathNode = featureNode;

					// Build the path from the feature path to the template path
					for (var path = new DirectoryInfo(Path.GetDirectoryName(templateFile).Replace(featurePath, string.Empty));
						path != null && path.Name != path.Root.Name;
						path = path.Parent)
					{
						var pathNode = parentPathNode.Children.FirstOrDefault(node => node.Name == path.Name) as SolutionPickerNode;
						if (pathNode == null)
						{
							pathNode = new SolutionPickerNode { Name = path.Name };
							pathNode.SetIconFromBitmap(Resources.Folder);
							parentPathNode.Add(pathNode);
						}

						parentPathNode = pathNode;
					}

					// Add the template node
					var templateNode = new SolutionPickerNode
					{
						Name = Path.GetFileName(templateFile),
						SolutionRelativeName = templateFile.Replace(Environment.ExpandEnvironmentVariables("%LocalAppData%"), "%LocalAppData%")
					};
					templateNode.SetIconFromBitmap(Resources.Template);
					parentPathNode.Add(templateNode);
				}
			}

			return featureNode;
		}
	}
}
