﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Provides visual studio known launch point locations
	/// </summary>
	public interface IVsLaunchPointLocationProvider
	{
		IEnumerable<VsLaunchPointLocation> GetKnownLocations();
	}
}
