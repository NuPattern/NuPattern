﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Represents the persisted information about features 
	/// instantiated in a solution.
	/// </summary>
	public class SolutionFeatureState
	{
		public string FeatureId { get; set; }
		public string InstanceName { get; set; }
		/// <summary>
		/// Version of the persisted feature.
		/// </summary>
		public Version Version { get; set; }
	}
}
