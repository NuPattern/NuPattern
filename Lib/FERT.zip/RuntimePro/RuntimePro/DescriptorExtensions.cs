﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public static class DescriptorExtensions
	{
		public static bool IsBindableProperty(this PropertyDescriptor descriptor)
		{
			var browsable = descriptor.Attributes.OfType<BrowsableAttribute>().FirstOrDefault();
			return (browsable == null || browsable.Browsable) &&
				!descriptor.Attributes.OfType<ImportAttribute>().Any() &&
				!descriptor.Attributes.OfType<ImportManyAttribute>().Any();
		}

		public static bool IsBrowsable(this Type type)
		{
			var browsable = type.GetCustomAttribute<BrowsableAttribute>();
			return browsable == null || browsable.Browsable;
		}
	}
}