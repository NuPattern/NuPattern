﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.ExtensibilityHosting;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;

[assembly: AssemblyTitle("Feature Extensions Runtime")]
[assembly: AssemblyProduct("Feature Extensions Runtime")]

[assembly: ComVisible(false)]
[assembly: Guid("e160267a-e8e0-4293-86ab-6afcbf007ea2")]

[assembly: VsCatalogName(Constants.CatalogName)]
[assembly: VsCatalogName("Microsoft.VisualStudio.Default")]