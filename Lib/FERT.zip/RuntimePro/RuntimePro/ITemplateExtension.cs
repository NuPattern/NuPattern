﻿using Microsoft.VisualStudio.TemplateWizard;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface ITemplateExtension : IWizard
	{
	}
}