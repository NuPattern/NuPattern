﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.VsTemplateSchema
{
	partial class VSTemplate : IVsTemplate
	{
		[XmlIgnore]
		public string PhysicalPath { get; set; }

		[XmlIgnore]
		public bool IsZip { get { return PhysicalPath.EndsWith(".zip", StringComparison.InvariantCultureIgnoreCase); } }

		[XmlIgnore]
		public string TemplateFileName { get; set; }

		VsTemplateType IVsTemplate.Type
		{
			get
			{
				VsTemplateType type;
				if (Enum.TryParse<VsTemplateType>(this.Type, out type))
					return type;

				return VsTemplateType.Custom;
			}
		}

		string IVsTemplate.TypeString
		{
			get { return this.Type; }
		}

		IVsTemplateContent IVsTemplate.TemplateContent
		{
			get { return this.TemplateContent; }
		}

		IVsTemplateData IVsTemplate.TemplateData
		{
			get { return this.TemplateData; }
		}

		IEnumerable<IVsTemplateWizardData> IVsTemplate.WizardData
		{
			get { return this.WizardData ?? Enumerable.Empty<IVsTemplateWizardData>(); }
		}

		IEnumerable<IVsTemplateWizardExtension> IVsTemplate.WizardExtension
		{
			get { return this.WizardExtension ?? Enumerable.Empty<IVsTemplateWizardExtension>(); }
		}

		Version IVsTemplate.Version
		{
			get { return System.Version.Parse(this.Version); }
		}
	}

	partial class VSTemplateTemplateContent : IVsTemplateContent
	{
		IEnumerable<IVsTemplateCustomParameter> IVsTemplateContent.CustomParameters
		{
			get { return this.CustomParameters ?? Enumerable.Empty<IVsTemplateCustomParameter>(); }
		}

		IEnumerable<object> IVsTemplateContent.Items
		{
			get { return this.Items ?? Enumerable.Empty<object>(); }
		}
	}

	partial class VSTemplateTemplateContentCustomParameter : IVsTemplateCustomParameter
	{
	}

	partial class NameDescriptionIcon : IVsTemplateResourceOrValue
	{
		public bool HasValue
		{
			get { return !String.IsNullOrEmpty(this.Value); }
		}
	}

	partial class VSTemplateTemplateData : IVsTemplateData
	{
		IVsTemplateResourceOrValue IVsTemplateData.Description
		{
			get { return this.Description; }
		}

		IVsTemplateResourceOrValue IVsTemplateData.Icon
		{
			get { return this.Icon; }
		}

		IVsTemplateResourceOrValue IVsTemplateData.Name
		{
			get { return this.Name; }
		}

		bool? IVsTemplateData.CreateNewFolder
		{
			get { return this.CreateNewFolderSpecified ? (bool?)this.CreateNewFolder : null; }
		}

		bool? IVsTemplateData.EnableEditOfLocationField
		{
			get { return this.EnableEditOfLocationFieldSpecified ? (bool?)this.EnableEditOfLocationField : null; }
		}

		bool? IVsTemplateData.EnableLocationBrowseButton
		{
			get { return this.EnableLocationBrowseButtonSpecified ? (bool?)this.EnableLocationBrowseButton : null; }
		}

		bool? IVsTemplateData.Hidden
		{
			get { return this.HiddenSpecified ? (bool?)this.Hidden : null; }
		}

		VSTemplateTemplateDataLocationField? IVsTemplateData.LocationField
		{
			get { return this.LocationFieldSpecified ? (VSTemplateTemplateDataLocationField?)this.LocationField : null; }
		}

		bool? IVsTemplateData.PromptForSaveOnCreation
		{
			get { return this.PromptForSaveOnCreationSpecified ? (bool?)this.PromptForSaveOnCreation : null; }
		}

		bool? IVsTemplateData.ProvideDefaultName
		{
			get { return this.ProvideDefaultNameSpecified ? (bool?)this.ProvideDefaultName : null; }
		}

		VSTemplateTemplateDataRequiredFrameworkVersion? IVsTemplateData.RequiredFrameworkVersion
		{
			get { return this.RequiredFrameworkVersionSpecified ? (VSTemplateTemplateDataRequiredFrameworkVersion?)this.RequiredFrameworkVersion : null; }
		}

		bool? IVsTemplateData.SupportsCodeSeparation
		{
			get { return this.SupportsCodeSeparationSpecified ? (bool?)this.SupportsCodeSeparation : null; }
		}

		bool? IVsTemplateData.SupportsLanguageDropDown
		{
			get { return this.SupportsLanguageDropDownSpecified ? (bool?)this.SupportsLanguageDropDown : null; }
		}

		bool? IVsTemplateData.SupportsMasterPage
		{
			get { return this.SupportsMasterPageSpecified ? (bool?)this.SupportsMasterPage : null; }
		}

		[XmlElement(Namespace = "http://schemas.microsoft.com/developer/vssdktemplate/2007")]
		public string OutputSubPath { get; set; }
	}

	partial class VSTemplateWizardData : IVsTemplateWizardData
	{
		IEnumerable<XmlElement> IVsTemplateWizardData.Elements
		{
			get { return this.Any ?? Enumerable.Empty<XmlElement>(); }
		}
	}

	partial class VSTemplateWizardExtension : IVsTemplateWizardExtension
	{
		string IVsTemplateWizardExtension.Assembly
		{
			get { return this.Assembly.OfType<XmlNode[]>().SelectMany(nodes => nodes).Select(node => node.Value).FirstOrDefault(); }
		}

		string IVsTemplateWizardExtension.FullClassName
		{
			get { return this.FullClassName.OfType<XmlNode[]>().SelectMany(nodes => nodes).Select(node => node.Value).FirstOrDefault(); }
		}
	}
}