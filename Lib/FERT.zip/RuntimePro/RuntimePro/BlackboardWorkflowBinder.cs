﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;
using System.Windows.Forms;
using System.ComponentModel.Composition;


namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
    /// <summary>
    /// Binds a guidance workflow state to the storage in 
    /// the blackboard properties for the 
    /// overriden states and the focused activity.
    /// </summary>
    public class BlackboardWorkflowBinder
    {

        private readonly ITraceSource tracer;
        private readonly IGuidanceWorkflow guidanceWorkflow;
        private IFeatureExtension feature;

        /// <summary>
        /// Binds the state of the guidance workflow to Blackboard data, 
        /// and starts tracking changes in the workflow to update the underlying 
        /// storage in the Blackboard
        /// </summary>
        public BlackboardWorkflowBinder(IFeatureExtension feature, IGuidanceWorkflow guidanceWorkflow)
        {

            this.tracer = FeatureTracer.GetSourceFor<BlackboardWorkflowBinder>(feature.FeatureId, feature.InstanceName);
            this.guidanceWorkflow = guidanceWorkflow;

            this.feature = feature;

            //
            // Note: For BlackboardWorkflowBinder we don't set the WF state here because we have to wait
            // until the OnInitialize in Feature.cs initializes the Blackboard.
            //
            this.TrackChanges();
        }


        private void OnHasStateOverrideChanged(object sender, EventArgs e)
        {
            // If the override property changed, it means the state has 
            // been just overriden (HasStateOverride = true), in which 
            // case we do nothing as the OnNodeStateChanged would have 
            // caught it already. If it's false, then we have to clear 
            // the overriden state from storage.
            var guidanceNode = sender as IConditionalNode;
            if (guidanceNode != null && !guidanceNode.HasStateOverride)
            {
                BlackboardManager.Current.Set(BlackboardWorkflowBinder.StateOverrideKey(feature, guidanceNode), guidanceNode.State.ToString());
            }
        }

        private void OnIsUserAcceptedChanged(object sender, EventArgs e)
        {
            var guidanceNode = sender as IConditionalNode;
            if (guidanceNode != null)
            {
                BlackboardManager.Current.Set(BlackboardWorkflowBinder.UserAcceptedKey(feature, guidanceNode), guidanceNode.IsUserAccepted.ToString());
            }
        }

        private void OnNodeStateChanged(object sender, EventArgs e)
        {
            var guidanceNode = sender as IConditionalNode;
            if (guidanceNode != null)
            {
                BlackboardManager.Current.Set(BlackboardWorkflowBinder.StateOverrideKey(feature, guidanceNode), guidanceNode.HasStateOverride.ToString());
            }
        }

        private void TrackChanges()
        {
            foreach (var node in guidanceWorkflow.AllNodesToEvaluate)
            {
                node.StateChanged += OnNodeStateChanged;
                var conditional = node as IConditionalNode;
                conditional.IsUserAcceptedChanged += this.OnIsUserAcceptedChanged;
                conditional.HasStateOverrideChanged += this.OnHasStateOverrideChanged;
            }
        }

        public static string UserAcceptedKey(IFeatureExtension feature, object node)
        {
            var guidanceNode = node as IConditionalNode;

            return (feature.InstanceName + "." + guidanceNode.Name + ".UserAccepted");
        }

        public static string StateOverrideKey(IFeatureExtension feature, object node)
        {
            var guidanceNode = node as IConditionalNode;

            return (feature.InstanceName + "." + guidanceNode.Name + ".StateOverride");
        }

    }
}
