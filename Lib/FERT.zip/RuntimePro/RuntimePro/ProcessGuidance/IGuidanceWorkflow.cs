﻿using System;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IGuidanceWorkflow : IConditionalNode
	{
		/// <summary>
		/// Occurs when the focused activity changed.
		/// </summary>
		event EventHandler FocusedActionChanged;
		void ClearFocused();
		void Focus(IGuidanceAction activity);
		IGuidanceAction FocusedAction { get; }
		IInitial InitialNode { get; }
	    IList<IConditionalNode> AllNodesToEvaluate { get; }
        string OwningFeatureId { get; set;  }
        IFeatureExtension OwningFeature { get; set;  }
	}
}