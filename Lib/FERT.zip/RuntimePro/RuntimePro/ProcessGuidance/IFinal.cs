﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IFinal : INode
	{
	}
}