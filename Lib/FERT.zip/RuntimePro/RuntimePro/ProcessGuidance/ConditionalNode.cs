﻿using System;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Implements a <see cref="Node"/> with intrinsic state that is determined by
	/// pre and post conditions, and which can optionally be forced (overriden).
	/// </summary>
	public abstract class ConditionalNode : Node, IConditionalNode
	{
		private NodeState? stateOverride;
		private bool isUserAccepted;

		/// <summary>
		/// Initializes a new instance of the <see cref="ConditionalNode"/> class.
		/// </summary>
		/// <param name="stateComposer">The strategy to compose the state of this node from the predecessors state.</param>
		/// <param name="fanIn">The input cardinality of this predecessor.</param>
		/// <param name="fanOut">The output cardinality of this predecessor.</param>
		protected ConditionalNode(IStateComposer stateComposer, Cardinality fanIn, Cardinality fanOut)
			: base(stateComposer, fanIn, fanOut)
		{
			this.Preconditions = new List<IBinding<ICondition>>();
			this.Postconditions = new List<IBinding<ICondition>>();
		}

		public event EventHandler HasStateOverrideChanged = (s, e) => { };

		public event EventHandler IsUserAcceptedChanged = (s, e) => { };

		/// <summary>
		/// Gets the pre-conditions evaluated before the activity begins.
		/// </summary>
		/// <value>The pre-conditions evaluated before the activity begins.</value>
		public IList<IBinding<ICondition>> Preconditions { get; private set; }

		/// <summary>
		/// Gets the pre-conditions evaluated before the activity begins.
		/// </summary>
		/// <value>The pre-conditions evaluated before the activity begins.</value>
		IEnumerable<IBinding<ICondition>> IConditionalNode.Preconditions
		{
			get { return this.Preconditions; }
		}

		/// <summary>
		/// Gets the post-conditions evaluated when the activity is <see cref="NodeState.Available"/>.
		/// </summary>
		/// <value>The post-conditions evaluated when the activity is <see cref="NodeState.Available"/>.</value>
		public IList<IBinding<ICondition>> Postconditions { get; private set; }

		/// <summary>
		/// Gets the post-conditions evaluated when the activity is <see cref="NodeState.Available"/>.
		/// </summary>
		/// <value>The post-conditions evaluated when the activity is <see cref="NodeState.Available"/>.</value>
		IEnumerable<IBinding<ICondition>> IConditionalNode.Postconditions
		{
			get { return this.Postconditions; }
		}

		/// <summary>
		/// Gets a value indicating whether the state is forced.
		/// </summary>
		/// <value>
		/// 	<see langword="true"/> if the state is forced; otherwise, <see langword="false"/>.
		/// </value>
		public bool HasStateOverride
		{
			get { return stateOverride.HasValue; }
		}

		/// <summary>
		/// Gets the state of the activity.
		/// </summary>
		/// <value>One of the <see cref="NodeState"/> members.</value>
		public override NodeState State
		{
			get { return stateOverride ?? base.State; }
		}

		public bool IsUserAccepted
		{
			get
			{
				return this.isUserAccepted;
			}
			set
			{
				if (this.isUserAccepted != value)
				{
					this.isUserAccepted = value;
					this.OnIsUserAcceptedChanged();
				}
			}
		}

		/// <summary>
		/// Clears the state if it was forced.
		/// </summary>
		public virtual void ClearStateOverride()
		{
			var previousState = this.State;
			var hadStateOverride = this.HasStateOverride;
			stateOverride = null;

			if (previousState != base.State)
				this.OnStateChanged();

			if (hadStateOverride)
				this.OnHasStateOverrideChanged();
		}

		/// <summary>
		/// Sets the intrinsic state of the node.
		/// </summary>
		/// <param name="state">The new intrisic state  the node.</param>
		/// <param name="isOverride">if set to <see langword="true"/> the state is forced, otherwise the state is determined from an external evaluation.</param>
		public virtual void SetState(NodeState state, bool isOverride)
		{
			var previousState = this.State;
			var hadStateOverride = this.HasStateOverride;

			if (isOverride)
			{
				stateOverride = state;
				if (previousState != state)
					this.OnStateChanged();

				if (!hadStateOverride)
					this.OnHasStateOverrideChanged();
			}
			else
			{
				base.State = state;
				if (!hadStateOverride && previousState != state)
					this.OnStateChanged();
			}
		}

		protected void OnHasStateOverrideChanged()
		{
			this.OnPropertyChanged(Reflect<IConditionalNode>.GetProperty(g => g.HasStateOverride).Name);
			this.HasStateOverrideChanged(this, EventArgs.Empty);
		}


		private void OnIsUserAcceptedChanged()
		{
			this.OnPropertyChanged(Reflect<IConditionalNode>.GetProperty(g => g.IsUserAccepted).Name);
			this.IsUserAcceptedChanged(this, EventArgs.Empty);
		}
	}
}