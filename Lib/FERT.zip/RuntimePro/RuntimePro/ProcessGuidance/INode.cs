﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface INode : INotifyPropertyChanged //, IFluentInterface
	{
		event EventHandler StateChanged;
		string Name { get; }
        object ParentObject { get; set; }
		string Description { get; }
		/// <summary>
		/// Gets the link to optional guidance associated with the element.
		/// </summary>
		string Link { get; }
		IEnumerable<INode> Predecessors { get; }
		NodeState State { get; }
		IEnumerable<INode> Successors { get; }
	}
}