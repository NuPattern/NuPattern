﻿using System;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IConditionalNode : INode
	{
		event EventHandler HasStateOverrideChanged;
		event EventHandler IsUserAcceptedChanged;
		bool HasStateOverride { get; }
		bool IsUserAccepted { get; set; }
		IEnumerable<IBinding<ICondition>> Preconditions { get; }
		IEnumerable<IBinding<ICondition>> Postconditions { get; }
		void ClearStateOverride();
		void SetState(NodeState state, bool isOverride);
	}
}