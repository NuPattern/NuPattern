﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IInitial : INode
	{
		IGuidanceAction InitialActivity { get; }
	}
}