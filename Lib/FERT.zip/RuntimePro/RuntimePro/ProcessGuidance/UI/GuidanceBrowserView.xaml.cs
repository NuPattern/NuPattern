﻿using System.Windows.Controls;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Interaction logic for GuidanceBrowserView.xaml
	/// </summary>
	public partial class GuidanceBrowserView : UserControl
	{
		public GuidanceBrowserView()
		{
			this.InitializeComponent();
		}
	}
}