﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	[DebuggerStepThrough]
	public abstract class ViewModel : INotifyPropertyChanged
	{
		protected ViewModel()
		{
		}

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged<T>(Expression<Func<T>> propertyExpresion)
		{
			var property = propertyExpresion.Body as MemberExpression;
			if (property == null || !(property.Member is PropertyInfo) ||
				!property.Member.DeclaringType.IsAssignableFrom(this.GetType()))
			{
				throw new InvalidOperationException(string.Format(
					CultureInfo.CurrentCulture,
					Resources.ViewModel_InvalidExpressionProperty,
					propertyExpresion,
					this.GetType()));
			}

			this.OnPropertyChanged(property.Member.Name);
		}

		protected virtual void OnPropertyChanged(string propertyName)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
			}
		}
	}

	[DebuggerStepThrough]
	public abstract class ViewModel<T> : ViewModel where T : class
	{
		protected ViewModel(T model)
		{
			Guard.NotNull(() => model, model);

			this.Model = model;
			this.RegisterCommands();
		}

		protected internal T Model { get; private set; }

		protected virtual void RegisterCommands()
		{
		}
	}
}