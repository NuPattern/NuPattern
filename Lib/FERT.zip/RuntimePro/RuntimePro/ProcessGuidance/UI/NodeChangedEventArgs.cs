﻿using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class NodeChangedEventArgs : EventArgs
	{
		public NodeChangedEventArgs(INode node)
		{
			this.CurrentNode = node;
		}

		public INode CurrentNode { get; private set; }
	}
}