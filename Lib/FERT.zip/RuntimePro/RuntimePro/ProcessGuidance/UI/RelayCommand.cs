﻿using System;
using System.Diagnostics;
using System.Windows.Input;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	[DebuggerStepThrough]
	public class RelayCommand : ICommand
	{
		private Action execute;
		private Func<bool> canExecute;

		public RelayCommand(Action execute)
			: this(execute, () => true)
		{
		}

		public RelayCommand(Action execute, Func<bool> canExecute)
		{
			Guard.NotNull(() => execute, execute);
			Guard.NotNull(() => canExecute, canExecute);

			this.execute = execute;
			this.canExecute = canExecute;
		}

		public event EventHandler CanExecuteChanged
		{
			add { CommandManager.RequerySuggested += value; }
			remove { CommandManager.RequerySuggested -= value; }
		}

		public bool CanExecute(object parameter)
		{
			return this.canExecute();
		}

		public void Execute(object parameter)
		{
			if (this.CanExecute(parameter))
			{
				this.execute();
			}
		}
	}

	[DebuggerStepThrough]
	public class RelayCommand<T> : ICommand
	{
		private Action<T> execute;
		private Predicate<T> canExecute;

		public RelayCommand(Action<T> execute)
			: this(execute, o => true)
		{
		}

		public RelayCommand(Action<T> execute, Predicate<T> canExecute)
		{
			Guard.NotNull(() => execute, execute);
			Guard.NotNull(() => canExecute, canExecute);

			this.execute = execute;
			this.canExecute = canExecute;
		}

		public event EventHandler CanExecuteChanged
		{
			add { CommandManager.RequerySuggested += value; }
			remove { CommandManager.RequerySuggested -= value; }
		}

		public bool CanExecute(object parameter)
		{
			return this.canExecute((T)parameter);
		}

		public void Execute(object parameter)
		{
			if (this.CanExecute(parameter))
			{
				this.execute((T)parameter);
			}
		}
	}
}