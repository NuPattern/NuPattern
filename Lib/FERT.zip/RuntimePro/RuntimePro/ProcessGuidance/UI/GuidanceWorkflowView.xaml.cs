﻿using System.Windows.Controls;
using System.Windows.Data;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Interaction logic for GuidanceWorkflowToolView.xaml
	/// </summary>
	public partial class GuidanceWorkflowView : UserControl
	{
		public GuidanceWorkflowView()
		{
			this.InitializeComponent();
		}
	}
}