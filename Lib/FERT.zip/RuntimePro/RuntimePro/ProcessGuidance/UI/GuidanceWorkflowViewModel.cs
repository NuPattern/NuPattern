﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class GuidanceWorkflowViewModel : ViewModel
	{
        public static GuidanceWorkflowViewModel Current;
        private IEnumerable<TreeNodeViewModel<INode>> nodes;
        private NodeViewModel currentNode;
        private bool hasCurrentNode;

        public GuidanceWorkflowViewModel(IFeatureExtension feature)
        {
            Guard.NotNull(() => feature, feature);

            this.Feature = feature;
            Current = this;
        }
        public event EventHandler CurrentNodeChanged = (s, e) => { };

		public IFeatureExtension Feature { get; private set; }

		public NodeViewModel CurrentNode
		{
			get
			{
				return this.currentNode;
			}
			set
			{
				if (this.currentNode != value)
				{
					this.currentNode = value;
					this.HasCurrentNode = value != null;
					this.OnCurrentNodeChanged();
				}
			}
		}

		public bool HasCurrentNode
		{
			get
			{
				return this.hasCurrentNode;
			}
			private set
			{
				if (this.hasCurrentNode != value)
				{
					this.hasCurrentNode = value;
					this.OnPropertyChanged(() => this.HasCurrentNode);
				}
			}
		}

		public IGuidanceWorkflow Model
		{
			get { return this.Feature.GuidanceWorkflow; }
		}

		public string Name
		{
			get { return this.Feature.InstanceName; }
		}

		public IEnumerable<TreeNodeViewModel<INode>> Nodes
		{
			get
			{
				if (this.nodes == null)
				{
					this.LoadGuidanceTree();
				}

				return this.nodes;
			}
		}

		public void GoToFocusedAction()
		{
			var focusedAction = this.Model.FocusedAction;
			if (focusedAction != null)
			{
				var node = this.Nodes
					.Traverse(n => n.Nodes)
					.First(a => a.Model == focusedAction);
				node.IsSelected = true;

				node = node.ParentNode;
				while (node != null)
				{
					node.IsExpanded = true;
					node = node.ParentNode;
				}
			}
		}

		public void RefreshGraphStates()
		{
			GuidanceConditionsEvaluator.EvaluateGraph(this.Feature);
		}

		private void LoadGuidanceTree()
		{
			var viewModelBuilder = this.Feature as IWorkflowViewModelBuilder ?? new DefaultWorkflowViewModelBuilder(this.Feature);
			this.nodes = new ObservableCollection<NodeViewModel>(viewModelBuilder.GetNodes());

			foreach (var node in this.nodes.Traverse(node => node.Nodes))
			{
				node.SetSelected = currentNode => this.CurrentNode = (NodeViewModel)currentNode;
			}

			this.GoToFocusedAction();
		}

		private void OnCurrentNodeChanged()
		{
            if (this.CurrentNode.Node is IGuidanceAction)
                Model.Focus(this.CurrentNode.Node as IGuidanceAction);
			this.OnPropertyChanged(() => this.CurrentNode);
			this.CurrentNodeChanged(this, EventArgs.Empty);
		}
	}
}