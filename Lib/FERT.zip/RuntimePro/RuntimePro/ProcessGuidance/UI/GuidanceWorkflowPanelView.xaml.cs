﻿using System.Windows.Controls;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Interaction logic for GuidanceWorkflowPanelView.xaml
	/// </summary>
	public partial class GuidanceWorkflowPanelView : UserControl
	{
		public GuidanceWorkflowPanelView()
		{
			this.InitializeComponent();
		}
	}
}