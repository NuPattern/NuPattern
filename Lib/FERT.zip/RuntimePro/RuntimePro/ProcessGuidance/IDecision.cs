﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IDecision : IGuidanceAction
	{
	}
}