﻿using System;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IGuidanceAction : IConditionalNode
	{
        /// <summary>
        /// Gets the launch point references associated with the activity.
        /// </summary>
        IEnumerable<string> LaunchPoints { get; }
	}
}