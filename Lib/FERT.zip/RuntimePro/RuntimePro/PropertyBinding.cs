﻿using System.ComponentModel;
using System.Linq;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using System.Globalization;
using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
    public abstract class PropertyBinding
    {
		private readonly ITraceSource tracer;

        protected PropertyBinding(string propertyName)
        {
            this.PropertyName = propertyName;
			this.tracer = Tracer.GetSourceFor(this.GetType());
        }

        public string PropertyName { get; private set; }

        public abstract void SetValue(object target);

        protected void SetValue(object target, object value)
        {
            var property = TypeDescriptor.GetProperties(target)
                .Cast<PropertyDescriptor>()
                .FirstOrDefault(d => d.Name == this.PropertyName);

			if (property != null)
			{
				if (value != null && !property.PropertyType.IsAssignableFrom(value.GetType()))
				{
					if (property.Converter != null)
					{
						if (property.Converter.CanConvertFrom(value.GetType()))
						{
							property.SetValue(target, property.Converter.ConvertFrom(value));
						}
						else
						{
							var message = string.Format(CultureInfo.CurrentCulture, 
								"Provided value {0} is not compatible with property {1}.{2} of type {3}, and specific type conversion is not supported by provided converter {4}.",
								ObjectDumper.ToString(value, 5), target, this.PropertyName, property.PropertyType, property.Converter);

							tracer.TraceError(message);
							throw new ArgumentException(message);
						}
					}
					else
					{
						var message = string.Format(CultureInfo.CurrentCulture, 
							"Provided value {0} is not compatible with property {1}.{2} of type {3}, and a custom type conversion is not provided.",
							ObjectDumper.ToString(value, 5), target, this.PropertyName, property.PropertyType);

						tracer.TraceError(message);
						throw new ArgumentException(message);
					}
				}
				else
				{
					property.SetValue(target, value);
				}
			}
			else
			{
				var message = string.Format(CultureInfo.CurrentCulture, "Property {0}.{1} not found", target, this.PropertyName);
				tracer.TraceError(message);
				throw new ArgumentException(message);
			}
        }
    }

    public class FixedValuePropertyBinding : PropertyBinding
    {
        public FixedValuePropertyBinding(string propertyName, string value)
            : base(propertyName)
        {
            this.Value = value;
        }

        public string Value { get; private set; }

        public override void SetValue(object target)
        {
            base.SetValue(target, this.Value);
        }
    }

    public class ValueProviderPropertyBinding : PropertyBinding
    {
		private readonly ITraceSource tracer;

        public ValueProviderPropertyBinding(string propertyName, Binding<IValueProvider> binding)
            : base(propertyName)
        {
            this.Binding = binding;
			this.tracer = Tracer.GetSourceFor(this.GetType());
        }

        public Binding<IValueProvider> Binding { get; private set; }

        public override void SetValue(object target)
        {
			if (this.Binding.Evaluate())
			{
				var valueProvider = this.Binding.Value;
				this.SetValue(target, valueProvider.Evaluate());
			}
			else
			{
				tracer.TraceError("Value provider binding for property {0}.{1} could not be successfully evaluated. Errors: \n",
					target, this.PropertyName, ObjectDumper.ToString(this.Binding.EvaluationResults, 5));
			}
        }
    }
}