﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public static class CommandBindingExtensions
	{
		public static CommandBinding FindByName(this IEnumerable<CommandBinding> commands, string bindingName)
		{
			return commands.FirstOrDefault(binding => binding.Name.Equals(bindingName, StringComparison.OrdinalIgnoreCase));
		}
	}
}