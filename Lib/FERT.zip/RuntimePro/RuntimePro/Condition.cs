﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	[Condition]
	public abstract class Condition : ICondition
	{
		public abstract bool Evaluate();
	}
}