﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
    public interface ICondition
    {
        bool Evaluate();
    }
}