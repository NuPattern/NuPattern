﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Usability methods on over the <see cref="IFeatureManager"/>.
	/// </summary>
	public static class IFeatureManagerExtensions
	{
		/// <summary>
		/// Gets whether the given feature is installed in the system.
		/// </summary>
		public static bool IsInstalled(this IFeatureManager manager, string featureId)
		{
			return manager.InstalledFeatures.Any(registration => registration.FeatureId == featureId);
		}

		/// <summary>
		/// Gets whether the given feature has been instantiated in the solution.
		/// </summary>
		public static bool IsInstantiated(this IFeatureManager manager, string featureId)
		{
			return manager.InstantiatedFeatures.Any(feature => feature.FeatureId == featureId);
		}

		/// <summary>
		/// Gets whether the given feature has been instantiated in the solution.
		/// </summary>
		public static bool IsInstantiated(this IFeatureManager manager, IFeatureRegistration featureRegistration)
		{
			return manager.IsInstantiated(featureRegistration.FeatureId);
		}
	}
}
