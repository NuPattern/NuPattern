﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition.Primitives;
using System.ComponentModel;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.ExtensibilityHosting;
using System.ComponentModel.Composition.ReflectionModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Custom catalog that filters only parts that have a 
	/// <see cref="FeatureComponent"/> attribute applied, and
	/// provides default feature component metadata behavior.
	/// </summary>
	public class FeatureComponentCatalog : DecoratingReflectionCatalog //, IVsContractNameProvider
	{
		internal readonly static string CatalogNameMetadataKey = Reflect<IFeatureComponentMetadata>.GetProperty(x => x.CatalogName).Name;		
		internal readonly static string IdMetadataKey = Reflect<IFeatureComponentMetadata>.GetProperty(x => x.Id).Name;
		internal readonly static string CategoryMetadataKey = Reflect<IFeatureComponentMetadata>.GetProperty(x => x.Category).Name;
		internal readonly static string DescriptionMetadataKey = Reflect<IFeatureComponentMetadata>.GetProperty(x => x.Description).Name;
		internal readonly static string DisplayNameMetadataKey = Reflect<IFeatureComponentMetadata>.GetProperty(x => x.DisplayName).Name;
		internal readonly static string ExportingTypeMetadataKey = Reflect<IFeatureComponentMetadata>.GetProperty(x => x.ExportingType).Name;

		public FeatureComponentCatalog(ComposablePartCatalog innerCatalog)
			: base(new FilteringReflectionCatalog(innerCatalog)
			{
				PartFilter = part => part.PartType.AsFeatureComponent() != null, 
				ExportFilter = export => export.ExportingType.AsFeatureComponent() != null
			})
		{
			base.PartMetadataDecorator = PartDecorator;
			base.ExportMetadataDecorator = ExportDecorator;
		}

		private static void PartDecorator(DecoratedPart context)
		{
			DecorateMetadata(context.PartType.Value, context.NewMetadata);
		}

		private static void ExportDecorator(DecoratedExport context)
		{
			DecorateMetadata(context.ExportingType.Value, context.NewMetadata);
		}

		private static void DecorateMetadata(Type partType, IDictionary<string, object> metadata)
		{
			// Mark all components as having passed through our catalog.
			metadata[CatalogNameMetadataKey] = Constants.CatalogName;

			var featureAttribute = partType.AsFeatureComponent();

			if (featureAttribute != null)
			{
				// Override metadata with defaults if necessary.
				metadata[IdMetadataKey] = featureAttribute.Id;
				metadata[CategoryMetadataKey] = featureAttribute.Category;
				metadata[DescriptionMetadataKey] = featureAttribute.Description;
				metadata[DisplayNameMetadataKey] = featureAttribute.DisplayName;
				metadata[ExportingTypeMetadataKey] = partType;

                // check first for the presence of a creation policy metadata, and if none is defined, assign the NonShared one
                if (!metadata.ContainsKey(CompositionConstants.PartCreationPolicyMetadataName))
                    metadata[CompositionConstants.PartCreationPolicyMetadataName] = CreationPolicy.NonShared;	
			}
		}

		public IDictionary<string, IList<string>> Exports
		{
			get 
			{
				return base.Parts.ToDictionary(
					part => ReflectionModelServices.GetPartType(part).Value.Name, 
					part => (IList<string>)part.ExportDefinitions.Select(export => export.ContractName).ToList());
			}
		}
	}

	/// <summary>
	/// Helper methods that simplify working with exports that come from our catalog.
	/// </summary>
	public static class CompositionExportExtensions
	{
		/// <summary>
		/// Filters the exports to only those that were processed by the features component catalog.
		/// </summary>
		public static IEnumerable<Lazy<T, TMetadataView>> FromFeaturesCatalog<T, TMetadataView>(this IEnumerable<Lazy<T, TMetadataView>> exports)
			where T : class
			where TMetadataView : IFeatureComponentMetadata
		{
			return exports.Where(e => e.Metadata.CatalogName == Constants.CatalogName);
		}

		/// <summary>
		/// Filters the exports to only those that were processed by the features component catalog.
		/// </summary>
		public static IEnumerable<Lazy<T, IDictionary<string, object>>> FromFeaturesCatalog<T>(this IEnumerable<Lazy<T, IDictionary<string, object>>> exports)
			where T : class
		{
			return exports.Where(e =>
				e.Metadata.ContainsKey(FeatureComponentCatalog.CatalogNameMetadataKey) &&
				(string)e.Metadata[FeatureComponentCatalog.CatalogNameMetadataKey] == Constants.CatalogName);
		}
	}

}
