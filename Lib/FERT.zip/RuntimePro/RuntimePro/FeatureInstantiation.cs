﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public enum FeatureInstantiation
	{
		None,
		SingleInstance,
		MultipleInstance
	}
}