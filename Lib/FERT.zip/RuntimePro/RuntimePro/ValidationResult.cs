﻿using System.ComponentModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class ValidationResult
	{
        public ValidationResult(string propertyName, string errorMessage)
		{
			this.PropertyName = propertyName;
			this.ErrorMessage = errorMessage;
		}

		public string PropertyName { get; private set; }

		public string ErrorMessage { get; private set; }
	}
}