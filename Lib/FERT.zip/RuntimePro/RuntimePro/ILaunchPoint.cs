﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.ExtensionEnablement;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Feature command launch point
	/// </summary>
	public interface ILaunchPoint
	{
        bool CanExecute(IFeatureExtension feature);
        void Execute(IFeatureExtension feature);
	}
}
