﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	[FeatureCommand]
	public abstract class FeatureCommand : IFeatureCommand
	{
		public abstract void Execute();
	}
}