﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.VisualStudio.Shell.Interop;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics
{
	public class OutputWindowTextWriter : TextWriter
	{
		IVsOutputWindowPane outputPane;

		public OutputWindowTextWriter(IVsOutputWindowPane outputPane)
		{
			this.outputPane = outputPane;
		}

		public override Encoding Encoding
		{
			get { return Encoding.UTF8; }
		}

		public override void Write(string value)
		{
			outputPane.OutputStringThreadSafe(value);
		}

		public override void WriteLine()
		{
			outputPane.OutputStringThreadSafe(Environment.NewLine);
		}

		public override void WriteLine(string value)
		{
			Write(value);
			WriteLine();
		}
	}
}
