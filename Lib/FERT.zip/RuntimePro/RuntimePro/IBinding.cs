﻿using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IBinding<T> where T : class
	{
		IEnumerable<BindingResult> EvaluationResults { get; }
		bool HasErrors { get; }
		string UserMessage { get; set; }
		T Value { get; }
		bool Evaluate();
	}
}