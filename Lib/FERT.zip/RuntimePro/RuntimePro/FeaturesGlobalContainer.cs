﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.ComponentModel.Composition.ReflectionModel;
using System.Linq;
using Microsoft.VisualStudio.ComponentModelHost;
using Microsoft.VisualStudio.ExtensibilityHosting;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;


namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Provides access to the feature runtime composition services.
	/// </summary>
	public class FeaturesGlobalContainer : CompositionContainer 
		// inheriting CompositionContainer is a workaround for a MEF issue in Beta2
		// that prevents us from using CompositionContainer as a contract type 
		// but with a different contract name.
	{
		static readonly ITraceSource tracer = Tracer.GetSourceFor<FeaturesGlobalContainer>();

		/// <summary>
		/// Contract name of the exported global container.
		/// </summary>
		public static readonly string ExportedContractName = typeof(FeaturesGlobalContainer).FullName;

		private static object syncLock = new object();

		[Export(typeof(FeaturesGlobalContainer))]
		public static CompositionContainer Instance { get; internal set; }

		static FeaturesGlobalContainer()
		{
			var globalComponentModel = (IComponentModel)Package.GetGlobalService(typeof(SComponentModel));
			if (globalComponentModel == null)
			{
				tracer.TraceWarning("Could not retrieve the VS global IComponentModel service.");
			}
			else
			{
				var catalog = globalComponentModel.GetCatalog(Constants.CatalogName);
				if (catalog == null)
				{
					tracer.TraceWarning("Could not retrieve the catalog '{0}' from the global IComponentModel service.", Constants.CatalogName);
				}
				else
				{
					try
					{
                        //
                        // Create our DecoratingReflectionCatalog
                        //
						FeatureComponentCatalog featureComponentsCatalog = new FeatureComponentCatalog(catalog);

                        //
                        // Now create a catalog provider
                        //
                        CatalogExportProvider catalogProvider = new CatalogExportProvider(featureComponentsCatalog);
						
                        //
                        // have it inherit the global provider
                        //
                        catalogProvider.SourceProvider = globalComponentModel.DefaultExportProvider;

                        //
                        // Create provider settings to look here first and then include others when not found
                        //
                        VsExportProviderSettings providerSettings = new VsExportProviderSettings(
							VsExportProvidingPreference.BeforeExportsFromOtherContainers, 
                            VsExportSharingPolicy.IncludeExportsFromOthers);

                        Instance = VsCompositionContainer.Create(featureComponentsCatalog, providerSettings);
					}
					catch (Exception ex)
					{
						tracer.TraceError(ex, "Failed to initialize global container");
						throw;
					}
				}
			}
		}

		// Implements the "innovation" interface that VsCompositionContainer requires but does not 
		// make explicit in the API in any way.
		class VsContractNameProviderCatalogExportProvider : CatalogExportProvider //, IVsContractNameProvider
		{
			public VsContractNameProviderCatalogExportProvider(ComposablePartCatalog catalog)
				: base(catalog)
			{
			}

			public IDictionary<string, IList<string>> Exports
			{
				get
				{
					return base.Catalog.Parts.ToDictionary(
						part => ReflectionModelServices.GetPartType(part).Value.Name,
						part => (IList<string>)part.ExportDefinitions.Select(export => export.ContractName).ToList());
				}
			}
		}
	}
}