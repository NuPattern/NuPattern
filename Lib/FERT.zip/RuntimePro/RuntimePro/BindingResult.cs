﻿using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class BindingResult
	{
		internal BindingResult(string propertyName)
		{
			this.PropertyName = propertyName;
			this.Errors = new List<string>();
            this.InnerResults = new List<BindingResult>();
		}

		public ICollection<string> Errors { get; private set; }

        public ICollection<BindingResult> InnerResults { get; private set; }

        public string PropertyName { get; private set; }

        public object Value { get; internal set; }
    }
}