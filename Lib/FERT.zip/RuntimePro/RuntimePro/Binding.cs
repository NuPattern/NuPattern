﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class Binding<T> : IBinding<T> where T : class
	{
		private Dictionary<string, BindingResult> evaluationResults = new Dictionary<string, BindingResult>();
		private ITraceSource tracer;
		private IFeatureCompositionService featureComposition;
		private PropertyBinding[] propertyBindings;
		private Lazy<T, IFeatureComponentMetadata> lazyValue;
		private string userMessage;
		public string componentTypeId;

		public Binding(IFeatureCompositionService featureComposition, string componentTypeId, params PropertyBinding[] propertyBindings)
		{
			Guard.NotNull(() => featureComposition, featureComposition);
			Guard.NotNullOrEmpty(() => componentTypeId, componentTypeId);

			this.componentTypeId = componentTypeId;
			this.featureComposition = featureComposition;
			this.propertyBindings = propertyBindings;
			this.InitializeTracer();

            ResolveComponentTypeId();

			featureComposition.SatisfyImportsOnce(this);
		}

        private void ResolveComponentTypeId()
        {
            this.lazyValue = featureComposition.GetExports<T, IFeatureComponentMetadata>()
                        .FromFeaturesCatalog()
                        .FirstOrDefault(component => component.Metadata.Id == componentTypeId);
        }

		public IEnumerable<BindingResult> EvaluationResults
		{
			get { return this.evaluationResults.Values; }
		}

		/// <summary>
		/// Gets the <see cref="IFeatureCompositionService"/> allowing access to MEF.
		/// </summary>
		protected IFeatureCompositionService FeatureComposition
		{
			get { return this.featureComposition; }
		}

		public bool HasErrors { get; protected set; }

		public string UserMessage
		{
			get
			{
				if (this.userMessage == null && this.lazyValue != null)
				{
					this.userMessage = this.lazyValue.Metadata.DisplayName;
				}

				return this.userMessage;
			}
			set
			{
				this.userMessage = value;
			}
		}

		public T Value
		{
			get { return this.lazyValue == null ? null : this.lazyValue.Value; }
		}

		/// <summary>
		/// Evaluates this binding.
		/// </summary>
		/// <returns><see langword="true"/>, if the evaluation of the binding succeded; otherwise <see langword="false"/>.</returns>
		public virtual bool Evaluate()
		{
            if (FeatureManager.VerboseBindingTracing)
			    tracer.TraceVerbose("Evaluating binding {0}", this.lazyValue == null ? this.ToString() : this.lazyValue.Metadata.Id, this);
			this.evaluationResults.Clear();

            if (this.lazyValue == null)
            {
                // Re-evaluate component from MEF as new available exports 
                // might have made it available whereas previously it was not.
                ResolveComponentTypeId();
            }

			bool evaluationResult;
			if (this.Value == null)
			{
				evaluationResult = false;

				var bindingResult = new BindingResult("this");
				bindingResult.Errors.Add(string.Format(CultureInfo.CurrentCulture,
					"Could not resolve component with id '{0}' to an actual instance of type {1}.",
					this.componentTypeId, typeof(T).Name));

				this.evaluationResults.Add("this", bindingResult);
			}
			else
			{
				var initializable = this.Value as ISupportInitialize;
				var editable = this.Value as IEditableObject;
				if (initializable != null)
					initializable.BeginInit();
				if (editable != null)
					editable.BeginEdit();

				featureComposition.SatisfyImportsOnce(this.Value);
				evaluationResult = this.EvaluateProperties();

				if (evaluationResult)
				{
					evaluationResult = this.Validate();
					if (evaluationResult)
					{
						if (editable != null)
							editable.EndEdit();
						if (initializable != null)
							initializable.EndInit();
					}
					else
					{
						if (editable != null)
							editable.CancelEdit();
					}
				}
				else
				{
					// We don't call EndInit as we didn't end.
					if (editable != null)
						editable.CancelEdit();
				}
			}

			this.HasErrors = !evaluationResult;

            if (FeatureManager.VerboseBindingTracing)
			    tracer.TraceData(TraceEventType.Verbose, 0, this);

			return evaluationResult;
		}

		/// <summary>
		/// Creates a validator for the binding, which derived classes 
		/// can change from the default <see cref="DataAnnotationsValidator"/>.
		/// </summary>
		protected virtual IValidator GetValidator()
		{
			return new DataAnnotationsValidator();
		}

		/// <summary>
		/// Evaluates properties and returns false if any property failed to 
		/// evaluate.
		/// </summary>
		private bool EvaluateProperties()
		{
			if (!this.propertyBindings.Any())
				return true;

			var result = true;
			var properties = TypeDescriptor.GetProperties(this.Value);

			foreach (var propertyBinding in this.propertyBindings)
			{
				var bindResult = new BindingResult(propertyBinding.PropertyName);
				try
				{
					propertyBinding.SetValue(this.Value);
					bindResult.Value = properties[propertyBinding.PropertyName].GetValue(this.Value);
				}
				catch (Exception e)
				{
					bindResult.Errors.Add(e.Message);
					result = false;
				}

				var valueProviderBinding = propertyBinding as ValueProviderPropertyBinding;
				if (valueProviderBinding != null)
				{
					bindResult.InnerResults.AddRange(valueProviderBinding.Binding.EvaluationResults);
				}

				this.evaluationResults.Add(propertyBinding.PropertyName, bindResult);
			}

			return result;
		}

		private void InitializeTracer()
		{
			var featureManager = featureComposition.GetExportedValueOrDefault<IFeatureManager>();
			if (featureManager != null)
			{
				var featureRegistration = featureManager.FindFeature(this.GetType());
				if (featureRegistration != null)
					tracer = FeatureTracer.GetSourceFor<Binding<T>>(featureRegistration.FeatureId);
			}

			if (tracer == null)
				tracer = Tracer.GetSourceFor<Binding<T>>();
		}

		private bool Validate()
		{
			var isValid = true;
			foreach (var validationResult in this.GetValidator().Validate(this.Value))
			{
				BindingResult bindResult;
				if (!this.evaluationResults.TryGetValue(validationResult.PropertyName, out bindResult))
				{
					bindResult = new BindingResult(validationResult.PropertyName);
					this.evaluationResults.Add(validationResult.PropertyName, bindResult);
				}

				bindResult.Errors.Add(validationResult.ErrorMessage);
				isValid = false;
			}

			return isValid;
		}
	}
}