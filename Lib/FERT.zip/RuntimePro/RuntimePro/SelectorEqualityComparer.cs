﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Allows comparisons (and Distinct in linq) by using 
	/// a simple selector function that projects a value 
	/// from a source, to use for comparison.
	/// </summary>
	public class SelectorEqualityComparer<TSource, TResult> : IEqualityComparer<TSource>
	{
		Func<TSource, TResult> selector;

		public SelectorEqualityComparer(Func<TSource, TResult> selector)
		{
			Guard.NotNull(() => selector, selector);

			this.selector = selector;
		}

		public bool Equals(TSource x, TSource y)
		{
			if (Object.Equals(null, x) || Object.Equals(null, y))
				return false;

			return Object.Equals(selector(x), selector(y));
		}

		public int GetHashCode(TSource obj)
		{
			if (obj == null)
				throw new ArgumentNullException("obj");

			return selector(obj).GetHashCode();
		}
	}
}
