﻿using System;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Keeps the list of instantiated features in a solution in a permanent storage.
	/// </summary>
	public interface ISolutionState
	{
		IEnumerable<SolutionFeatureState> InstantiatedFeatures { get; }
		
		void AddFeature(string featureId, string instanceName, Version version);
		
		void RemoveFeature(string featureId, string instanceName);

		/// <summary>
		/// Updates the feature state with the given id and name with the 
		/// specified version.
		/// </summary>
		void Update(string featureId, string instanceName, Version newVersion);
	}
}