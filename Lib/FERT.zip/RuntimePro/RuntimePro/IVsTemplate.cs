﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.VsTemplateSchema;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public enum VsTemplateType
	{
		Custom,
		Item,
		Project,
		ProjectGroup, 
	}

	public interface IVsTemplate 
	{
		/// <summary>
		/// Full path to the file this template was read from.
		/// </summary>
		string PhysicalPath { get; }
		/// <summary>
		/// The file name of the template, without its full path. 
		/// In a zip template, this name may be different from 
		/// the full path file, as it represents the .vstemplate 
		/// inside the zip.
		/// </summary>
		string TemplateFileName { get; }
		VsTemplateType Type { get; }
		string TypeString { get; }
		/// <summary>
		/// Whether the template was read from a zip file or a 
		/// regular .vstemplate file.
		/// </summary>
		bool IsZip { get; }
		Version Version { get; }
		IVsTemplateContent TemplateContent { get; }
		IVsTemplateData TemplateData { get; }
		IEnumerable<IVsTemplateWizardData> WizardData { get; }
		IEnumerable<IVsTemplateWizardExtension> WizardExtension { get; }
	}

	public interface IVsTemplateWizardExtension
	{
		string Assembly { get; }
		string FullClassName { get; }
	}

	public interface IVsTemplateWizardData
	{
		IEnumerable<XmlElement> Elements { get; }
		string Name { get; }
	}

	public interface IVsTemplateContent
	{
		IEnumerable<IVsTemplateCustomParameter> CustomParameters { get; }
		IEnumerable<object> Items { get; }
		//[System.Xml.Serialization.XmlElementAttribute("Project", typeof(VSTemplateTemplateContentProject))]
		//[System.Xml.Serialization.XmlElementAttribute("ProjectCollection", typeof(VSTemplateTemplateContentProjectCollection))]
		//[System.Xml.Serialization.XmlElementAttribute("ProjectItem", typeof(VSTemplateTemplateContentProjectItem))]
		//[System.Xml.Serialization.XmlElementAttribute("References", typeof(VSTemplateTemplateContentReferences))]
	}

	public interface IVsTemplateCustomParameter
	{
		string Name { get; }
		string Value { get; }
	}

	public interface IVsTemplateResourceOrValue
	{
		string ID { get;  }
		string Package { get;  }
		string Value { get;  }
		bool HasValue { get; }
	}

	public interface IVsTemplateData
	{
		object BuildOnLoad { get;  }
		object CreateInPlace { get;  }
		bool? CreateNewFolder { get;  }
		string DefaultName { get;  }
		IVsTemplateResourceOrValue Description { get;  }
		bool? EnableEditOfLocationField { get;  }
		bool? EnableLocationBrowseButton { get;  }
		bool? Hidden { get;  }
		IVsTemplateResourceOrValue Icon { get;  }
		VSTemplateTemplateDataLocationField? LocationField { get;  }
		string LocationFieldMRUPrefix { get;  }
		IVsTemplateResourceOrValue Name { get;  }
		string NumberOfParentCategoriesToRollUp { get;  }
		string ProjectSubType { get;  }
		string ProjectType { get;  }
		bool? PromptForSaveOnCreation { get;  }
		bool? ProvideDefaultName { get;  }
		VSTemplateTemplateDataRequiredFrameworkVersion? RequiredFrameworkVersion { get;  }
		object ShowByDefault { get;  }
		string SortOrder { get;  }
		bool? SupportsCodeSeparation { get;  }
		bool? SupportsLanguageDropDown { get;  }
		bool? SupportsMasterPage { get;  }
		string TemplateGroupID { get;  }
		string TemplateID { get;  }

		string OutputSubPath { get; }
	}
}
