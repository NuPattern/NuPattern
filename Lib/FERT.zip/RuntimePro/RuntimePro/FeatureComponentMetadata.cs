﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;
using System.Reflection;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;
using Microsoft.VisualStudio.TemplateWizard;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
    /// <summary>
    /// Specifies that the component is a provided <see cref="IValueProvider"/>.
    /// </summary>
    public class ValueProviderAttribute : FeatureComponentAttribute
    {
        /// <summary>
        /// Initializes the attribute.
        /// </summary>
        public ValueProviderAttribute()
            : base(typeof(IValueProvider))
        {
        }
    }

    /// <summary>
    /// Specifies that the component is a provided <see cref="IFeatureCommand"/>.
    /// </summary>
    public class FeatureCommandAttribute : FeatureComponentAttribute
    {
        /// <summary>
        /// Initializes the attribute.
        /// </summary>
        public FeatureCommandAttribute()
            : base(typeof(IFeatureCommand))
        {
        }
    }

    /// <summary>
    /// Specifies that the component is a provided <see cref="ICondition"/>.
    /// </summary>
    public class ConditionAttribute : FeatureComponentAttribute
    {
        /// <summary>
        /// Initializes the attribute.
        /// </summary>
        public ConditionAttribute()
            : base(typeof(ICondition))
        {
        }
    }

    /// <summary>
    /// Specifies that the component is a provided <see cref="IWizard"/>.
    /// </summary>
    public class TemplateExtensionAttribute : FeatureComponentAttribute
    {
        /// <summary>
        /// Initializes the attribute.
        /// </summary>
        public TemplateExtensionAttribute()
            : base(typeof(ITemplateExtension))
        {
        }
    }

    /// <summary>
    /// Base attribute used by component provided by a feature.
    /// </summary>
    [MetadataAttribute]
    [AttributeUsage(AttributeTargets.Class)]
    public class FeatureComponentAttribute : InheritedExportAttribute, IFeatureComponentMetadata
    {
        /// <summary>
        /// Exports the component using the default contract information.
        /// </summary>
        public FeatureComponentAttribute()
        {
        }

        /// <summary>
        /// Exports the component with the given contract type.
        /// </summary>
        public FeatureComponentAttribute(Type contractType)
            : base(contractType)
        {
        }

		/// <summary>
		/// Exports the component with the given contract name.
		/// </summary>
		public FeatureComponentAttribute(string contractName)
			: base(contractName)
		{
		}

		/// <summary>
		/// Exports the component with the given contract name and type.
		/// </summary>
		public FeatureComponentAttribute(string contractName, Type contractType)
			: base(contractName, contractType)
		{
		}

        /// <summary>
        /// Optionally sets the  id of the component, which otherwise defaults 
        /// to the component full type name.
        /// </summary>
        public virtual string Id { get; set; }

        /// <summary>
        /// Gets or sets the category of the component. Alternatively, 
        /// consider using <see cref="CategoryAttribute"/> which allows 
        /// localization.
        /// </summary>
        public virtual string Category { get; set; }

        /// <summary>
        /// Gets or sets the display name of the component. Alternatively, 
        /// consider using <see cref="DisplayNameAttribute"/> which allows 
        /// localization.
        /// </summary>
        public virtual string DisplayName { get; set; }

        /// <summary>
        /// Gets or sets the description of the component. Alternatively, 
        /// consider using <see cref="DescriptionAttribute"/> which allows 
        /// localization.
        /// </summary>
        public virtual string Description { get; set; }

        /// <summary>
        /// Gets or sets the exporting type. For use by the runtime.
        /// </summary>
        internal Type ExportingType { get; set; }

        /// <summary>
        /// Explicit implementation so that users don't see it in intellisense.
        /// </summary>
        Type IFeatureComponentMetadata.ExportingType { get { return ExportingType; } }

        /// <summary>
        /// Explicit implementation so that users don't see it in intellisense.
        /// </summary>
        string IFeatureComponentMetadata.CatalogName { get { return null; } }
     
    }

    /// <summary>
    /// Metadata provided by a feature component
    /// </summary>
    public interface IFeatureComponentMetadata
    {
        /// <summary>
        /// Gets the id of the component
        /// </summary>
        string Id { get; }

        /// <summary>
        /// Gets the display name of the component
        /// </summary>
        string DisplayName { get; }

        /// <summary>
        /// Gets the description of the component
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Gets the category of the component.
        /// </summary>
        string Category { get; }

        /// <summary>
        /// Gets the actual type of the provided feature component.
        /// </summary>
        Type ExportingType { get; }

        /// <summary>
        /// Gets the catalog the component is being retrieved from.
        /// </summary>
        string CatalogName { get; }
    }

    /// <summary>
    /// Provides extensions for <see cref="Type"/> to access the feature component metadata 
    /// and specify its defaults.
    /// </summary>
    public static class FeatureComponentTypeExtensions
    {
        /// <summary>
        /// Returns the <see cref="IFeatureComponentMetadata"/> of the type if available, 
        /// <see langword="null"/> otherwise (i.e. the type does not have a 
        /// <see cref="FeatureComponentAttribute"/> attribute or a derived one applied).
        /// </summary>
        public static IFeatureComponentMetadata AsFeatureComponent(this Type componentType)
        {
            var metadata = componentType.GetCustomAttribute<FeatureComponentAttribute>();
            if (metadata == null)
                metadata = componentType.FeatureComponentDynamic();

            if (metadata == null)
                return null;

            if (string.IsNullOrEmpty(metadata.Id))
                metadata.Id = componentType.FullName;

            if (metadata.ExportingType == null)
                metadata.ExportingType = componentType;

            if (string.IsNullOrEmpty(metadata.Category))
                metadata.Category = TypeDescriptor.GetAttributes(componentType)
                    .OfType<CategoryAttribute>()
                    .Select(attribute => attribute.Category)
                    .FirstOrDefault();

            if (string.IsNullOrEmpty(metadata.Category))
                metadata.Category = Resources.FeatureComponentAttribute_DefaultCategory;

            if (string.IsNullOrEmpty(metadata.Description))
                metadata.Description = TypeDescriptor.GetAttributes(componentType)
                    .OfType<System.ComponentModel.DescriptionAttribute>()
                    .Select(attribute => attribute.Description)
                    .FirstOrDefault();

            if (string.IsNullOrEmpty(metadata.DisplayName))
            {
                var displayName = TypeDescriptor.GetAttributes(componentType)
                    .OfType<DisplayNameAttribute>()
                    .Select(attribute => attribute.DisplayName)
                    .FirstOrDefault();
                if (string.IsNullOrEmpty(displayName))
                    displayName = componentType.Name;

                metadata.DisplayName = displayName;
            }

            return metadata;
        }

        private static FeatureComponentAttribute FeatureComponentDynamic(this Type component)
        {
            // The dynamic version is necessary when the component type was obtained using the DynamicTypeService
            // So the component will be in another (temp) assembly and the cast to IFeatureComponentMetadata won't work.

            foreach (Attribute attribute in component.GetCustomAttributes(true))
            {
                if (IsFeatureComponentMetadata(attribute.GetType()))
                {
                    var featureComponentAttribute = new FeatureComponentAttribute();

                    foreach (var property in attribute.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetProperty | BindingFlags.SetProperty))
                    {
                        var featureComponentAttributeProperty = featureComponentAttribute.GetType().GetProperty(property.Name);
                        if (featureComponentAttributeProperty != null && featureComponentAttributeProperty.CanWrite)
                            featureComponentAttributeProperty.SetValue(featureComponentAttribute, property.GetValue(attribute, null), null);
                    }

                    return featureComponentAttribute;
                }
            }

            return null;
        }

        private static bool IsFeatureComponentMetadata(Type attributeType)
        {
            if (attributeType == null) return false;

            if (attributeType.AssemblyQualifiedName == typeof(FeatureComponentAttribute).AssemblyQualifiedName)
                return true;
            else
                return IsFeatureComponentMetadata(attributeType.BaseType);
        }
    }
}
