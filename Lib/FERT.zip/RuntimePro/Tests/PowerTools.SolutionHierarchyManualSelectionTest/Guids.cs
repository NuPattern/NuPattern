﻿// Guids.cs
// MUST match guids.h
using System;

namespace Microsoft.PowerTools_SolutionHierarchySelectionTest
{
    static class GuidList
    {
        public const string guidPowerTools_SolutionHierarchySelectionTestPkgString = "b1878bad-3a46-451e-aaa3-4cb240d8bba9";
        public const string guidPowerTools_SolutionHierarchySelectionTestCmdSetString = "7a027cd6-dabe-4c9c-8437-8a16d574cd4c";
        public const string guidToolWindowPersistanceString = "624bc194-596f-403d-aaf2-83dab015893e";

        public static readonly Guid guidPowerTools_SolutionHierarchySelectionTestCmdSet = new Guid(guidPowerTools_SolutionHierarchySelectionTestCmdSetString);
    };
}