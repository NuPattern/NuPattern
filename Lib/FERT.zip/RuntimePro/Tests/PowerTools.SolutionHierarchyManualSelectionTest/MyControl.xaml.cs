﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.VisualStudio.TeamArchitect.PowerTools;

namespace Microsoft.PowerTools_SolutionHierarchySelectionTest
{
    /// <summary>
    /// Interaction logic for MyControl.xaml
    /// </summary>
    public partial class MyControl : UserControl
    {
        public MyControl()
        {
            InitializeComponent();

            
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Globalization", "CA1300:SpecifyMessageBoxOptions")]
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            // MessageBox.Show(string.Format("Solution name {0}", Solution.Name), "My Tool Window");
            var str = textBox1.Text;

            IItemContainer scope = Solution;
            if(checkBox1.IsChecked ?? false)
            {
                scope = Solution.GetSelection().FirstOrDefault() ?? Solution;
            }
            
            var items = scope.Find(str);

            Solution.SetSelection(items);                        
        }

        public ISolution Solution { get; set; }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            IItemContainer scope = Solution;
            //if (checkBox2.IsChecked ?? false)
            //{
            //    scope = Solution.GetSelection().FirstOrDefault() ?? Solution;
            //} 
            
            var items = scope.GetSelection().Select(i => i.Name).ToArray();
            listBox1.ItemsSource = items;           
        }
    }
}