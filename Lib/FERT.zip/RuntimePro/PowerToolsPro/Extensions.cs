﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	/// <summary>
	/// Provides common extensions for CLR types.
	/// </summary>
	public static class Extensions
	{
		/// <summary>
		/// Traverses the given source, using the specified recurse function and 
		/// stop condition for traversal.
		/// </summary>
		/// <returns>The first item that matches the condition, or <see langword="null"/></returns>
		public static T Traverse<T>(this T source, Func<T, T> recurseFunction, Predicate<T> stopCondition)
		{
			if (source == null)
				return default(T);

			if (stopCondition(source))
				return source;

			return recurseFunction(source).Traverse(recurseFunction, stopCondition);
		}

		/// <summary>
		/// Traverses the given source, using the specified recurse function and 
		/// stop condition for traversal.
		/// </summary>
		/// <returns>The first item that matches the condition, or <see langword="null"/></returns>
		public static T Traverse<T>(this T node, Func<T, IEnumerable<T>> recurseFunction, Predicate<T> stopCondition)
		{
			foreach (var parentNode in recurseFunction(node))
			{
				if (stopCondition(parentNode))
				{
					return parentNode;
				}
				else
				{
					return parentNode.Traverse(recurseFunction, stopCondition);
				}
			}

			return default(T);
		}

		/// <summary>
		/// Flattens a hierarchy by doing a depth-first traversal using the 
		/// given recurse function.
		/// </summary>
		/// <returns>The flattened hierarchy.</returns>
		public static IEnumerable<T> Traverse<T>(this IEnumerable<T> source, Func<T, IEnumerable<T>> recurseFunction)
		{
			foreach (T item in source)
			{
				yield return item;

				var recurseSequence = recurseFunction(item);
				if (recurseSequence != null)
				{
                    foreach (T itemRecurse in Traverse(recurseSequence, recurseFunction))
                    {
                        yield return itemRecurse;
                    }
				}
			}
		}

		/// <summary>
		/// Invokes the provided initializers passing the instance and returning it 
		///	afterwards.
		/// </summary>
		/// <typeparam name="T">Type of the object instance.</typeparam>
		/// <param name="instance">The instance to apply the initializers to.</param>
		/// <param name="initializers">One or more initializers to apply to the instance.</param>
		/// <returns>The <paramref name="instance"/>.</returns>
		/// <remarks>
		/// Allows to chain calls after an object has been constructed, so that 
		/// further invocations can be done in it without declaring intermediate variables.
		/// </remarks>
		/// <example>
		/// The following example shows how to invoke a factory method, initialize the 
		/// object and continue invoking methods on the original object.
		/// <code>
		/// model
		/// 		.CreatePackage()
		/// 			.CreatePackage()
		/// 				.With(
		/// 					p => p.CreateClass(),
		/// 					p => p.CreateClass(), 
		/// 					p => p.CreateInterface()
		/// 				)
		/// 			.CreatePackage()
		/// 				.With(
		/// 					p => p.CreateClass(),
		/// 					p => p.CreateClass()
		/// 				);
		/// </code>
		/// </example>
		public static T With<T>(this T instance, params Action<T>[] initializers)
		{
			foreach (var initializer in initializers)
			{
				initializer(instance);
			}

			return instance;
		}

        /// <summary>
        /// Adds the elements of the specified collection to the end of the <see cref="ICollection{T}"/>.
        /// </summary>
        /// <typeparam name="T">The type of the items that the collection contains.</typeparam>
        /// <param name="source">The collection to add the elements.</param>
        /// <param name="collection">The collection whose elements should be added to the end of the
        /// <see cref="ICollection{T}"/>.</param>
        public static void AddRange<T>(this ICollection<T> source, IEnumerable<T> collection)
        {
            foreach (var item in collection)
            {
                source.Add(item);
            }
        }

        /// <summary>
        /// Extension method to set the selection to the ModelExplorer
        /// </summary>
        /// <param name="modelExplorerService">ModelExplorer service</param>
        /// <param name="selectedElement">element to be selected</param>
        //public static void SetSelection(this IModelExplorerService modelExplorerService, IElement selectedElement)
        //{
        //    if (modelExplorerService == null) throw new ArgumentNullException("modelExplorerService");
        //    if (modelExplorerService == null) throw new ArgumentNullException("selectedElement");

        //    MainUserControl modelExplorer = modelExplorerService.UserControl as MainUserControl;
        //    Debug.Assert(modelExplorer != null);

        //    MethodInfo findViewNodeByReference = typeof(ViewNode).GetMethod("FindViewNodeByReference",
        //                                                BindingFlags.NonPublic | BindingFlags.Instance);
        //    Debug.Assert(findViewNodeByReference != null, "Cannot find ViewNode.FindViewNodeByReference! SetSelection cannot continue ");

        //    PropertyInfo viewNodeReferenceInternal = typeof(ViewNode).GetProperty("ReferenceInternal", BindingFlags.NonPublic | BindingFlags.Instance);
        //    Debug.Assert(viewNodeReferenceInternal != null, "Cannot find ViewNode.ReferenceInternal SetSelection cannot continue ");

        //    // Don't continue when you can't find any of the reflection method/property.
        //    if (modelExplorer != null && findViewNodeByReference != null && viewNodeReferenceInternal != null)
        //    {
        //        ModelStoreTreeView treeView = modelExplorer.FindName("treeView") as ModelStoreTreeView;
        //        Debug.Assert(treeView != null, "Cannot find ModelStoreTreeView in the modelExplorer! Is the name changed?");

        //        if (treeView != null && treeView.Items.MoveCurrentToFirst())
        //        {
        //            // The FindViewNodeByReference method is designed to search the entire root in ME
        //            // To support multiple modeling projects, we will loop thru all the root in the ME
        //            do
        //            {
        //                ViewNode eachRootNode = treeView.Items.CurrentItem as ViewNode;

        //                // See if the selectedElement is the root. In this case, we want to select the root node.
        //                IElement eachRoot = viewNodeReferenceInternal.GetValue(eachRootNode, null) as IElement;

        //                ViewNode elementViewNode = (selectedElement == eachRoot) ?
        //                                            eachRootNode : findViewNodeByReference.Invoke(eachRootNode, new object[] { selectedElement }) as ViewNode;

        //                if (elementViewNode != null)
        //                {
        //                    SelectExplorerNode(modelExplorer, elementViewNode);
        //                    treeView.Focus();
        //                    break;
        //                }
        //            }
        //            while (treeView.Items.MoveCurrentToNext());
        //        }
        //    }
        //}

        /// <summary>
        /// Extension method to get the selection in the ModelExplorer
        /// </summary>
        /// <param name="modelExplorerService">ModelExplorer service</param>
        //public static IElement GetSelection(this IModelExplorerService modelExplorerService)
        //{
        //    if (modelExplorerService == null) throw new ArgumentNullException("modelExplorerService");

        //    MainUserControl modelExplorer = modelExplorerService.UserControl as MainUserControl;
        //    Debug.Assert(modelExplorer != null);

        //    PropertyInfo selectedTreeViewItem = modelExplorer.GetType().GetProperty("SelectedTreeViewItem", BindingFlags.NonPublic | BindingFlags.Instance);
        //    Debug.Assert(selectedTreeViewItem != null, "Should be able to find property SelectedTreeViewItem");
        //    ModelElementTreeViewItem viewItem = (selectedTreeViewItem != null) ? selectedTreeViewItem.GetValue(modelExplorer, null) as ModelElementTreeViewItem : null;
        //    if (viewItem != null)
        //    {
        //        ViewNode selectedViewNode = viewItem.DataContext as ViewNode;
        //        PropertyInfo viewNodeReferenceInternal = typeof(ViewNode).GetProperty("ReferenceInternal", BindingFlags.NonPublic | BindingFlags.Instance);
        //        Debug.Assert(viewNodeReferenceInternal != null && selectedViewNode != null, "selectedViewNode and viewNodeReferenceInternal both should not be null!");
        //        if (viewNodeReferenceInternal != null && selectedViewNode != null)
        //        {
        //            return viewNodeReferenceInternal.GetValue(selectedViewNode, null) as IElement;
        //        }
        //    }
        //    return null;
        //}

        /// <summary>
        /// Does the heavy lifting associated with selecting <paramref name="elementViewNode"/> in the 
        /// UML Model Explorer
        /// </summary>
        /// <param name="modelExplorer">The actual control</param>
        /// <param name="elementViewNode">The node to select</param>
        //private static void SelectExplorerNode(MainUserControl modelExplorer, ViewNode elementViewNode)
        //{
        //    // BringTreeViewItemIntoView will ensure that the selected item in the tree is properly scrolled into
        //    // view so that the user can see the selection
        //    MethodInfo bringTreeViewIntoView = typeof(MainUserControl).GetMethod("BringTreeViewItemIntoView", BindingFlags.NonPublic | BindingFlags.Instance);
        //    Debug.Assert(bringTreeViewIntoView != null, "reflection on MainUserControl.BringTreeViewItemIntoView is null?");

        //    PropertyInfo selectedTreeViewItem = modelExplorer.GetType().GetProperty("SelectedTreeViewItem", BindingFlags.NonPublic | BindingFlags.Instance);
        //    Debug.Assert(selectedTreeViewItem != null, "reflection on ModelExplorer.SelectedTreeViewItem is null?");
        //    if (selectedTreeViewItem == null || bringTreeViewIntoView == null)
        //    {
        //        return;
        //    }

        //    // Attach the element ViewNode to a TreeViewItem...
        //    ModelElementTreeViewItem viewItem = new ModelElementTreeViewItem();
        //    viewItem.DataContext = elementViewNode;

        //    elementViewNode.IsSelected = true;

        //    selectedTreeViewItem.SetValue(modelExplorer, viewItem, null);
        //    bringTreeViewIntoView.Invoke(modelExplorer, new object[] { elementViewNode, viewItem });
        //}
	}
}