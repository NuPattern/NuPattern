﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Design;
using System.Drawing;
using Microsoft.VisualStudio.Modeling.Integration;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	/// <summary>
	/// Exposes registration information for an adapter.
	/// </summary>
	public class AdapterRegistration : IAdapterRegistration
	{
		/// <summary>
		/// Gets the adapter manager associated with the adapter.
		/// </summary>
		public ModelBusAdapterManager AdapterManager { get; set; }

		/// <summary>
		/// Gets the attribute that specifies additional metadata about 
		/// the model represented by the template.
		/// </summary>
		public ModelTemplateAttribute ModelTemplate { get; set; }

		/// <summary>
		/// The identifier for the adapter.
		/// </summary>
		public string AdapterId { get; set; }

		/// <summary>
		/// Gets the adapter type.
		/// </summary>
		public Type AdapterType { get; set; }

		/// <summary>
		/// Exposes the root of a diagram of the adapted type.
		/// </summary>
		public SupportedType RootModel { get; set; }

		/// <summary>
		/// Exposes the elements that the adapter exposes.
		/// </summary>
		public IEnumerable<SupportedType> SupportedElements { get; set; }
	}
}
