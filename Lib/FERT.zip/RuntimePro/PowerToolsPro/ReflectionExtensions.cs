﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	/// <summary>
	/// Miscelaneous extensions to facilitate reflection.
	/// </summary>
	public static class ReflectionExtensions
	{
		/// <summary>
		/// Finds a base type in the given <paramref name="source"/> that 
		/// matches the given <paramref name="typeToMatch"/>, which can be 
		/// the generic type definition of a base class used by the <paramref name="source"/>.
		/// </summary>
		/// <param name="source">The type to search for base types.</param>
		/// <param name="typeToMatch">Type to match, which can be a generic type definition such as <c>typeof(IList&lt;&gt;)</c></param>
		/// <returns>The type found, or <see langword="null"/>.</returns>
		public static Type FindBase(this Type source, Type typeToMatch)
		{
			var condition = typeToMatch.IsGenericTypeDefinition ?
					(Predicate<Type>)(t => t.IsGenericType && t.GetGenericTypeDefinition() == typeToMatch) :
					(Predicate<Type>)(t => t == typeToMatch);

			return source.Traverse(t => t.BaseType, condition);
		}

		/// <summary>
		/// Provides direct access to the value of the <see cref="DisplayNameAttribute"/> if present.
		/// </summary>
		/// <param name="provider">Any type implementing the interface, which can be an assembly, type, 
		/// property, method, etc.</param>
		/// <param name="inherit">Optionally, whether the attribute will be looked in base classes.</param>
		/// <returns>The attribute value if defined; <see langword="null"/> otherwise.</returns>
		public static string DisplayName(this ICustomAttributeProvider provider, bool inherit = true)
		{
			var attribute = GetCustomAttribute<DisplayNameAttribute>(provider, inherit);
			if (attribute != null)
				return attribute.DisplayName;

			return null;
		}

		/// <summary>
		/// Provides direct access to the value of the <see cref="DescriptionAttribute"/> if present.
		/// </summary>
		/// <param name="provider">Any type implementing the interface, which can be an assembly, type, 
		/// property, method, etc.</param>
		/// <param name="inherit">Optionally, whether the attribute will be looked in base classes.</param>
		/// <returns>The attribute value if defined; <see langword="null"/> otherwise.</returns>
		public static string Description(this ICustomAttributeProvider provider, bool inherit = true)
		{
			var attribute = GetCustomAttribute<DescriptionAttribute>(provider, inherit);
			if (attribute != null)
				return attribute.Description;

			return null;
		}

		/// <summary>
		/// Retrieves the first defined attribute of the given type from the provider if any.
		/// </summary>
		/// <typeparam name="TAttribute">Type of the attribute, which must inherit from <see cref="Attribute"/></typeparam>
		/// <param name="provider">Any type implementing the interface, which can be an assembly, type, 
		/// property, method, etc.</param>
		/// <param name="inherit">Optionally, whether the attribute will be looked in base classes.</param>
		/// <returns>The attribute instance if defined; <see langword="null"/> otherwise.</returns>
		public static TAttribute GetCustomAttribute<TAttribute>(this ICustomAttributeProvider provider, bool inherit = true)
			where TAttribute : Attribute
		{
			return GetCustomAttributes<TAttribute>(provider, inherit).FirstOrDefault();
		}

		/// <summary>
		/// Retrieves the first defined attribute of the given type from the provider if any.
		/// </summary>
		/// <typeparam name="TAttribute">Type of the attribute, which must inherit from <see cref="Attribute"/></typeparam>
		/// <param name="provider">Any type implementing the interface, which can be an assembly, type, 
		/// property, method, etc.</param>
		/// <param name="inherit">Optionally, whether the attribute will be looked in base classes.</param>
		/// <returns>The attribute instance if defined; <see langword="null"/> otherwise.</returns>
		public static IEnumerable<TAttribute> GetCustomAttributes<TAttribute>(this ICustomAttributeProvider provider, bool inherit = true)
			where TAttribute : Attribute
		{
			return provider
				.GetCustomAttributes(inherit)
				.OfType<TAttribute>();
		}
	}
}