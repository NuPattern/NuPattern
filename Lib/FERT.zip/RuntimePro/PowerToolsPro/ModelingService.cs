﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Modeling.Integration;
using Microsoft.VisualStudio.Modeling.Integration.Shell;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Properties;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{

    ///  class to implement IModelingService interface. Also exports interface IModelingService.

    [Export(typeof(IFxrModelingService))]
    public class ModelingService : IFxrModelingService
    {
        /// <summary>
        /// Struct for temporary holding query results. Used for holding the temporary result. Never meant to be return outside this class
        /// </summary>
        internal struct TransientModelBusReferenceResult<TElement>
        {
            public ModelBusReference ModelBusReference;
            public ModelingAdapter ModelingAdapter;
            public TElement Element;
            public TransientModelBusReferenceResult(ModelingAdapter modelingAdapter, ModelBusReference modelBusReference, TElement element)
            {
                this.ModelingAdapter = modelingAdapter;
                this.ModelBusReference = modelBusReference;
                this.Element = element;
            }
        }

        #region fields
        private IModelBus bus;
        private ISolution solutionProvider;
        private IEnumerable<AdapterRegistration> registeredManagers;

        #endregion

        /// <summary>
        ///   ModelingService ctor
        /// </summary>
        /// <param name="serviceProviderForModelBus">model bus service provider</param>
        /// <param name="importedManagers">imported model bus adapter managers</param>

        [ImportingConstructor]
        public ModelingService(
            [Import(typeof(SVsServiceProvider), AllowDefault = true)]IServiceProvider serviceProviderForModelBus,
            ISolution solutionProvider,
            [ImportMany]IEnumerable<ModelBusAdapterManager> importedManagers,
           [Import(AllowDefault = true)]IFxrTemplateService templateService)
            : this((IModelBus)serviceProviderForModelBus.GetService(typeof(SModelBus)),
                solutionProvider, importedManagers, templateService)
        {
        }

        /// <summary>
        ///   ModelingService ctor
        /// </summary>
        /// <param name="bus">model bus</param>
        /// <param name="importedManagers">imported model bus adapter managers</param>

        public ModelingService(
            IModelBus bus,
            ISolution solutionProvider,
            [ImportMany]IEnumerable<ModelBusAdapterManager> importedManagers,
            IFxrTemplateService templateService)
        {
            Guard.NotNull(() => bus, bus);
            Guard.NotNull(() => solutionProvider, solutionProvider);
            Guard.NotNull(() => importedManagers, importedManagers);
            Guard.NotNull(() => templateService, templateService);

            this.bus = bus;
            this.solutionProvider = solutionProvider;

            IEnumerable<AdapterRegistration> results = (from manager in importedManagers
                                                        from adapterId in manager.GetSupportedLogicalAdapterIds()
                                                        let adapterType = FindAdapterType(manager, adapterId)
                                                        where adapterType != null && IsStandardModelingAdapter(adapterType)
                                                        let rootModelType = GetSupportedRootType(manager, adapterType, adapterId)
                                                        select new AdapterRegistration
                                                        {
                                                            AdapterManager = manager,
                                                            AdapterId = adapterId,
                                                            AdapterType = adapterType,
                                                            // This may remain null, in which case CreateDiagram might throw.
                                                            // Note that the presence of this attribute is verified by our 
                                                            // own ModelingAdapterManager constructor, so this will only 
                                                            // happen for VsModelingAdapterManager-derived classes that 
                                                            // don't inherit from ours.
                                                            ModelTemplate = manager.GetType().GetCustomAttribute<ModelTemplateAttribute>(),
                                                            RootModel = rootModelType,
                                                            SupportedElements = manager.GetExposedElementTypes(adapterId),
                                                        });
            this.registeredManagers = results.Distinct(new RegistrationEqualityComparer());

           
            this.Templates = templateService;
        }

        /// <summary>
        ///   Returns ModelBus of this ModelingService 
        /// </summary>

        public IModelBus ModelBus
        {
            [DebuggerStepThrough]
            get { return bus; }
        }

        /// <summary>
        ///   Returns ITemplateService of this ModelingService 
        /// </summary>
        protected IFxrTemplateService Templates { get; set; }

        /// <summary>
        ///   Loads all the elements matching the given root element type under the given scope
        /// </summary>
        /// <typeparam name="TRoot">root element type of interest</typeparam>
        /// <param name="scope">search scope </param>
        /// <returns>Collection of ModelBusReferences</returns>
        public IEnumerable<ModelBusReference> All<TRoot>(Scope scope = Scope.Solution)
        {
            IEnumerable<IItem> items = FindItems(scope);
            return FindModelBusReferences<TRoot>(items);


            #region Equivalent non-LINQ procedural code.
            //    foreach (var item in items)
            //    {
            //        var managers = bus.FindAdapterManagers(item.Path).ToList();
            //        foreach (var manager in managers)
            //        {
            //            if (manager.CanCreateReference(item.Path))
            //            {
            //                var adapterIds = manager.GetSupportedAdapterTypeIds().ToList();
            //                foreach (var adapterId in adapterIds)
            //                {
            //                    var supportedTypes = manager.GetExposedElementTypes(adapterId).ToList();
            //                    foreach (var supportedType in supportedTypes)
            //                    {
            //                        if (typeof(TRoot).IsAssignableFrom(supportedType.Type))
            //                        {
            //                            var adapter = manager.CreateAdapter(new ModelBusReference(bus, adapterId, item.Name,
            //                               new ModelingAdapterReference(null, null, item.Path))) as ModelingAdapter;
            //                            if (adapter != null)
            //                            {
            //                                var elementRefs = adapter.GetElementReferences(typeof(TRoot));
            //                                foreach (var elementRef in elementRefs)
            //                                {
            //                                    var element = (TRoot)adapter.ResolveElementReference(elementRef);
            //                                    if (element is ModelElement)
            //                                    {
            //                                        yield return new Adapted<TRoot>(element, elementRef) { Adapter = adapter };
            //                                    }
            //                                }
            //                            }
            //                        }
            //                    }
            //                }
            //            }
            //        }
            #endregion
        }

        ///   Loads all the elements matching the given root element type and the path specification.
        /// </summary>
        /// <typeparam name="TRoot">root element type of interest</typeparam>
        /// <param name="pathExpression">A regular expression that is matched against the items as a path (i.e. Project1\Item.cs).</param>
        /// <returns>ModelBusReference collection</returns>
        public IEnumerable<ModelBusReference> All<TRoot>(string pathExpression)
        {
            var items = solutionProvider.Find(pathExpression).OfType<IItem>().Distinct();

            return FindModelBusReferences<TRoot>(items);

        }


        /// <summary>
        /// For the given scope, this method tries to find all the items in it.
        /// </summary>
        /// <param name="scope">search scope</param>
        /// <returns>Found items</returns>
        private IEnumerable<IItem> FindItems(Scope scope)
        {
            var projects = solutionProvider.Items
                .Traverse(i => i.Items)
                .Where(i => i.Kind == ItemKind.Project);

            if (scope == Scope.Selection)
                projects = projects.Where(p => p.IsSelected);

            var items = projects
                    .Traverse(i => i.Items)
                    .OfType<IItem>()
                    .Distinct();

            return items;
        }

        /// <summary>
        /// for the given item collection, this method tries to find all the TRoot type from the adapter created by each item
        /// </summary>
        /// <typeparam name="TRoot"></typeparam>
        /// <param name="items"></param>
        /// <returns></returns>
        private IEnumerable<ModelBusReference> FindModelBusReferences<TRoot>(IEnumerable<IItem> items)
        {
            // Find all diagram MBRs.
            IEnumerable<ModelBusReference> allDiagramMBRs = (from item in items
                                                             from adapterManager in bus.FindAdapterManagers(item.PhysicalPath)
                                                             where adapterManager.CanCreateReference(item.PhysicalPath)
                                                             from adapterId in adapterManager.GetSupportedLogicalAdapterIds()
                                                             select new ModelBusReference(bus, adapterId, item.Name,
                                                                     new ModelingAdapterReference(null, null, item.PhysicalPath)));
            foreach (ModelBusReference mbr in allDiagramMBRs)
            {
                using (var busAdapter = this.bus.CreateAdapter(mbr))
                {
                    ModelingAdapter modelingAdapter = busAdapter as ModelingAdapter;
                    if (modelingAdapter != null)
                    {
                        foreach (ModelBusReference eachMBR in modelingAdapter.GetElementReferences(typeof(TRoot)))
                        {
                            yield return eachMBR;
                        }
                    }
                }
            }
        }

        //public IEnumerable<ModelBusReference> Find<TRoot, TElement>(Func<TRoot, IEnumerable<TElement>> query, Scope scope = Scope.Solution)
        //{
        //    IEnumerable<IItem> items = FindItems(scope);

        //    return from TransientModelBusReferenceResult<TRoot> rootModel in CreateAdapters<TRoot>(items)
        //           from element in query(rootModel.Element)
        //           // We need model element instances 
        //           // This also prevents a query function that 
        //           // returns unsupported or invalid elements.
        //           let mel = element as ModelElement
        //           where mel != null
        //           // All<T> always filters out the ones that are not modeling adapters
        //           select new ModelBusReference(
        //                   this.ModelBus,
        //                   rootModel.ModelBusReference.LogicalAdapterId,
        //                   rootModel.ModelingAdapter.DisplayName,
        //                   GetElementDisplayName(rootModel.ModelingAdapter, mel),
        //                   new ModelingAdapterReference(
        //                           mel.Id.ToString(), null, rootModel.ModelingAdapter.DocumentHandler.ModelFile)
        //                   );

        //}

        private IEnumerable<TransientModelBusReferenceResult<TRoot>> CreateAdapters<TRoot>(IEnumerable<IItem> items)
        {
            return (from item in items
                    from adapterManager in bus.FindAdapterManagers(item.PhysicalPath)
                    where adapterManager.CanCreateReference(item.PhysicalPath)
                    from adapterId in adapterManager.GetSupportedLogicalAdapterIds()
                    let mbr = new ModelBusReference(bus, adapterId, item.Name,
                         new ModelingAdapterReference(null, null, item.PhysicalPath))
                    let busAdapter = bus.CreateAdapter(mbr)
                    let adapter = busAdapter as ModelingAdapter

                    // For consistency with Find, we need to restrict to modeling adapters only.
                    where adapter != null
                    from elementRef in busAdapter.GetElementReferences(typeof(TRoot))
                    let adapterRef = elementRef.AdapterReference

                    let element = (TRoot)adapter.ResolveElementReference(elementRef)
                    select new TransientModelBusReferenceResult<TRoot>(adapter, elementRef, element));
        }


        //private string GetElementDisplayName(ModelingAdapter adapter, ModelElement mel)
        //{
        //    var typedAdapter = adapter as IProvideElementDisplayName;
        //    if (typedAdapter != null)
        //        return typedAdapter.GetDisplayName(mel);

        //    string name = null;
        //    if (!DomainClassInfo.TryGetName(mel, out name))
        //        name = mel.GetDomainClass().DisplayName;

        //    return name;
        //}

        
        /// <summary>
        ///   Helper method to resolve element designated by the ModelBusReference
        /// </summary>
        /// <typeparam name="T">elemene type</typeparam>
        /// <param name="reference">ModelBusReference</param>
        /// <returns>resolved element</returns>
        public T Resolve<T>(ModelBusReference reference)
        {
            // Throws ArgumentException if manager for ID is not registered.
            // This is IModelBus behavior.
            //var manager = bus.GetAdapterManager(reference.AdapterTypeId);
            // CreateAdapter throws AdapterCreationException if adapter cannot be created, 
            // so we know it succeeded. If we end up with a null modelingAdapter variable 
            // it's because it was not a modeling adapter.
            try
            {
                using (ModelBusAdapter busAdapter = bus.CreateAdapter(reference))
                {
                    var modelingAdapter = busAdapter as ModelingAdapter;

                    if (modelingAdapter == null)
                    {
                        throw new ArgumentException(String.Format(
                                                    CultureInfo.CurrentCulture,
                                                    Resources.ModelingService_RegisteredAdapterNotModelingAdapter,
                                                    reference.LogicalAdapterId));
                    }

                    var element = modelingAdapter.ResolveElementReference(reference);

                    if (element is T)
                    {
                        return (T)element;
                    }
                    else
                    {
                        throw new ArgumentException(String.Format(
                                                    CultureInfo.CurrentCulture,
                                                    Properties.Resources.ModelingService_IncompatibleType,
                                                    typeof(T), element.GetType()));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ArgumentException(String.Format(
                    CultureInfo.CurrentCulture,
                    Properties.Resources.ModelingService_CantCreateAdapterFromReference,
                    reference.ToString()), ex);
            }
        }

        /// <summary>
        /// Exposes the registration information for adapter managers that 
        /// </summary>
        public IEnumerable<IAdapterRegistration> RegisteredAdapters
        {
            get { return registeredManagers; }
        }

        /// <summary>
        ///   Open the model of the given path.
        /// </summary>
        /// <typeparam name="TRootModel">Root model type</typeparam>
        /// <param name="path">path to the diagram file</param>
        /// <returns>Root model</returns>
        public Model<TRootModel> OpenModel<TRootModel>(string path)
        {
            if (!File.Exists(path))
                throw new FileNotFoundException("The model file could not be found.", path);

            var manager = this.ModelBus.FindAdapterManagers(path).FirstOrDefault();
            if (manager == null)
                throw new ArgumentException(string.Format("The Adapter Manager for the model '{0}' could not be found", path));

            var reference = manager.CreateReference(path);

            try
            {
                using (var adapter = this.ModelBus.CreateAdapter(reference))
                {

                    var view = adapter.GetDefaultView();
                    view.SetSelection(reference);
                    view.Open();
                    view.Show();

                    var standardVsModelingDiagramView = view as StandardVsModelingDiagramView;
                    Diagram diagram = standardVsModelingDiagramView != null ? standardVsModelingDiagramView.Diagram : null;


                    if (diagram != null)
                    {
                        return new Model<TRootModel>(diagram);
                    }

                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(String.Format(
                    CultureInfo.CurrentCulture,
                    Properties.Resources.ModelingService_CantCreateAdapterFromReference,
                    reference.ToString()), ex);
            }
        }

        /// <summary>
        ///  Creates and adds a new model to the solution.
        /// </summary>
        /// <typeparam name="TRootModel">The root type of the model</typeparam>
        /// <param name="name">The name of the model</param>
        /// <param name="path">The path where the model will be created.</param>
        /// <param name="kind">The kind of model to be created. If kind is not specified the first model assignable to TRootModel will be used.</param>
        /// <returns>The model</returns>
        public Model<TRootModel> CreateModel<TRootModel>(string name, string path = "", string kind = "")
        {
            // Find parent item
            IItemContainer parentItem = null;
            if (!string.IsNullOrEmpty(path) && Path.IsPathRooted(path))
            {
                parentItem = solutionProvider.Find(path.Remove(0, Path.GetPathRoot(path).Length)).FirstOrDefault();
            }
            else
            {
                parentItem = solutionProvider.GetSelection().FirstOrDefault();

                if (parentItem != null && !string.IsNullOrEmpty(path))
                {
                    parentItem = parentItem.Find(path).FirstOrDefault();
                }
                else if (parentItem == null && !string.IsNullOrEmpty(path))
                {
                    parentItem = solutionProvider.Find(path).FirstOrDefault();
                }
            }

            if (parentItem == null)
                throw new InvalidOperationException(Resources.ModelingService_InvalidParentItem);

            // Find adapter
            AdapterRegistration adapter;
            if (!string.IsNullOrEmpty(kind))
            {
                adapter = this.registeredManagers.FirstOrDefault(manager => manager.RootModel.DisplayName == kind);

                if (adapter == null)
                {
                    throw new NotSupportedException(String.Format(
                        CultureInfo.CurrentCulture, Resources.ModelingService_UnsupportedKind, kind));
                }
            }
            else
            {
                adapter = this.registeredManagers.FirstOrDefault(manager => typeof(TRootModel).IsAssignableFrom(manager.RootModel.Type));


                if (adapter == null)
                {
                    throw new NotSupportedException(String.Format(
                        CultureInfo.CurrentCulture, Resources.ModelingService_UnsupportedRootModelType, typeof(TRootModel).FullName));
                }
            }

            if (!typeof(TRootModel).IsAssignableFrom(adapter.RootModel.Type))
            {
                throw new InvalidOperationException(String.Format(
                    CultureInfo.CurrentCulture, Resources.ModelingService_InvalidRootType, adapter.RootModel.Type.FullName, typeof(TRootModel).FullName));
            }

            Diagram diagram = this.CreateDiagram(name, adapter, parentItem);
            return new Model<TRootModel>(diagram);
        }



        /// <summary>
        /// Creates a new diagram under the first selected element in the current solution.
        /// </summary>
        /// <param name="modelName">Name for the new root model and its diagram.</param>
        /// <param name="registration"></param>
        /// <param name="parentItem">The container item to place the new model under.</param>
        protected virtual Diagram CreateDiagram(string modelName, AdapterRegistration registration, IItemContainer parentItem)
        {
            Guard.NotNullOrEmpty(() => modelName, modelName);
            Guard.NotNull(() => parentItem, parentItem);

            if (registration.ModelTemplate == null)
                throw new NotSupportedException(String.Format(
                    CultureInfo.CurrentCulture,
                    Properties.Resources.ModelingService_NoTemplateForNewDiagramProvided,
                    registration.AdapterManager.GetType(),
                    registration.RootModel.Type,
                    typeof(ModelTemplateAttribute)));

            var template = Templates.Find(registration.ModelTemplate.Name, registration.ModelTemplate.Category);
            if (template == null)
                throw new NotSupportedException(String.Format(
                    CultureInfo.CurrentCulture,
                    Properties.Resources.ModelingService_UnregisteredTemplate,
                    registration.AdapterManager.GetType(),
                    registration.RootModel.Type,
                    registration.ModelTemplate.Name,
                    registration.ModelTemplate.Category));

            var item = template.Unfold(modelName, parentItem);

            if (!registration.AdapterManager.CanCreateReference(item.PhysicalPath))
                throw new NotSupportedException(String.Format(
                    CultureInfo.CurrentCulture,
                    Properties.Resources.ModelingService_UnsupportedUnfoldedTemplateItem,
                    registration.ModelTemplate.Name,
                    registration.AdapterManager.GetType(),
                    registration.AdapterType));

            var adapterReference = new ModelingAdapterReference(null, null, item.PhysicalPath);
            var busReference = new ModelBusReference(bus,
                    registration.AdapterId, modelName, adapterReference);

            // There seems to be an issue in the model bus as the service provider is not being 
            // passed to the adapter manager, and therefore seems like some code paths are not being reached.
            // See Connect FeedbackID=464998
            ModelBusAdapter adapter;
            try
            {
                adapter = bus.CreateAdapter(busReference);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(String.Format(
                    CultureInfo.CurrentCulture,
                    Properties.Resources.ModelingService_CantCreateAdapterForItem,
                    item.PhysicalPath, registration.AdapterId), ex);
            }

            using (adapter)
            {
                // Note that our adapters are always StandardModelingAdapter<T>, 
                // as we filter the rest in the constructor.
                var standardModelingView = adapter.GetDefaultView() as StandardVsModelingDiagramView;
                if (standardModelingView == null)
                    throw new NotSupportedException(String.Format(
                        CultureInfo.CurrentCulture,
                        Properties.Resources.ModelingService_UnsupportedDiagramView,
                        adapter.GetType()));

                return standardModelingView.Diagram;
            }
        }


        private Type FindAdapterType(ModelBusAdapterManager manager, string adapterId)
        {
            // If manager inherits from our modeling one, get the type from its 
            // generic argument
            var modelingType = manager.GetType().FindBase(typeof(ModelingAdapterManager<,>));
            if (modelingType != null)
                return modelingType.GetGenericArguments()[0];

            // We assume adapter managers use [HandlesAdapter(typeof(MyAdapter))] 
            // registration form. This way, we can get at the adapter 
            // using its adapterId as the full type name, which we assume 
            // lives in the same assembly as its adapter manager, and is public.
            var adapterType = manager.GetType().Assembly.GetType(adapterId, false);

            // There may be no custom adapter and just an instance of our own 
            // generic one.
            if (adapterType == null)
                adapterType = Assembly.GetExecutingAssembly().GetType(adapterId, false);

            if (adapterType == null)
                Debug.WriteLine("Could not infer adapter type for manager {0} from adapter id {1}", manager.GetType(), adapterId);

            return adapterType;
        }

        private bool IsStandardModelingAdapter(Type adapterType)
        {
            var isStandard = FindStandardModelingAdapterBase(adapterType) != null;
            if (!isStandard)
                Debug.WriteLine("Adapter type {0} does not derive directly or indirectly from {1} and will be ignored by the service.",
                        adapterType, typeof(StandardModelingAdapter));

            return isStandard;
        }

        private SupportedType GetSupportedRootType(ModelBusAdapterManager manager, Type adapterType, string adapterId)
        {
            // Will never be null as we're already filtering from the ctor 
            // the adapter types that are standard modeling adapters.
            var standardModelingType = FindStandardModelingAdapterBase(adapterType);
            Debug.Assert(standardModelingType != null, "adapterType's base type should not be null");

            PropertyInfo propInfo = manager.GetType().GetProperty("RootModelType", BindingFlags.NonPublic | BindingFlags.Instance);
            // Note propInfo can be null when the manager is not derived from ModelingAdapterManager<TAdapter, TRootModel> 
            // a descendent of ModelBusAdapterManager. Hence, only use reflection when we can find the property
            SupportedType rootType = null;
            if (propInfo != null)
            {
                rootType = propInfo.GetValue(manager, null) as SupportedType;
            }
            else
            {
                //// The StandardModelingAdapter is not generic anymore.
                //// We are assuming that the first exposed element is the root element
                rootType = manager.GetExposedElementTypes(adapterId).FirstOrDefault();
            }

            return rootType;
        }

        private Type FindStandardModelingAdapterBase(Type adapterType)
        {
            if (adapterType == typeof(object)) return null;

            var baseType = adapterType.BaseType;

            if (baseType == typeof(StandardModelingAdapter))
                return baseType;
            else
                return FindStandardModelingAdapterBase(baseType);
        }

        private class RegistrationEqualityComparer : IEqualityComparer<AdapterRegistration>
        {
            public bool Equals(AdapterRegistration x, AdapterRegistration y)
            {
                return x.RootModel.Type == y.RootModel.Type;
            }

            public int GetHashCode(AdapterRegistration x)
            {
                int templateNameHash = (x.ModelTemplate != null) ? x.ModelTemplate.Name.GetHashCode() + x.ModelTemplate.Category.GetHashCode() :
                       0;
                return x.AdapterManager.GetHashCode() ^
                        templateNameHash ^
                        x.AdapterType.GetHashCode() ^
                        x.RootModel.Type.GetHashCode();
            }
        }
    }
}
