﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
		/// <summary>
		/// Enables the corresponding annotated adapter manager to participate 
		/// in new model creation via <see cref="IFxrModelingService.CreateDiagram(string, Type)"/>.
		/// </summary>
		[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
		public class ModelTemplateAttribute : Attribute
		{
				/// <summary>
				/// Initializes the template attribute.
				/// </summary>
				/// <param name="templateName">Template name matches the .zip file that contains it.</param>
				/// <param name="category">Project type is the one specified as the ProjectType XML element 
				/// in the .vstemplate inside the .zip file specified as <paramref name="templateName"/>.</param>
				public ModelTemplateAttribute(string templateName, string category)
				{
						this.Name = templateName;
						this.Category = category;
				}

				/// <summary>
				/// The name of the template associated with the annotated adapter manager.
				/// </summary>
				public string Name { get; private set; }

				/// <summary>
				/// Category of the template, which must match the one specified as the ProjectType XML element 
				/// in the .vstemplate inside the .zip file specified as the template <see cref="Name"/>.
				/// </summary>
				public string Category { get; private set; }
		}
}
