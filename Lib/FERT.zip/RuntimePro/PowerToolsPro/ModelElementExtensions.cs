﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;
using System.Diagnostics.Contracts;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	/// <summary>
	/// Provides extension methods for <see cref="ModelElement"/>
	/// </summary>
	public static class ModelElementExtensions
	{
		/// <summary>
		/// Returns the most inmediate ancestor of the element that 
		/// supports the given type <typeparamref name="T"/>.
		/// </summary>
		/// <typeparam name="T">The type of the parent element to find</typeparam>
        /// <param name="modelElement">A direct child or descendent of the element to find</param>
        /// <returns>The most inmediate ancestor of the model element or null.</returns>
        public static T GetParent<T>(this ModelElement modelElement)
            where T : ModelElement
        {
            if (modelElement != null)
            {
                ModelElement parent = DomainClassInfo.FindEmbeddingElement(modelElement);
				// Walk the "Linked Package" relationship as a parent of the element, if available
				if (parent == null)
				{
					try
					{
						dynamic dynModel = modelElement;
						parent = dynModel.LinkedPackage as ModelElement;
					}
					catch (Exception)
					{
					}
				}

                return parent != null && typeof(T).IsAssignableFrom(parent.GetType()) ? (T)parent : GetParent<T>(parent);
            }

            return null;
        }

		/// <summary>
		/// Returns the shape of the model element
		/// </summary>
		/// <typeparam name="T">The shape type</typeparam>
		/// <param name="element">The model element</param>
		/// <returns>The shape</returns>
		public static T GetShape<T>(this ModelElement element)
			where T : ShapeElement
		{
			foreach (PresentationElement presentationElement in PresentationViewsSubject.GetPresentation(element))
			{
				T local = presentationElement as T;
				if (local != null)
				{
					return local;
				}
			}
			return default(T);
		}


		/// <summary>
		/// Creates a new element. The generic {T} parameter can be the concrete model element type or an interface.
		/// If {T} is an interface the first domain class implementing the interface will be used to create the element.
		/// </summary>
		/// <example>
		/// <code>
		/// IModel model = ...;
		/// model.Create&lt;Class&gt;() // An instance of Class will be created
		/// 	 .Create&lt;ClassOperation();
		/// </code>
		/// </example>
		/// <typeparam name="T">The target model element type</typeparam>
		/// <param name="parent">The parent of the element</param>
		/// <returns>A model element of type {T}</returns>
		public static T Create<T>(this ModelElement parent)
		{
			return parent.Create<T>(parent.Partition);
		}

		/// <summary>
		/// Creates a new element. The generic {T} parameter can be the concrete model element type or an interface.
		/// If {T} is an interface the first domain class implementing the interface will be used to create the element.
		/// </summary>
		/// <example>
		/// <code>
		/// IModel model = ...;
		/// model.Create&lt;Class&gt;() // An instance of Class will be created
		/// 	 .Create&lt;ClassOperation();
		/// </code>
		/// </example>
		/// <typeparam name="T">The target model element type</typeparam>
		/// <param name="parent">The parent of the element</param>
		/// <param name="partition">The partition where the element will be created</param>
		/// <returns>A model element of type {T}</returns>
		public static T Create<T>(this ModelElement parent, Partition partition)
		{
			T result;

			if (!parent.Store.TransactionManager.InTransaction)
			{
				using (Transaction transaction = parent.Store.TransactionManager.BeginTransaction("Creating: " + typeof(T).Name))
				{
					result = parent.DoCreate<T>(partition);

					transaction.Commit();
				}
			}
			else
			{
				result = parent.DoCreate<T>(partition);
			}

			return result;
		}

		private static T DoCreate<T>(this ModelElement parent, Partition partition)
		{
			Guard.NotNull(() => parent, parent);
			Guard.NotNull(() => partition, partition);

			ElementGroup elementGroup = new ElementGroup(parent.Partition);
			ModelElement element = null;
			DomainClassInfo domainClass = partition.DomainDataDirectory.DomainClasses
				.FirstOrDefault(domainClassInfo => typeof(T).IsAssignableFrom(domainClassInfo.ImplementationClass)
					&& !domainClassInfo.ImplementationClass.IsAbstract);

			if (domainClass != null)
			{
				element = partition.ElementFactory.CreateElement(domainClass);

				if (element != null)
				{
					elementGroup.Add(element);
					elementGroup.MarkAsRoot(element);
					new ElementOperations(parent.Store, parent.Partition).MergeElementGroup(parent, elementGroup);
				}
			}

			return element != null ? (T)(object)element : default(T);
		}
	}
}