﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using EnvDTE;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde
{
    internal static class VsHelper
    {
        static IServiceProvider serviceProvider;

        internal static void Initialize(IServiceProvider provider)
        {
            serviceProvider = provider;
        }

        internal static string GetActiveDocumentPath()
        {
            var activeDocument = GetActiveDocument();

            return activeDocument != null ? activeDocument.FullName : null;
        }

        internal static EnvDTE.Document GetActiveDocument()
        {
            AssertServiceProvider();

            var vs = serviceProvider.GetService(typeof(EnvDTE.DTE)) as EnvDTE.DTE;

            if (vs != null && vs.ActiveDocument != null)
            {
                return vs.ActiveDocument;
            }

            return null;
        }

        internal static void CheckOut(string filename)
        {
            if (File.Exists(filename) && File.GetAttributes(filename).HasFlag(FileAttributes.ReadOnly))
            {
                AssertServiceProvider();

                var vs = serviceProvider.GetService(typeof(EnvDTE.DTE)) as EnvDTE.DTE;

                if (vs != null && vs.SourceControl != null &&
                    vs.SourceControl.IsItemUnderSCC(filename) && !vs.SourceControl.IsItemCheckedOut(filename))
                {
                    vs.SourceControl.CheckOutItem(filename);
                }
                else
                {
                    File.SetAttributes(filename, FileAttributes.Normal);
                }
            }
        }

        private static void AssertServiceProvider()
        {
            if (serviceProvider == null)
            {
                throw new InvalidOperationException("The Service Provider of the VsHelper was not initialized");
            }
        }

        /// <summary>
        /// Selected item in the solution explorer based on given hierarchyNode
        /// </summary>
        public static void Select(IServiceProvider serviceProvider, IHierarchyNode hierarchyNode)
        {
            Select(serviceProvider, new[] { hierarchyNode });
        }

        /// <summary>
        /// Selected item in the solution explorer based on given hierarchyNode
        /// </summary>
        public static void Select(IServiceProvider serviceProvider, IEnumerable<IHierarchyNode> hierarchyNodes)
        {
            Debug.Assert(serviceProvider != null && hierarchyNodes != null);

            if (serviceProvider != null && hierarchyNodes != null)
            {
                var uiShell = serviceProvider.GetService(typeof(SVsUIShell)) as IVsUIShell;
                var slnExplorerGuid = new Guid(ToolWindowGuids80.SolutionExplorer);

                IVsWindowFrame frame;
                ErrorHandler.ThrowOnFailure(uiShell.FindToolWindow((uint)__VSFINDTOOLWIN.FTW_fForceCreate, ref slnExplorerGuid, out frame));

                object view;
                ErrorHandler.ThrowOnFailure(frame.GetProperty((int)__VSFPROPID.VSFPROPID_DocView, out view));

                bool first = true;
                var hierarchyWindow = view as IVsUIHierarchyWindow;
                if (hierarchyWindow != null)
                {
                    foreach (var hierarchyNode in hierarchyNodes)
                    {
                        hierarchyWindow.ExpandItem(hierarchyNode.GetObject<IVsHierarchy>() as IVsUIHierarchy,
                                                   hierarchyNode.ItemId,
                                                   first ? EXPANDFLAGS.EXPF_SelectItem : EXPANDFLAGS.EXPF_AddSelectItem);

                        if (first) first = false;
                    }
                }
                frame.Show();
            }
        }   
    }
}
