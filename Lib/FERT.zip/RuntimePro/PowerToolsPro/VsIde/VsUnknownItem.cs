﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde
{
	internal class VsUnknownItem : HierarchyItem
	{
        public VsUnknownItem(IServiceProvider serviceProvider, IHierarchyNode node)
            : base(serviceProvider, node)
        { }

		public override Microsoft.VisualStudio.TeamArchitect.PowerTools.ItemKind Kind
		{
			get { return ItemKind.Unknown; }
		}
	}
}
