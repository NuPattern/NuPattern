﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using EnvDTE;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde
{
	internal class VsItem : HierarchyItem, IItem
    {
		public VsItem(IServiceProvider serviceProvider, IHierarchyNode node)
            : base(serviceProvider, node)
        {
			this.Data = new VsItemDynamicProperties(node);
		}

		public dynamic Data { get; private set; }

        public override ItemKind Kind
        {
            get { return ItemKind.Item; }
        }

		public override string PhysicalPath
		{
			get
			{
				ProjectItem projectItem = (ProjectItem)ExtenderObject;
				return projectItem.get_FileNames(1);
			}
		}
    }
}
