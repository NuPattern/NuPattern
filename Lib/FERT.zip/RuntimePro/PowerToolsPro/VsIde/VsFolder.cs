﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;
using EnvDTE;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Properties;
using System.Globalization;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde
{
    internal class VsFolder: HierarchyItem, IFolder
    {
		public VsFolder(IServiceProvider serviceProvider, IHierarchyNode node)
            : base(serviceProvider, node)
        { }

        public override ItemKind Kind
        {
            get { return ItemKind.Folder; }
        }

		public IFolder CreateFolder(string name)
		{
			if (this.Items.Where(i => i.Name == name).FirstOrDefault() != null)
				throw new ArgumentException(String.Format(
					CultureInfo.CurrentCulture, Resources.VsIde_DuplicateItemName, this.Name, name));

			var item = (ProjectItem)base.ExtenderObject;

			item.ProjectItems.AddFolder(name, EnvDTE.Constants.vsProjectItemKindPhysicalFolder);

			return this.Items
				.OfType<IFolder>()
				.Where(folder => folder.Name == name)
				.Single();
		}

        /// <summary>
        /// implements IFolderContainer.Folders, returns the list of all solution folders in this container
        /// </summary>
        public IEnumerable<IFolder> Folders
        {
            get { return this.Items.OfType<IFolder>(); }
        }
	}
}
