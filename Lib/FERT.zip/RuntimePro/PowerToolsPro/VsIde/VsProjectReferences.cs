﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde
{
	internal class VsProjectReferences : HierarchyItem
	{
		public VsProjectReferences(IServiceProvider serviceProvider, IHierarchyNode node)
            : base(serviceProvider, node)
        { }

		public override ItemKind Kind
		{
			get { return ItemKind.ReferencesFolder; }
		}
	}
}
