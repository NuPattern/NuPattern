﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Integration;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Modeling;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    [Guid("17A7945A-996E-4815-8359-63713E4B5513")]    
    public interface IFxrModelingService
    {
        /// <summary>
        ///   Loads all the elements matching the given root element type under the given scope
        /// </summary>
        /// <typeparam name="TRoot">root element type of interest</typeparam>
        /// <param name="scope">search scope </param>
        /// <returns>Collection of ModelBusReferences</returns>
        IEnumerable<ModelBusReference> All<TRoot>(Scope scope = Scope.Solution);

        /// <summary>
        ///   Loads all the elements matching the given root element type and the path specification.
        /// </summary>
        /// <typeparam name="TRoot">root element type of interest</typeparam>
        /// <param name="pathExpression">A regular expression that is matched against the items as a path (i.e. Project1\Item.cs).</param>
        /// <returns>ModelBusReference</returns>
        IEnumerable<ModelBusReference> All<TRoot>(string pathExpression);

        ///// <summary>
        /////   Find the elements of the query results based on the given root element under the scope
        ///// </summary>
        ///// <typeparam name="TRoot">root element type of interest</typeparam>
        ///// <typeparam name="TRoot">query result element type</typeparam>
        ///// <param name="query">query fuction to be executed</param>
        ///// <param name="scope">search scope </param>
        ///// <returns>ModelBusReference</returns>
        //IEnumerable<ModelBusReference> Find<TRoot, TElement>(Func<TRoot, IEnumerable<TElement>> query, Scope scope = Scope.Solution);

        /// <summary>
        ///  Creates and adds a new model to the solution.
        /// </summary>
        /// <typeparam name="TRootModel">The root type of the model</typeparam>
        /// <param name="name">The name of the model</param>
        /// <param name="path">The path where the model will be created.</param>
        /// <param name="kind">The kind of model to be created. If kind is not specified the first model assignable to TRootModel will be used.</param>
        /// <returns>The model</returns>
        Model<TRootModel> CreateModel<TRootModel>(string name, string path = "", string kind = "");

        /// <summary>
        ///   Open the model of the given path.
        /// </summary>
        /// <typeparam name="TRootModel">Root model type</typeparam>
        /// <param name="path">path to the diagram file</param>
        /// <returns>Root model</returns>
        Model<TRootModel> OpenModel<TRootModel>(string path);

        /// <summary>
        ///   Helper method to resolve element designated by the ModelBusReference
        /// </summary>
        /// <typeparam name="T">elemene type</typeparam>
        /// <param name="reference">ModelBusReference</param>
        /// <returns>resolved element</returns>
        T Resolve<T>(ModelBusReference reference);

        /// <summary>
        ///   Returns the registered adapters.
        /// </summary>
        IEnumerable<IAdapterRegistration> RegisteredAdapters { get; }

        /// <summary>
        ///  Exposes the model bus that this services works on top of.
        /// </summary>
        IModelBus ModelBus { get; }
    }
}
