﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Integration;
using Microsoft.VisualStudio.Modeling;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	internal class ModelTransaction : ITransaction
	{
		Store store;
		Transaction modelTransaction;
		Transaction layoutTransaction;

		internal ModelTransaction(Store store, string transactioNname)
		{
			this.store = store;
			this.modelTransaction = CreateTransaction(transactioNname);
		}

		public void Abort()
		{
			this.modelTransaction.Rollback();
		}

		public void Commit()
		{
			// Subscribe to the model transaction committed event in order to create the Layout transaction
			this.store.EventManagerDirectory.TransactionCommitted.Add(this.modelTransaction.Id, 
				new EventHandler<TransactionCommitEventArgs>(OnModelTransactionComitted));
			try
			{
				this.modelTransaction.Commit();

				// The diagram elements (shapes) are created after the model transaction is committed.
				// So we need another transaction if we want to perform operation over those shapes
				if (this.layoutTransaction != null)
				{
					// Commit the layout transaction
					using (this.layoutTransaction)
					{
						this.layoutTransaction.Commit();
						this.layoutTransaction = null;
					}
				}
			}
			finally
			{
				this.store.EventManagerDirectory.TransactionCommitted.Remove(this.modelTransaction.Id,
					new EventHandler<TransactionCommitEventArgs>(OnModelTransactionComitted));
			}
		}

		public string Id
		{
			get { return this.modelTransaction.Id.ToString(); }
		}

		public void Dispose()
		{
			this.modelTransaction.Dispose();
		}

		private Transaction CreateTransaction(string transactionName)
		{
			return store.TransactionManager.BeginTransaction(transactionName); 
		}

		private void OnModelTransactionComitted(object sender, TransactionCommitEventArgs e)
		{
			this.layoutTransaction = CreateTransaction("Layout Transaction");
		}
	}
}