﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using EnvDTE;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Integration;
using Microsoft.VisualStudio.Modeling.Integration.Shell;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Properties;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    /// <summary>
    ///  Abstrat class for creating a adapter manager for Visual Studio Team Architect designers.
    /// </summary>
    /// <typeparam name="TAdapter">Adapter type, needs to be of type ModelingAdapter&lt;TRootModel&gt;</typeparam>
    /// <typeparam name="TRootModel">Root model of the designer</typeparam>
    public abstract class ModelingAdapterManager<TAdapter, TRootModel> : VsModelingAdapterManager
        where TRootModel : ModelElement
        where TAdapter : ModelingAdapter<TRootModel>
    {
        /// <summary>
        ///   Return the file extension where the AdapterManager is capable of handling
        /// </summary>
        protected string fileExtension;

        /// <summary>
        ///   ModelingAdapterManager ctor
        /// </summary>
        /// <param name="fileExtension">file extension where this adapater manager can manage</param>
        protected ModelingAdapterManager(string fileExtension)
        {
            Guard.NotNullOrEmpty(() => fileExtension, fileExtension);

            this.fileExtension = fileExtension;

            // Make sure the concrete adapter manager has the right HandlesAdapter attribute.
            var handles = this.GetType().GetCustomAttribute<HandlesAdapterAttribute>();
            if (handles == null)
            {
                var error = String.Format(
                    CultureInfo.CurrentCulture,
                    Resources.ModelingAdapterManager_MissingAttribute,
                        this.GetType(), typeof(ModelTemplateAttribute).Name);
                Debug.WriteLine(error);
                throw new InvalidOperationException(error);
            }

            // Ensure that handles.LogicalAdapterId is amongst the GetSupportedLogicalAdapterIds() collection.
            // Notice that we're using short name in the GetSupportedLogicalAdapterIds list. Howerver, we can declare modeling manager which looks
            // [HandlesAdapter(typeof(ModelingAdapter<FooModel>))]
            // public class FooManager : ModelingAdapterManager<ModelingAdapter<FooModel>, FooModel> {}
            // In this case, handles.LogicalAdapterId is really a long name (constructed in the DSL runtime). Hence, we're doing a substring search here!
            if (!this.GetSupportedLogicalAdapterIds().Where(eachAdapter => handles.LogicalAdapterId.IndexOf(eachAdapter) != (-1)).Any())
            {
                var error = String.Format(
                    CultureInfo.CurrentCulture,
                    Resources.ModelingAdapterManager_InvalidHandlesAdapterAttribute,
                    this.GetType(), typeof(HandlesAdapterAttribute).Name, typeof(TAdapter).Name);
                Debug.WriteLine(error);
                throw new InvalidOperationException(error);
            }
        }

        /// <summary>
        ///   Create instance of ModelingAdapter based on reference and rootModel
        /// </summary>
        /// <param name="reference">reference to the adapter</param>
        /// <param name="rootModel">root model of the diagram</param>
        /// <returns>ModelingAdapter instance</returns>
        protected sealed override ModelingAdapter CreateModelingAdapterInstance(ModelBusReference reference, ModelElement rootModel)
        {
            if (!(rootModel is TRootModel))
                throw new ArgumentException("Invalid root model.");

            return CreateAdapter(reference, (TRootModel)rootModel);
        }

        /// <summary>
        ///   Retune a string collection of LogicalAdapterId this manager supports.
        /// </summary>
        /// <returns></returns>
        public override IEnumerable<string> GetSupportedLogicalAdapterIds()
        {
            yield return typeof(TAdapter).Name;
        }

        /// <summary>
        ///   Returns the LogicalAdapterId for creating model bus reference. Default is to return 1st entry in the GetSupportedLogicalAdapterIds().
        /// </summary>
        protected virtual string LogicalAdapterId
        {
            [DebuggerStepThrough]
            get { return GetSupportedLogicalAdapterIds().First(); }
        }

        /// <summary>
        /// Get a collection of all the ModelElement types which are exposed by any ModelBusAdapter
        /// managed by this adapter manager, and thus can be referenced from the outside, along
        /// with their display name;
        /// </summary>
        /// <param name="adapterId">the adapter id from which to get the supported types</param>
        /// <returns>Readonly collection of <see cref="SupportedType"/>s</returns>
        public override IEnumerable<SupportedType> GetExposedElementTypes(string adapterId)
        {
            if (adapterId == null) throw new ArgumentNullException("adapterId");

            if ( !GetSupportedLogicalAdapterIds().Contains(adapterId))
            {
                // Do not recognize the incoming adapterId. Simply throw
                throw new NotSupportedException(String.Format( CultureInfo.CurrentCulture,
                                                                Resources.LogicalAdapterIdNotSupported, 
                                                                adapterId, 
                                                                this.GetType().Name));
            }

            return GetExposedElementTypes();
        }

        /// <summary>
        /// Returns the root model type. Default behavior is to reutrn the 1st entry in the GetExposedElementTypes()
        /// </summary>
        protected virtual SupportedType RootModelType
        {
            [DebuggerStepThrough]
            get  {  return this.GetExposedElementTypes().FirstOrDefault();  }
        }

        /// <summary>
        /// Retrieves the types exposed by the adapter, which can be used for querying 
        /// as well as selection context in the diagram for extension.
        /// </summary>
        /// <returns></returns>
        public abstract IEnumerable<SupportedType> GetExposedElementTypes();

        /// <summary>
        /// Creates an instance of the adapter for the given reference and root model.
        /// </summary>
        protected abstract ModelingAdapter<TRootModel> CreateAdapter(ModelBusReference reference, TRootModel rootModel);

        /// <summary>
        ///   Determine whether a model bus reference can be created based on the modelLocatorInfo
        /// </summary>
        /// <param name="modelLocatorInfo">ReferenceContext provided to describe the desired model.</param>
        /// <returns>true if this manager can create a model bus reference to the model</returns>
        public override bool CanCreateReference(params object[] modelLocatorInfo)
        {
            var fileName = GetFileName(modelLocatorInfo);

            // add this for debugging
            bool canCreate = !String.IsNullOrEmpty(fileName) &&
                    new FileInfo(fileName).Extension.Equals(fileExtension, StringComparison.Ordinal);

            return canCreate;
        }

        /// <summary>
        ///   Create and return a model bus reference from the supplied data.
        /// </summary>
        /// <param name="modelLocatorInfo">ReferenceContext provided to describe the desired model.</param>
        /// <returns>A new model bus reference, or null.</returns>
        /// <remarks>This method may throw exceptions if a model bus reference could not be created.</remarks>
        public override ModelBusReference CreateReference(params object[] modelLocatorInfo)
        {
            if (!CanCreateReference(modelLocatorInfo))
            {
                return null;
            }

            var fileName = GetFileName(modelLocatorInfo);

            return new ModelBusReference(
                    this.ModelBus,
                    this.LogicalAdapterId,
                    Path.GetFileNameWithoutExtension(fileName),
                    new ModelingAdapterReference(null, null, fileName));
        }

        /// <summary>
        /// Gets the file name from the locator info.
        /// </summary>
        protected string GetFileName(params object[] modelLocatorInfo)
        {
            if (modelLocatorInfo == null || modelLocatorInfo.Length == 0)
            {
                return null;
            }

            var path = (from info in modelLocatorInfo
                        where info is ProjectItem
                        select ((ProjectItem)info).get_FileNames(1))
                                 .FirstOrDefault();

            if (String.IsNullOrEmpty(path))
                path = (from info in modelLocatorInfo
                        where info is string
                        select (string)info)
                             .FirstOrDefault();

            return path;
        }
    }
}
