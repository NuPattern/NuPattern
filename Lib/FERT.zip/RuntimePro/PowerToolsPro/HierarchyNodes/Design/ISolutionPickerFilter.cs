
namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes.Design
{
    /// <summary>
    /// Inferface that must be implemented by filters of the <see cref="SolutionPickerEditor"/>
    /// </summary>
    public interface ISolutionPickerFilter
    {
        /// <summary>
        /// Filter method
        /// </summary>
        /// <param name="node">Wheather or not this node should be filter out</param>
        /// <returns>True if the node must be filter out, False if not</returns>
        bool Filter(IHierarchyNode node);
    }
}
