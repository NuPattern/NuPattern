
namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes.Design
{
    /// <summary>
    /// Filter to allow only projects
    /// </summary>
    public class OnlyProjectsFilter : ISolutionPickerFilter
    {
        #region ISolutionPickerFilter Members

        /// <summary>
        /// Filter method
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        public bool Filter(IHierarchyNode node)
        {
            if (node.IsSolution)
            {
                return false;
            }
            if (node.ExtObject is EnvDTE.Project)
            {
                return false;
            }
            return true;
        }

        #endregion
    }
}
