using System;
using System.Runtime.Serialization;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes
{
    [Serializable]
    public class HierarchyNodeException : Exception
    {
        public HierarchyNodeException()
        {
        }

        public HierarchyNodeException(string message) : base(message)
        {
        }

        public HierarchyNodeException(string message, Exception inner) : base(message, inner)
        {
        }

        protected HierarchyNodeException(
            SerializationInfo info,
            StreamingContext context) : base(info, context)
        {
        }
    }
}