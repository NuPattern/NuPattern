﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;

using Microsoft.VisualStudio.Shell.Interop;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes
{
    static class Guard
    {
        public static void ArgumentNotNullOrEmptyString(string value, string paramName)
        {
            if (String.IsNullOrEmpty(value))
                throw new ArgumentNullException(paramName,
                                                String.Format(CultureInfo.CurrentCulture,
                                                              Properties.Resources.General_ArgumentEmpty, paramName));

        }

        public static void ArgumentNotNull(object value, string paramName)
        {
            if (value == null)
                throw new ArgumentNullException(paramName,
                                                String.Format(CultureInfo.CurrentCulture,
                                                              Properties.Resources.General_ArgumentEmpty, paramName));

        }
    }
}
