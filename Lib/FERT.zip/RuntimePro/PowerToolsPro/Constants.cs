﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.ExtensibilityHosting;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	/// <summary>
	/// Invariant values for the Power Tools.
	/// </summary>
	public static class Constants
	{
		/// <summary>
		/// Catalog name to use with the <see cref="VsCatalogNameAttribute"/>.
		/// </summary>
		public const string CatalogName = "Microsoft.VisualStudio.TeamArchitect.PowerTools";
	}
}
