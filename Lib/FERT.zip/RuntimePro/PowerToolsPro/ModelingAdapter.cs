﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Integration;
using Microsoft.VisualStudio.Modeling.Integration.Shell;
using Microsoft.VisualStudio.TeamArchitect;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    /// <summary>
    /// Base class for standard modeling adapters that provide generic functionality by reusing 
    /// the <see cref="ModelingAdapterManager&lt;TAdapter, TRootModel&gt;"/> in combination with this class.
    /// </summary>
    /// <typeparam name="TRootModel">Type of root model exposed by the adapter.</typeparam>
    public class ModelingAdapter<TRootModel> : StandardModelingAdapter
            where TRootModel : ModelElement
    {
        /// <summary>
        ///   ModelingAdapter ctor
        /// </summary>
        /// <param name="reference">Model bus reference </param>
        /// <param name="manager">VsModelingAdapterManager object where this ModelingAdapter object is created from</param>
        /// <param name="rootModel">root model of the apater object.</param>
        public ModelingAdapter(ModelBusReference reference, VsModelingAdapterManager manager, TRootModel rootModel)
            : base(reference, manager, rootModel)
        {
        }

        /// <summary>
        ///   Return the display name of adapter.
        /// </summary>
        public override string DisplayName
        {
            get { return Path.GetFileNameWithoutExtension(this.DocumentHandler.ModelFile); }
        }

        /// <summary>
        ///   Get back all referenced objects that conform to a given exposed element type
        /// </summary>
        /// <param name="elementType">The element type</param>
        /// <returns>A collection of model bus reference to the object of requesting type</returns>
        protected override IEnumerable<ModelBusReference> GetElementReferences(System.Type elementType)
        {
            if (elementType == null)
                throw (new System.ArgumentNullException("elementType"));

            //ValidateArg.NotNull(elementType, "elementType");

            // Search always from the root model to its linked child elements
            // descendents (shallow API).  

            var references = (from role in AdapterModelRoot.GetDomainClass().LocalDomainRolesPlayed
                              from element in role.GetLinkedElements(AdapterModelRoot)
                              where elementType.IsAssignableFrom(element.GetType())
                              select element)
                            .Distinct()
                            .Select(element => new ModelBusReference(
                                this.Reference.ModelBus,
                                this.Reference.LogicalAdapterId,
                                this.DisplayName,
                                this.GetDisplayName(element),
                                new ModelingAdapterReference(element.Id.ToString(), null, this.DocumentHandler.ModelFile)))
                                .ToList(); //for debugging
            return references;
        }

        /// <summary>
        /// Allows DSL author to decide the display name for a particular model element.
        /// </summary>
        /// <param name="mel">Model element for which we want to compute the display name</param>
        /// <returns>A string constaining the Display name for the <paramref name="mel"/>. This string can be null in which case
        /// the display name will be the display name of the corresponding DomainClass.</returns>
        public virtual string GetDisplayName(ModelElement mel)
        {
            string name;
            if (DomainClassInfo.TryGetName(mel, out name))
            {
                return name;
            }

            return mel.GetDomainClass().DisplayName;
        }

        /// <summary>
        ///  Returns the view of the current adapter
        /// </summary>
        /// <param name="reference"></param>
        /// <returns></returns>
        public override ModelBusView GetView(ModelBusReference reference)
        {
            //ValidateArg.NotNull(reference, "reference");
            if (reference == null)
                throw (new System.ArgumentNullException("reference"));

            return new StandardVsModelingDiagramView(this, reference);
        }
    }
}
