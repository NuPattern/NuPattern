﻿using System;
using Microsoft.VisualStudio.Modeling.Integration;
using System.Collections.Generic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
		public interface IAdapterRegistration
		{
				Type AdapterType { get; }
				SupportedType RootModel { get; }
				IEnumerable<SupportedType> SupportedElements { get; }
		}
}
