﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    public interface IDataContainer
    {
        /// <summary>
        /// Arbitrary data associated with the item, using dynamic property syntax 
        /// (i.e. solution.Data.MyValue = "Hello").
        /// </summary>
        dynamic Data { get; }
    }
}
