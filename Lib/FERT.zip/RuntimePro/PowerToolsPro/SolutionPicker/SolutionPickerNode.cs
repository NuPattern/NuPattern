﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;
using System.Drawing;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
    internal class SolutionPickerNode : IHierarchyNode
	{
		private List<IHierarchyNode> children = new List<IHierarchyNode>();

		public IEnumerable<IHierarchyNode> Children
		{
			get { return this.children; } 
		}

		public void Add(IHierarchyNode node)
		{
			this.children.Add(node);
		}

		public void AddRange(IEnumerable<IHierarchyNode> nodes)
		{
			this.children.AddRange(nodes);
		}

		public void SetIconFromBitmap(Bitmap image)
		{
			image.MakeTransparent(Color.Magenta);
			this.Icon = Icon.FromHandle(image.GetHicon());
		}

		public object ExtObject
		{
			get;
			set;
		}

		public T GetObject<T>() where T : class
		{
			return default(T);
		}

		public bool HasChildren
		{
			get { return this.Children != null && this.Children.Count() > 0; }
		}

		public System.Drawing.Icon Icon
		{
			get;
			set;
		}

		private string iconKey;
		public string IconKey
		{
			get 
			{
				if (string.IsNullOrEmpty(iconKey))
				{
					if (!string.IsNullOrEmpty(this.SolutionRelativeName))
					{
						this.iconKey = this.SolutionRelativeName;
					}
					else
					{
						this.iconKey = Guid.NewGuid().ToString();
					}
				}

				return iconKey;
			}
			set { this.iconKey = value; }
		}



		public bool IsSolution
		{
			get;
			set;
		}

		public uint ItemId
		{
			get;
			set;
		}

		public string Name
		{
			get;
			set;
		}

		public Guid ProjectGuid
		{
			get;
			set;
		}

		public string SolutionRelativeName
		{
			get;
			set;
		}

		public Guid TypeGuid
		{
			get;
			set;
		}
	}
}
