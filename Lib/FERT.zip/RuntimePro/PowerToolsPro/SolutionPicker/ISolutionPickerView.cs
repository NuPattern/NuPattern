using System;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
    public interface ISolutionPickerView
    {
        void SetRootHierarchyNode(IHierarchyNode value);
        bool CanExit { get; set; }
		bool CanBrowse { get; set; }

		/// <summary>
		/// Gets the file name that was browsed via the filesystem.
		/// </summary>
		string FileName { get; }
		event EventHandler FileNameChanged;

		IHierarchyNode SelectedNode { get; set; }
        event EventHandler SelectedNodeChanged;
    }
}