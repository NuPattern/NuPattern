using System;
using System.Linq;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;
using Microsoft.VisualStudio.ComponentModelHost;
using System.Collections.Generic;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
    public class SolutionPickerPresenter
    {
        private ISolutionPickerView view;
		private IHierarchyNode solutionNode;
		private IServiceProvider serviceProvider;

        public SolutionPickerPresenter(IServiceProvider serviceProvider, IHierarchyNode solutionNode, 
			ISolutionPickerView view, SolutionPickerFilter filter)
        {
			this.serviceProvider = serviceProvider;
			this.solutionNode = solutionNode;
            this.view = view;
            view.CanExit = false;

			var componentModel = (IComponentModel)serviceProvider.GetService(typeof(SComponentModel));
			var providers = componentModel.GetExtensions<ISolutionPickerNodesProvider>().ToList();

			var root = new SolutionPickerNode { Name = "Solution and Features" };
            root.SetIconFromBitmap(Properties.Resources.Feature);
			root.Add(solutionNode);
			providers.ForEach(provider => root.AddRange(provider.GetNodes(filter)));
			
            view.SetRootHierarchyNode(root);
            view.SelectedNodeChanged += OSelectedNodeChanged;
			view.CanBrowse = filter.Kind.HasFlag(ItemKind.Item);
			view.FileNameChanged += OnFileNameChanged;
        }

		void OnFileNameChanged(object sender, EventArgs e)
		{
			var item = ItemFactory.CreateItem(this.serviceProvider, this.solutionNode);
			var relativePath = new RelativePathBuilder(referencePath: item.PhysicalPath, toConvert: this.view.FileName).Build();

			view.SelectedNode = new FileNode(relativePath);
		}

        void OSelectedNodeChanged(object sender, EventArgs e)
        {
            IHierarchyNode node = view.SelectedNode;

			view.CanExit = true;
        }
    }
}