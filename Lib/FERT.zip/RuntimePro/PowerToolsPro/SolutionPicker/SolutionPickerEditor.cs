﻿using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.Design;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
    internal class SolutionPickerEditor : UITypeEditor
    {
        public override object EditValue(System.ComponentModel.ITypeDescriptorContext context, IServiceProvider provider, object value)
        {
            if (null == provider) return null;

            using (var solutionPicker = new SolutionPickerView(provider))
            {
                solutionPicker.Filter.Kind = ItemKind.Solution | ItemKind.SolutionFolder | ItemKind.Project | ItemKind.Folder;
                solutionPicker.Text = "Select target";

                if (DialogResult.OK == solutionPicker.ShowDialog())
                {
                    return solutionPicker.SelectedNode.SolutionRelativeName;
                }
                else
                {
                    return base.EditValue(context, provider, value);
                }
            }
        }

        public override UITypeEditorEditStyle GetEditStyle(System.ComponentModel.ITypeDescriptorContext context)
        {
            return UITypeEditorEditStyle.Modal;
        }
    }
}
