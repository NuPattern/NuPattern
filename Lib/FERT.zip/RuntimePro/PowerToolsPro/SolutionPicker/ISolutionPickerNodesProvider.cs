﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
	internal interface ISolutionPickerNodesProvider
	{
		IEnumerable<IHierarchyNode> GetNodes(SolutionPickerFilter filter);
	}
}
