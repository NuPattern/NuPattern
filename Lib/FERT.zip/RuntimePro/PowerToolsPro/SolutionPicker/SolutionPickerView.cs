using System;
using System.IO;
using System.Linq;
using System.Reflection;
using EnvDTE;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes.Design;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;
using System.Windows.Forms;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
    public partial class SolutionPickerView : Form, ISolutionPickerView
    {
        private SolutionPickerFilter filter;
        private SolutionPickerControl control;
        private bool canExit;
        private bool canBrowse;
        private SolutionPickerPresenter presenter;
        private string fileName;
        private IServiceProvider provider;
        private IHierarchyNode targetProject;
        private IHierarchyNode customSelection;
        private HierarchyNode solutionNode;

        public event EventHandler SelectedNodeChanged = (sender, args) => { };
        public event EventHandler FileNameChanged = (sender, args) => { };


        public SolutionPickerView(IServiceProvider provider)
            : this(provider, new HierarchyNodeFactory(provider).GetSelectedProject())
        {
            this.filter = new SolutionPickerFilter(provider);
        }

        public SolutionPickerFilter Filter
        {
            get { return this.filter; }
        }

        //FxCop: Presenter attaches to ISolutionPickerView and events once created.
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker.SolutionPickerPresenter")]
        public SolutionPickerView(IServiceProvider provider, IHierarchyNode targetProject)
        {
            InitializeComponent();
            this.provider = provider;
            this.targetProject = targetProject;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);

            IVsSolution solution = provider.GetService(typeof(SVsSolution)) as IVsSolution;
            this.solutionNode = new HierarchyNode(solution);
            this.presenter = new SolutionPickerPresenter(this.provider, this.solutionNode, this, this.Filter);
            this.CenterToParent();
        }

        public void SetRootHierarchyNode(IHierarchyNode value)
        {
            UpdatePickerControl(value);
        }

        private void UpdatePickerControl(IHierarchyNode rootNode)
        {
            if (control != null)
            {
                this.contentPanel.Controls.Remove(control);
            }

            control = new SolutionPickerControl(rootNode, filter);
            control.Left = 0;
            control.Top = 0;
            control.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            control.Size = contentPanel.ClientSize;
            control.SelectionChanged += new EventHandler(OnNodeSelectionChanged);

            this.contentPanel.Controls.Add(control);
        }

        public string FileName
        {
            get { return this.fileName; }
            private set { this.fileName = value; FileNameChanged(this, EventArgs.Empty); }
        }

        public bool CanBrowse
        {
            get { return this.canBrowse; }
            set
            {
                this.canBrowse = value;
                this.pnlBrowse.Visible = value;
                if (!value)
                    this.contentPanel.Height += this.pnlBrowse.Height;
            }
        }

        public bool CanExit
        {
            get { return canExit; }
            set
            {
                canExit = value;
                buttonOK.Enabled = canExit;
            }
        }

        public IHierarchyNode SelectedNode
        {
            get { return this.customSelection ?? control.SelectedTarget; }
            set { this.customSelection = value; SelectedNodeChanged(this, EventArgs.Empty); }
        }

        public IItemContainer SelectedItem
        {
            get { return this.SelectedNode != null ? ItemFactory.CreateItem(this.provider, this.SelectedNode) : null; }
        }

        private void OnBrowse(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog())
            {
                dialog.Title = "Select file location";
                if (dialog.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                {
                    this.FileName = dialog.FileName;
                    this.txtFile.Text = this.SelectedNode.SolutionRelativeName;
                }
            }
        }

        private void OnDoubleClickNode(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            Close();
        }

        private void OnNodeSelectionChanged(object sender, EventArgs e)
        {
            SelectedNodeChanged(this, EventArgs.Empty);
            this.fileName = null;
            this.customSelection = null;
            this.txtFile.Text = "";
        }

        private class WindowHandleAdapter : IWin32Window
        {
            private IntPtr handle;
            public WindowHandleAdapter(IntPtr hwnd)
            {
                handle = hwnd;
            }

            public IntPtr Handle
            {
                get { return handle; }
            }
        }
    }
}