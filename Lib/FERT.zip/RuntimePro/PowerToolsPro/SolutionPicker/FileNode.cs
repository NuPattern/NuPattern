﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
	internal class FileNode : IHierarchyNode
	{
		private string fileName;

		public FileNode(string fileName)
		{
			this.fileName = fileName;
		}

		public IEnumerable<IHierarchyNode> Children
		{
			get { throw new NotImplementedException(); }
		}

		public object ExtObject
		{
			get { throw new NotImplementedException(); }
		}

		public T GetObject<T>() where T : class
		{
			throw new NotImplementedException();
		}

		public bool HasChildren
		{
			get { throw new NotImplementedException(); }
		}

		public System.Drawing.Icon Icon
		{
			get { throw new NotImplementedException(); }
		}

		public string IconKey
		{
			get { throw new NotImplementedException(); }
		}

		public bool IsSolution
		{
			get { return false; }
		}

		public uint ItemId
		{
			get { throw new NotImplementedException(); }
		}

		public string Name
		{
			get { return System.IO.Path.GetFileName(fileName); }
		}

		public Guid ProjectGuid
		{
			get { throw new NotImplementedException(); }
		}

		public string SolutionRelativeName
		{
			get { return fileName; }
		}

		public Guid TypeGuid
		{
			get { throw new NotImplementedException(); }
		}
	}
}
