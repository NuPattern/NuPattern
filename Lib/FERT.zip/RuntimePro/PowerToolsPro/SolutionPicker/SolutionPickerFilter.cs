﻿using System;
using System.Linq;
using System.IO;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.HierarchyNodes.Design;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.SolutionPicker
{
    public class SolutionPickerFilter : ISolutionPickerFilter
	{
		private IServiceProvider serviceProvider;

		public SolutionPickerFilter(IServiceProvider serviceProvider)
		{
			this.serviceProvider = serviceProvider;
			this.IncludeEmptyContainers = true;
		}

		public ItemKind Kind { get; set; }

		public bool IncludeEmptyContainers { get; set; }

		/// <summary>
		/// Gets or sets which extensions should be shown. For example: .cs;.txt;.xml
		/// </summary>
		public string IncludeFileExtensions { get; set; }

		public bool Filter(IHierarchyNode node)
		{
			if (node is SolutionPickerNode)
				return false;

			var item = ItemFactory.CreateItem(this.serviceProvider, node);

			if ((item.Kind | this.Kind) == this.Kind)
			{
				if (!string.IsNullOrEmpty(this.IncludeFileExtensions) && item.Kind == ItemKind.Item)
				{
					return !ApplyFileExtension(Path.GetExtension(item.PhysicalPath));
				}

				if (item.Kind != ItemKind.Item && !IncludeEmptyContainers)
				{
					if(node.Children == null || node.Children.Count() == 0)
					{
						return true;
					}
					else
					{
						return node.Children.Where(n => !Filter(n)).Count() == 0;
					}
				}

				return false;
			}

			return true;
		}

		public bool ApplyFileExtension(string fileExtension)
		{
			if (!string.IsNullOrEmpty(this.IncludeFileExtensions))
			{
				return this.IncludeFileExtensions.ToLowerInvariant().Contains(fileExtension.ToLowerInvariant());
			}

			return false;
		}
	}
}
