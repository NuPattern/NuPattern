﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Integration;
using System.Drawing;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    /// <summary>
    /// Adds information to <see cref="SupportedType"/> for Commands
    /// </summary>
    public class CommandSupportedType : SupportedType
    {
        public CommandSupportedType(Type supportedType)
            : base(supportedType)
        {}

        public CommandSupportedType(Type supportedType, string displayName)
            : base(supportedType, displayName)
        { }

        public CommandSupportedType(Type supportedType, string displayName, Bitmap image)
            : base(supportedType, displayName)
        {
            this.Image = image;
        }

        /// <summary>
        /// Gets the image associated with the supported type
        /// </summary>
        public Bitmap Image { get; private set; }
    }
}
