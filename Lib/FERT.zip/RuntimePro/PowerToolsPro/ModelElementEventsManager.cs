﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Diagrams;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	internal enum ElementEventType
	{
		ElementAdded = 0,
		ElementDeleted = 1,
		ElementMoved = 2
	}

	internal class ModelElementEventsManager
	{
		internal ModelElementEventsManager()
		{ }

		private List<HandlerInfo> handlers = new List<HandlerInfo>();
		private static ModelElementEventsManager instance;

		internal IEnumerable<ModelElementEventsManager.HandlerInfo> RegisteredHandlers
		{
			get { return this.handlers; }
		}

		internal void SubscribeToElementEvents<TElement>(Action<TElement> handler, Predicate<TElement> condition, Store store)
			where TElement : ModelElement
		{
			this.SubscribeToElementEvents(handler, condition, store, ElementEventType.ElementAdded | ElementEventType.ElementMoved | ElementEventType.ElementDeleted);
		}

		internal void SubscribeToElementEvents<TElement>(Action<TElement> handler, Predicate<TElement> condition, Store store, ElementEventType eventType)
			where TElement : ModelElement
		{
			HandlerInfo info = new HandlerInfo
			{
				Action = handler,
				Condition = condition,
				Store = store,
				TargetType = typeof(TElement),
				EventType = eventType
			};

			if (!this.handlers.Exists(h => h.Store == store))
			{
				SubscribeToStoreEvents(store);
			}
			if (!this.handlers.Exists(h => h.Store == store && h.TargetType == typeof(TElement)))
			{
				SubscribeToElementEvents<TElement>(store);
			}

			handlers.Add(info);
		}

		private void SubscribeToStoreEvents(Store store)
		{
			store.StoreDisposing += new EventHandler(OnStoreDisposing);
		}

		private void SubscribeToElementEvents<TElement>(Store store)
			where TElement : ModelElement
		{
			// Find the domain class info associated with the element type. 
			DomainClassInfo domainClassInfoToBeSubscribed = store.DomainDataDirectory.GetDomainClass(typeof(TElement));

			if (domainClassInfoToBeSubscribed != null)
			{				
				store.EventManagerDirectory.ElementAdded.Add(domainClassInfoToBeSubscribed, new EventHandler<ElementAddedEventArgs>(OnElementAdded));
				store.EventManagerDirectory.ElementDeleted.Add(domainClassInfoToBeSubscribed, new EventHandler<ElementDeletedEventArgs>(OnElementDeleted));
				store.EventManagerDirectory.ElementMoved.Add(domainClassInfoToBeSubscribed, new EventHandler<ElementMovedEventArgs>(OnElementMoved));
			}
		}

		private void OnStoreDisposing(object sender, EventArgs e)
		{
			// Release the handlers of the disposed store
			Store store = sender as Store;
			handlers.RemoveAll(handler => handler.Store == store);
		}

		private void OnElementEventOccured(object sender, ElementEventArgs e, ElementEventType eventType)
		{
			// Filter the hanlders that will be executed by EventType, TargetType and Condition
			IEnumerable<HandlerInfo> handlersToBeExecuted = this.handlers
				.Where(handler => (handler.EventType | eventType) == eventType && handler.TargetType.IsAssignableFrom(e.ModelElement.GetType()))
				.Where(handler => handler.CanExecute(e.ModelElement))
				.ToList(); // Convert to list so we can remove items after executing the handlers

			foreach (HandlerInfo handler in handlersToBeExecuted)
			{
				// Check if there is an active transaction
				if (handler.Store.TransactionManager.InTransaction)
				{
					handler.Execute(e.ModelElement);
				}
				else
				{
					// Create the transaction before executing the handler so it's safe to execute operation over the model elements
					using (Transaction transaction = handler.Store.TransactionManager.BeginTransaction("Model Events Manager Transaction"))
					{
						handler.Execute(e.ModelElement);

						transaction.Commit();
					}
				}
			}			
		}

		private void OnElementAdded(object sender, ElementAddedEventArgs e)
		{
			OnElementEventOccured(sender, e, ElementEventType.ElementAdded);
		}

		private void OnElementDeleted(object sender, ElementDeletedEventArgs e)
		{
			OnElementEventOccured(sender, e, ElementEventType.ElementDeleted);
		}

		private void OnElementMoved(object sender, ElementMovedEventArgs e)
		{
			OnElementEventOccured(sender, e, ElementEventType.ElementMoved);
		}

		internal static ModelElementEventsManager Instance
		{
			get
			{
				if (instance == null)
				{
					instance = new ModelElementEventsManager();
				}

				return instance;
			}			
		}

		internal class HandlerInfo
		{
			public HandlerInfo()
			{
				this.WasExecuted = false;
			}

			public Store Store { get; set; }
			public Delegate Action { get; set; }
			public Delegate Condition { get; set; }
			public Type TargetType { get; set; }
			public ElementEventType EventType { get; set; }

			public bool WasExecuted { get; set; }

			internal bool CanExecute(ModelElement modelElement)
			{
				return !this.WasExecuted && (bool)this.Condition.Method.Invoke(this.Condition.Target, new object[] { modelElement });
			}

			internal void Execute(ModelElement modelElement)
			{
				this.Action.Method.Invoke(this.Action.Target, new object[] { modelElement });
				this.WasExecuted = true;
			}
		}
	}
}
