﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Modeling;
using Microsoft.VisualStudio.Modeling.Integration;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
	/// <summary>
	/// Represents the model created by <see cref="ModelingService"/>
	/// </summary>
	/// <typeparam name="T">The root element type of the model</typeparam>
	public class Model<T>
	{
		internal Model(Diagram diagram)
		{
			this.Diagram = diagram;
			this.RootElement = (T)(object)diagram.ModelElement;
			this.Store = diagram.Store;
		}

		/// <summary>
		/// Gets the root element of the model
		/// </summary>
		public T RootElement { get; private set; }

		/// <summary>
		/// Gets the diagram of the model
		/// </summary>
		public Diagram Diagram { get; private set; }

		/// <summary>
		/// Gets the store of the model
		/// </summary>
		public Store Store { get; private set; }

		/// <summary>
		/// Begins a transaction
		/// </summary>
		/// <returns>The transaction</returns>
		public ITransaction BeginTransaction()
		{
			return BeginTransaction("Model Transaction");
		}

		/// <summary>
		/// Begins a new transaction
		/// </summary>
		/// <param name="transactionName">The transaction name</param>
		/// <returns>The transaction</returns>
		public ITransaction BeginTransaction(string transactionName)
		{
			return new ModelTransaction(this.Store, transactionName);
		}
	}
}