﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Integration;
using System.Reflection;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    internal static class ModelBusAdapterExtensions
    {
        internal static IEnumerable<ModelBusReference> GetElementReferences(this ModelBusAdapter adapter, Type elementType)
        {
            var getElementReferencesMethod = adapter.GetType().GetMethod("GetElementReferences", BindingFlags.NonPublic | BindingFlags.Instance);

            if (getElementReferencesMethod != null)
            {
                return getElementReferencesMethod.Invoke(adapter, new object[] { elementType }) as IEnumerable<ModelBusReference>;
            }

            return new ModelBusReference[0];
        }


       
    }
}
