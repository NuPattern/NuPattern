﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Integration;
using Microsoft.VisualStudio.Modeling;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools
{
    internal static class IModelBusExtensions
    {
        internal static bool TryCreateAdapter(this IModelBus bus, ModelBusReference reference, out ModelBusAdapter adapter)
        {
            adapter = null;
            try
            {
                adapter = bus.CreateAdapter(reference);
                return adapter != null;
            }
            catch
            {
                return false;
            }
        }
    }

    static class ModelBusExtensions
    {
        static public ModelingAdapter<ModelElement> CreateAdapter(this ModelBus modelBus, ModelBusReference reference)
        {
            return modelBus.CreateAdapter(reference) as ModelingAdapter<ModelElement>;
        }
    }
}
