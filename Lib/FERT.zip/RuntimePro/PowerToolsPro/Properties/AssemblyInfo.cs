﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.ExtensibilityHosting;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;

[assembly: AssemblyTitle("PowerTools")]
[assembly: AssemblyProduct("PowerTools")]

[assembly: ComVisible(false)]
[assembly: Guid("86b3bbb6-96ad-4df2-b282-f48385c41fb8")]