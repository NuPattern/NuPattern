﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Forms;
using System;
using System.ComponentModel.Composition;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Commands
{
    [Category(FeatureComponentCategories.UI)]
    [DisplayName("Set Blackboard Instance Value")]
    [Description("Store a value on the blackboard with the specified key prepended with the owning feature's instance name and a period (e.g. Feature1.Key)")]
    public class SetBlackboardInstanceValue : FeatureCommand
    {

        [Required]
        public string Key { get; set; }

        [Required]
        public string Value { get; set; }

        [Import(AllowDefault = true)]
        public IFeatureExtension Feature { get; set; }

        public override void Execute()
        {
            BlackboardManager.Current.Set(Feature.InstanceName + "." + Key, Value);
        }
    }
}