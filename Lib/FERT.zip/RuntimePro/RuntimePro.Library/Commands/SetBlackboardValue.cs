﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Forms;
using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Commands
{
	[Category(FeatureComponentCategories.UI)]
	[DisplayName("Set Blackboard Value")]
	[Description("Store a value on the blackboard with the specified key")]
    public class SetBlackboardValue : FeatureCommand
	{

        [Required]
        public string Key { get; set; }

        [Required]
        public string Value{ get; set; }

		public override void Execute()
		{
            BlackboardManager.Current.Set(Key, Value);
		}
	}
}