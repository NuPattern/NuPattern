﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows.Forms;
using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Commands
{
	[Category(FeatureComponentCategories.UI)]
	[DisplayName("Show Message")]
	[Description("Shows a message in a message box")]
    public class ShowMessage : FeatureCommand
	{

		public string Message { get; set; }

		public override void Execute()
		{
			MessageBox.Show(String.IsNullOrEmpty(this.Message) ? "<No Message Supplied>" : this.Message);
		}
	}
}