﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.ExtensibilityHosting;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features;

[assembly: AssemblyTitle("Feature Extensions Library")]
[assembly: AssemblyProduct("Feature Extensions Library")]

[assembly: ComVisible(false)]
[assembly: Guid("89B6939B-1B0B-4D2C-B51A-DD8276B0404D")]

[assembly: VsCatalogName(Constants.CatalogName)]