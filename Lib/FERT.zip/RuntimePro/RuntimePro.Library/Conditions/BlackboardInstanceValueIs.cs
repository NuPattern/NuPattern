using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
    /// <summary>
    /// This Condition returns true if the specified Key on the Blackboard matches the Value
    /// </summary>
    [DisplayName("BlackboardInstanceValueIs")]
    [Description("Returns true if the Blackboard contains the specified Value under the specified Key prepended with the owning features instance name and a period (e.g. Feature1.Key)")]
    public class BlackboardInstanceValueIs : Condition
    {
        [Required]
        public string Key { get; set; }

        [Required]
        public string Value { get; set; }

        [Import(AllowDefault = true)]
        public IFeatureExtension Feature { get; set; }

        public override bool Evaluate()
        {
            bool result = false;

            string blackboardData = BlackboardManager.Current.Get(Feature.InstanceName + "." + Key);
            if (!string.IsNullOrEmpty(blackboardData) &&
                blackboardData == Value)
                result = true;

            return result;
        }
    }
}