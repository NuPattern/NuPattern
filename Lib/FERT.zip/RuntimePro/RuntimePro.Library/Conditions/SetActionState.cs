using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	/// <summary>
	/// This Condition allows one Action in a workflow to depend on another which
	/// is how we will effectively implement the Start/Start, Start/Finish, Finish/Start and
	/// Finish/Finish states, in conjunction with the implied "predecessor must be complete"
	/// of connectors
	/// </summary>
	[DisplayName("SetActionState")]
	[Description("Returns true and sets the state of the action")]
	public class SetActionState : Condition
	{
		public string ActionName { get; set; }

		public NodeState ActionState { get; set; }

		[Import(AllowDefault = true)]
		public IFeatureExtension Feature { get; set; }

        [Import(AllowDefault=true)]
        public IFeatureManager FeatureManager { get; set; }

		public override bool Evaluate()
		{
            bool result = false;

            if (this.Feature != null && this.Feature.GuidanceWorkflow != null)
                result = this.Feature.GuidanceWorkflow.Traverse()
                    .Any(n => string.Equals(n.Name, this.ActionName, StringComparison.InvariantCultureIgnoreCase) &&
                              n.State == this.ActionState);
            else
            {
                result = FeatureManager.ActiveFeature.GuidanceWorkflow.Traverse()
                    .Any(n => string.Equals(n.Name, this.ActionName, StringComparison.InvariantCultureIgnoreCase) &&
                              n.State == this.ActionState);
            }

            return result;
		}
	}
}