using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	/// <summary>
	/// This Condition allows one Action in a workflow to depend on another which
	/// is how we will effectively implement the Start/Start, Start/Finish, Finish/Start and
	/// Finish/Finish states, in conjunction with the implied "predecessor must be complete"
	/// of connectors
	/// </summary>
	[DisplayName("At Least One Predecessor Complete")]
	[Description("Returns true if at least one of the predecessors of the named node is complete")]
	public class AtLeastOnePredecessorComplete : Condition
	{
		[Import(AllowDefault = true)]
		public IFeatureExtension Feature { get; set; }

        [Import(AllowDefault=true)]
        public IFeatureManager FeatureManager { get; set; }

		public override bool Evaluate()
		{
            bool result = false;
            INode targetNode = FeatureCallContext.Current.DefaultConditionTarget;

            //
            // Now, if any of it's predecessors
            // are *NOT* complete, return false, otherwise, true
            //
            if (targetNode != null)
            {
                result = false;
                foreach (INode n in targetNode.Predecessors)
                {
                    if (n.State == NodeState.Completed)
                    {
                        result = true;
                        break;
                    }
                }
            }
            return result;
		}
	}
}