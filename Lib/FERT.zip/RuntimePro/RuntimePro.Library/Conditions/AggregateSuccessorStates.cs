using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
    /// <summary>
    /// This Condition sets the workflow node to which it is attached (and that must be Fork or Decision)
    /// to the aggregate state of its successors (defined as any and all nodes between this node and its
    /// matching Join or Merge.
    /// That aggregate state is Enabled, if ANY of the successor nodes are Enabled, Complete if ALL of the successor
    /// nodes are complete and Blocked if ALL of the nodes are Blocked.
    /// Note:  Nested Fork/Join and Decision/Merge nodes are considered as one node using the state of the
    /// nested Fork or Decision as the state of the inner group
    /// </summary>
    [DisplayName("AggregateSuccessorStates")]
    [Description("Returns true. Sets the state of the owning node based on the states of its successors based on Any Enabled = Enabled, All Complete = Complete and All Blocked = Blocked")]
    public class AggregateSuccessorStates : Condition
    {
        [Import(AllowDefault = true)]
        public IFeatureExtension Feature { get; set; }

        [Import(AllowDefault = true)]
        public IFeatureManager FeatureManager { get; set; }

        public override bool Evaluate()
        {
            bool result = true;         // since we set the state, we always return true to allow multiple conditions to be specified
            bool allComplete = true;    // we assume all are complete and set this false if we see a Blocked or Ready
            NodeState stateToSet = NodeState.Blocked;

            IConditionalNode ourNode = FeatureCallContext.Current.DefaultConditionTarget as IConditionalNode;
            if (ourNode == null)
                return result;

            IConditionalNode matchingNode = FindEndNode(ourNode);

            foreach (IConditionalNode n in ourNode.Successors)
            {
                IConditionalNode nextNode;
                nextNode = n;

                do
                {

                    if (nextNode.State != NodeState.Completed)
                        allComplete = false;

                    if (nextNode.State == NodeState.Enabled)
                    {
                        stateToSet = NodeState.Enabled;
                        break;
                    }

                    if (nextNode is IFork || nextNode is IDecision)
                        nextNode = FindEndNode(nextNode);

                    nextNode = nextNode.Successors.First() as IConditionalNode;

                    if (nextNode == matchingNode)
                        break;
                }
                while (nextNode != null);

                if (stateToSet == NodeState.Enabled)
                    break;
            }

            if (allComplete)
            {
                ourNode.SetState(NodeState.Completed, true);
            }
            else
            {
                if (ourNode.IsUserAccepted)
                    ourNode.SetState(NodeState.Completed, true);
                else
                    ourNode.SetState(stateToSet, true);
            }


            return result;
        }

        private IConditionalNode FindEndNode(IConditionalNode ourNode)
        {
            Type endNodeType = ourNode is IFork ? typeof(Join) : typeof(Merge);

            IConditionalNode result = null;
            foreach (IConditionalNode n in ourNode.Successors)
            {
                IConditionalNode aNode = n;
                do
                {
                    if (aNode.GetType() == endNodeType)
                    {
                        result = n;
                        break;
                    }

                    if (aNode is IFork)
                    {
                        aNode = FindEndNode(aNode);
                    }
                    else if (aNode is IDecision)
                    {
                        aNode = FindEndNode(aNode);
                    }

                    aNode = aNode.Successors.First() as IConditionalNode;
                } 
                while (aNode != null);

            }

            return result;
        }
    }
}