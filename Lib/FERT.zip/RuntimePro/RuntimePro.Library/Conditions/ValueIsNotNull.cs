﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features;
using System.ComponentModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	[DisplayName("Value Is Not Null")]
	[Description("Evaluates whether the Value property has a non-null value.")]
	public class ValueIsNotNull : Condition
	{
		public object Value { get; set; }

		public override bool Evaluate()
		{
			return Value != null;
		}
	}
}
