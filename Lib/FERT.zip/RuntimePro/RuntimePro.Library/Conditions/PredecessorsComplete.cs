using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	/// <summary>
	/// This Condition allows one Action in a workflow to depend on another which
	/// is how we will effectively implement the Start/Start, Start/Finish, Finish/Start and
	/// Finish/Finish states, in conjunction with the implied "predecessor must be complete"
	/// of connectors
	/// </summary>
	[DisplayName("Predecessors Complete")]
	[Description("Returns true all the predecessors of the named node are complete")]
	public class PredecessorsComplete : Condition
	{
		[Import(AllowDefault = true)]
		public IFeatureExtension Feature { get; set; }

        [Import(AllowDefault=true)]
        public IFeatureManager FeatureManager { get; set; }

		public override bool Evaluate()
		{
            bool result = false;
            INode targetNode = FeatureCallContext.Current.DefaultConditionTarget;

            //
            // Now, if any of it's predecessors
            // are *NOT* complete, return false, otherwise, true
            //
            if (targetNode != null)
            {
                result = true;
                foreach (INode n in targetNode.Predecessors)
                {
                    if (n.State != NodeState.Completed)
                    {
                        result = false;
                        break;
                    }
                }
            }
            return result;
		}
	}
}