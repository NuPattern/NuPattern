using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	/// <summary>
	/// This Condition allows one Action in a workflow to depend on another which
	/// is how we will effectively implement the Start/Start, Start/Finish, Finish/Start and
	/// Finish/Finish states, in conjunction with the implied "predecessor must be complete"
	/// of connectors
	/// </summary>
	[DisplayName("SetActionStateFromPredecessorValue")]
	[Description("Returns true and sets the state of the action based on the state of a Blackboard value with the key calculated by the feature instance name+the precessor's name+_VALUE")]
	public class SetActionStateFromPredecessorValue : Condition
	{
		public NodeState ActionState { get; set; }

        public string MatchingValue { get; set; }

		[Import(AllowDefault = true)]
		public IFeatureExtension Feature { get; set; }

        [Import(AllowDefault=true)]
        public IFeatureManager FeatureManager { get; set; }

		public override bool Evaluate()
		{
            bool result = true;

            IConditionalNode ourNode = FeatureCallContext.Current.DefaultConditionTarget as IConditionalNode;
            if (ourNode == null)
                return result;

            IConditionalNode predecessor = ourNode.Predecessors.First() as IConditionalNode;

            string value = BlackboardManager.Current.Get(Feature.InstanceName + "." + predecessor.Name + ".Value");
            if (value == MatchingValue)
            {
                if (ourNode.IsUserAccepted)
                    ourNode.SetState(NodeState.Completed, true);
                else
                    ourNode.SetState(ActionState, true);
            }
            else
            {
                if (ourNode.IsUserAccepted)
                    ourNode.SetState(NodeState.Completed, true);
                else
                    ourNode.SetState(NodeState.Disabled, true);
            }
            return result;
		}
	}
}