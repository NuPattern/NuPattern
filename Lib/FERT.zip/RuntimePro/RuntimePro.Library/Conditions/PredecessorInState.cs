using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	/// <summary>
	/// This Condition allows an action to enable/disable itself based on it's grandparent node.
    /// For example, a node after a fork can enable it self only when the parent of the fork is complete
	/// </summary>
	[DisplayName("GrandparentInState")]
	[Description("Returns true if the predecessor's predecessor is in the specified state. For example, the predecessor of a fork or join.")]
	public class PredecessorInState : Condition
	{
		public NodeState ActionState { get; set; }

		[Import(AllowDefault = true)]
		public IFeatureExtension Feature { get; set; }

        [Import(AllowDefault=true)]
        public IFeatureManager FeatureManager { get; set; }

		public override bool Evaluate()
		{
            bool result = false;

            IConditionalNode ourNode = FeatureCallContext.Current.DefaultConditionTarget as IConditionalNode;
            if (ourNode == null)
                return result;

            IConditionalNode predecessor = null;
            try
            {
                predecessor = ourNode.Predecessors.First() as IConditionalNode;
            }
            catch
            {
            }

            if (predecessor == null)
                return false;

            IConditionalNode predecessorsPredecessor = null;
            try
            {
                predecessorsPredecessor = predecessor.Predecessors.First() as IConditionalNode;
            }
            catch
            {
            }

            if (predecessorsPredecessor == null)
                return false;

            if (predecessorsPredecessor.State == ActionState)
                result = true;

            return result;
		}
	}
}