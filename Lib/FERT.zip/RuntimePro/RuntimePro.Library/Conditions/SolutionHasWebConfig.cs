﻿using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Linq;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	[DisplayName("Solution contains Web.config")]
    [Description("The current solution must contain a Web.config")]
    public class SolutionHasWebConfig : Condition
	{
		[Import]
		public ISolution Solution { get; set; }

		public override bool Evaluate()
		{
            return this.Solution
                .Find(item => "Web.config".Equals(item.Name, System.StringComparison.InvariantCultureIgnoreCase))
                .Any();
		}
	}
}
