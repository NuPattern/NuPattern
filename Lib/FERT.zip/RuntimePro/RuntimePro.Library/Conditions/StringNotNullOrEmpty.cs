﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features;
using System.ComponentModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	[DisplayName("Value Is Not Null Or Empty")]
	[Description("Evaluates whether the string Value property is not null or empty.")]
	public class StringNotNullOrEmpty : Condition
	{
		public string Value { get; set; }

		public override bool Evaluate()
		{
			return string.IsNullOrEmpty(Value);
		}
	}
}
