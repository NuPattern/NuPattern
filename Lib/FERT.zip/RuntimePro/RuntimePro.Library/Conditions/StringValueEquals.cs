﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features;
using System.ComponentModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.Conditions
{
	[DisplayName("String Values Are Equal")]
	[Description("Evaluates that the two string values are equal.")]
	public class StringValueEquals : Condition
	{
		public string Value1 { get; set; }
		public string Value2 { get; set; }
		public StringComparison ComparisonKind { get; set; }
		
		public override bool Evaluate()
		{
			return String.Equals(Value1, Value2, ComparisonKind);
		}
	}
}
