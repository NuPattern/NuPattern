﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.ComponentModel;
using Microsoft.VisualStudio.Modeling.Diagrams.ExtensionEnablement;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualBasic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.ValueProviders
{
    [DisplayName("Get Blackboard Value")]
    [Description("Retrieves a string from the Blackboard")]
    [Category(FeatureComponentCategories.General)]
    public class GetBlackboardValue : ValueProvider
    {

        public string Key { get; set; }

        public override object Evaluate()
        {
            return (BlackboardManager.Current.Get(Key));
        }
    }
}
