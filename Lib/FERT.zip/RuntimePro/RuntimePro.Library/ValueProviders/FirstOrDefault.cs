﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features;
using System.ComponentModel.Composition;
using System.ComponentModel;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.ValueProviders
{
	[DisplayName("First or Default")]
	[Description("Selects the first or default value from an enumeration")]
	public class FirstOrDefault : ValueProvider
	{
		public IEnumerable<object> Elements { get; set; }

		public override object Evaluate()
		{
			if (Elements == null)
				return null;

			return Elements.FirstOrDefault();
		}
	}
}
