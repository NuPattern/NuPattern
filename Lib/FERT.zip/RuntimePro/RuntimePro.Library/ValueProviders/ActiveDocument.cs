﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.ComponentModel;
using Microsoft.VisualStudio.Modeling.Diagrams.ExtensionEnablement;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.ValueProviders
{
	[DisplayName("Active Document")]
    [Description("Provides the full path of the active document in Visual Studio")]
    [Category(FeatureComponentCategories.Ide)]
    public class ActiveDocument : ValueProvider
	{
        [Import(typeof(SVsServiceProvider))]
        public SVsServiceProvider ServiceProvider { get; set; }

		public override object Evaluate()
		{
			var vs = this.ServiceProvider.GetService(typeof(EnvDTE.DTE)) as EnvDTE.DTE;

			return vs.ActiveDocument != null ? vs.ActiveDocument.FullName : null;
		}
	}
}
