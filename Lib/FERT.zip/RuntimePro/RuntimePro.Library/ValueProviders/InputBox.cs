﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.ComponentModel;
using Microsoft.VisualStudio.Modeling.Diagrams.ExtensionEnablement;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualBasic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.ValueProviders
{
    [DisplayName("Input Box")]
    [Description("Prompts the user for a string value")]
    [Category(FeatureComponentCategories.Ide)]
    public class InputBox : ValueProvider
    {

        public string Title { get; set; }
        public string Message { get; set; }
        public string DefaultValue { get; set; }

        public override object Evaluate()
        {
            return (Interaction.InputBox(Message, 
                                         Title, 
                                         string.IsNullOrEmpty(DefaultValue)? "": DefaultValue));
        }
    }
}
