﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.ComponentModel;
using Microsoft.VisualStudio.Modeling.Diagrams.ExtensionEnablement;
using Microsoft.VisualStudio.Modeling.Diagrams;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualBasic;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.ValueProviders
{
    [DisplayName("Get Blackboard Instance Value")]
    [Description("Returns a value from the Blackboard under the specified Key prepended with the owning features instance name and a period (e.g. Feature1.Key)")]
    [Category(FeatureComponentCategories.General)]
    public class GetBlackboardInstanceValue : ValueProvider
    {

        [Import(AllowDefault = true)]
        public IFeatureExtension Feature { get; set; }

        public string Key { get; set; }

        public override object Evaluate()
        {
            return (BlackboardManager.Current.Get(Feature.InstanceName + "." + Key));
        }
    }
}
