﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Library.ValueProviders
{
	[DisplayName("First Solution Element Match")]
	[Description("Selects the first element in the current solution that matches the path expression.")]
    [Category(FeatureComponentCategories.Ide)]
    public class FirstSolutionElementMatch : ValueProvider
	{
		[Import]
		public ISolution Solution { get; set; }

		[Required]
		[DisplayName("Path Expression")]
		[Description("An expression that can contain wildcards and path specification, such as 'Solution Items\\*.txt'")]
		public string PathExpression { get; set; }

		public override object Evaluate()
		{
			return Solution.Find(PathExpression).FirstOrDefault();
		}
	}
}
