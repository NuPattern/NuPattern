﻿namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public interface IGuidanceWindowsService
	{
		object ShowGuidanceExplorer();
		object ShowGuidanceBrowser();
	}
}