﻿using System;
using System.Diagnostics;
using System.IO;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	///  Manages the output of feature trace messages to the 
	///  VS output window.
	/// </summary>
	public class FeatureOutputWindowManager : IDisposable
	{
		IServiceProvider serviceProvider;
        Guid traceOutputGuid = new Guid("{00A0641B-9B33-4809-9C27-DA3089031F70}");
		IVsOutputWindowPane outputWindowPane;
		TraceListener listener;
		StringWriter temporaryWriter;

		ShellEvents shellEvents;

		public FeatureOutputWindowManager(IServiceProvider serviceProvider)
		{
			Guard.NotNull(() => serviceProvider, serviceProvider);

			this.serviceProvider = serviceProvider;
			this.shellEvents = new ShellEvents(serviceProvider);

			this.shellEvents.ShellInitialized += OnShellInitialized;

			// Create a temporary writer that buffers events that happen 
			// before shell initialization is completed, so that we don't 
			// miss anything.
			temporaryWriter = new StringWriter();
			listener = new TraceRecordTextListener(temporaryWriter, Resources.TraceOutputWindowTitle);
			listener.IndentLevel = 4;
			listener.Filter = new DelegateTraceFilter((cache, source, eventType, id)
				=> eventType != TraceEventType.Transfer);

			Tracer.AddListener("*", listener);
		}

		public void Dispose()
		{
			this.shellEvents.Dispose();
		}

		private void OnShellInitialized(object sender, EventArgs args)
		{
			EnsureOutputWindow();

			// Replace temporary listener with the proper one, populating the 
			// output window from the temporary buffer.
			outputWindowPane.OutputStringThreadSafe(temporaryWriter.ToString());
			temporaryWriter = null;
			Tracer.RemoveListener("*", listener);
			listener = new TraceRecordTextListener(new OutputWindowTextWriter(outputWindowPane), Resources.TraceOutputWindowTitle);
			listener.IndentLevel = 4;
			listener.Filter = new DelegateTraceFilter((cache, source, eventType, id)
				=> eventType != TraceEventType.Transfer);

			Tracer.AddListener("*", listener);
		}

		private void EnsureOutputWindow()
		{
			if (outputWindowPane == null)
			{
				var outputWindow = (IVsOutputWindow)serviceProvider.GetService(typeof(SVsOutputWindow));
				ErrorHandler.ThrowOnFailure(outputWindow.CreatePane(ref traceOutputGuid, Resources.TraceOutputWindowTitle, 1, 1));
				ErrorHandler.ThrowOnFailure(outputWindow.GetPane(ref traceOutputGuid, out outputWindowPane));
			}
		}
	}
}
