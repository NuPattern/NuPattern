﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.IO;
using System.Drawing;
using Microsoft.VisualStudio.ExtensionManager;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	internal class FeatureRegistration : IFeatureRegistration
	{
		public string FeatureId { get; set; }
		public string DefaultName { get; set; }
		public string InstallPath { get; set; }
		public Icon Icon { get; set; }
		public Bitmap PreviewImage { get; set; }
		public IInstalledExtension InstalledExtension { get; set; }
		public IExtension ExtensionManifest { get; set; }
		public IEnumerable<IVsTemplate> Templates
		{
			get { throw new NotImplementedException("Not implemented yet"); }
		}
	}
}