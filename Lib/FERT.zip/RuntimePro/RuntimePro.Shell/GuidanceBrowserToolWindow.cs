﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Tool window for the guidance workflow.
	/// </summary>
	[Guid("85FB4A3F-1D68-47C9-809E-3D6E5F48DF44")]
	public class GuidanceBrowserToolWindowProXX : ToolWindowPane
	{
		private FrameworkElement control;

		/// <summary>
		/// Standard constructor for the tool window.
		/// </summary>
		public GuidanceBrowserToolWindowProXX() :
			base(null)
		{
			this.Caption = Resources.GuidanceBrowserToolWindowTitle;
			// Set the image that will appear on the tab of the window frame
			// when docked with an other window
			// The resource ID correspond to the one defined in the resx file
			// while the Index is the offset in the bitmap strip. Each image in
			// the strip being 16x16.
			this.BitmapResourceID = 302;
			this.BitmapIndex = 0;
			this.control = new GuidanceBrowserView();
		}

		/// <summary>
		/// Gets the control that should be hosted in the Tool Window.
		/// </summary>
		/// <value>the control that should be hosted in the Tool Window.</value>
		public override object Content
		{
			get { return this.control; }
		}

		internal GuidanceBrowserViewModel DataContext { get; private set; }

		/// <summary>
		/// Initializes services after the window pane has been sited.
		/// </summary>
		protected override void Initialize()
		{
			base.Initialize();

			this.DataContext = new GuidanceBrowserViewModel(this.GetService<IFeatureManager>(), this.GetService<IFxrUriReferenceService>());
			this.control.DataContext = this.DataContext;
		}
	}
}