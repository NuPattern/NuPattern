﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	internal static class BitmapHelper
	{
		internal static Bitmap Load(string path, string filename)
		{
			try
			{
				if (!string.IsNullOrEmpty(filename))
				{
					var fullPath = Path.Combine(path, filename);

					if (File.Exists(fullPath))
					{
						return new Bitmap(Bitmap.FromFile(fullPath));
					}
				}

				return null;
			}
			catch
			{
				return null;
			}
		}

		internal static Icon ToIcon(this Bitmap bitmap)
		{
			try
			{
				if (bitmap != null)
				{
					return Icon.FromHandle(bitmap.GetHicon());
				}
			}
			catch
			{
				return null;
			}

			return null;
		}

	}
}
