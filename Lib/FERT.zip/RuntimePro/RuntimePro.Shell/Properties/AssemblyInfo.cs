﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.ExtensibilityHosting;
using Microsoft.VisualStudio.TeamArchitect.PowerTools;

[assembly: AssemblyTitle("Feature Extensions Runtime Pro Shell Integration")]
[assembly: AssemblyProduct("Feature Extensions Runtime Pro Shell Integration")]

[assembly: ComVisible(false)]

[assembly: VsCatalogName(Constants.CatalogName)]
[assembly: VsCatalogName("Microsoft.VisualStudio.Default")]
