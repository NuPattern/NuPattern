﻿using System;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
    internal static class ShellConstants
    {
        // public const string FeatureExtension = ".feature";
        public const string PackageGuid = "47B786E9-53BE-4510-8D7E-952E02B6F87E";
        public const string ShellPackageCommandSetGuid = "E89060FD-F4DB-42CA-AC0C-2BDE40F7AC5B";

        public const int GuidanceWorkflowToolCommandId = 0x101;
        public const int GuidanceBrowserToolCommandId = 0x102;

        public static readonly Guid ShellPackageCommandSet = new Guid(ShellPackageCommandSetGuid);
    }
}