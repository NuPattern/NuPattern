﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using System.IO;
using System.Drawing;
using Microsoft.VisualStudio.ExtensionManager;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// This adapter is needed to isolate the <see cref="IFeatureManager"/> implementation 
	/// from the details of how to get a new instance of a registered feature from 
	/// the MEF container. Features have a creation policy of non-shared, meaning 
	/// every time you get a new export of the <see cref="IFeatureExtension"/> 
	/// you get a new instance created. However, you need to get the export 
	/// from the container in order to get the new instance. Instead of 
	/// passing the container itself around, we pass a func that calls back 
	/// into the container, so the only component aware of the container 
	/// is this adapter.
	/// </summary>
	internal class FeatureRegistrationAdapter
	{
		static readonly ITraceSource tracer = Tracer.GetSourceFor<FeatureRegistrationAdapter>();
		const string ManifestFilename = "extension.vsixmanifest";

        [Import(typeof(SVsServiceProvider))]
        public SVsServiceProvider ServiceProvider { get; set; }

		/// <summary>
		/// Exposes the registrations that can be used to instantiate features.
		/// Consumed by the <see cref="IFeatureManager"/>.
		/// </summary>
		[Export]
		public IEnumerable<IFeatureRegistration> RegisteredFeatures
		{
			get
			{
				if (ExportedFeatures == null)
				{
					yield break;
				}
				else
				{
					var extensionManager = this.ServiceProvider.GetService(typeof(SVsExtensionManager)) as IVsExtensionManager;
					if (extensionManager == null)
					{
						tracer.TraceError("Extension Manager service not available. Cannot load registered features.");
						yield break;
					}

					foreach (var export in this.ExportedFeatures)
					{
						var registration = new FeatureRegistration();

						// We need to create the feature to determine where the VSXI manifest is located.
						// We should find a way to locate the manifest without creating an instance of the feature.
						// Note: feature manager, and therefore this adapter, would live in the global VS container, 
						// not our custom containers.
						registration.FeatureId = export.Metadata.FeatureId;
						var feature = CreateFeature(registration);
						var featureManifestFilename = Path.Combine(Path.GetDirectoryName(feature.GetType().Assembly.Location), ManifestFilename);

						if (File.Exists(featureManifestFilename))
						{
							var extension = extensionManager.CreateExtension(featureManifestFilename);

							// The feature id metadata value is used both as part 
							// of the export definition as well as the assembly-level 
							// attribute to group components from multiple projects 
							// into a single feature.
							// We need the ID to be part of the metadata as it's 
							// the only way we have of relocating the export 
							// for a given feature Id (unless we find a way 
							// to query directly the catalog for the export definition 
							// but then we'd need to expose either an aggregate catalog 
							// or something.

							// Verify that both IDs match and issue a warning if they don't.
							if (export.Metadata.FeatureId != extension.Header.Identifier)
							{
								tracer.TraceWarning("Feature metadata attribute specifies idenfitier '{0}' but feature vsix manifest specifies '{1}'.\nThe two values must match. Skipping feature registration. Please contact feature author.",
									export.Metadata.FeatureId, extension.Header.Identifier);
								continue;
							}

							registration.FeatureId = extension.Header.Identifier;
							registration.DefaultName = export.Metadata.DefaultName;

							var installedExtension = extensionManager.GetInstalledExtension(extension.Header.Identifier);

							registration.ExtensionManifest = extension;
							registration.InstalledExtension = installedExtension;
							registration.InstallPath = installedExtension.InstallPath;
							registration.PreviewImage = BitmapHelper.Load(registration.InstallPath, extension.Header.PreviewImage);
							registration.Icon = BitmapHelper.Load(registration.InstallPath, extension.Header.Icon).ToIcon();
						}
						else
						{
							tracer.TraceWarning("Could not locate vsix manifest file from location inferred from the exported feature assembly location: {0}.\nSkipping feature type with identifier {1}.", 
								featureManifestFilename, export.Metadata.FeatureId);
							continue;
						}

						yield return registration;
					}
				}
			}
		}

		/// <summary>
		/// Exposes the factory of features
		/// </summary>
		/// <param name="registration"></param>
		/// <returns></returns>
		[Export(typeof(Func<IFeatureRegistration, IFeatureExtension>))]
		public IFeatureExtension CreateFeature(IFeatureRegistration registration)
		{
			// We re-retrieve the export rather than caching the one 
			// we got from ExportedFeatures as we need to 
			// lazily re-evaluate the export as it's a non-shared 
			// component that needs to be re-created every time.
			// If we cache the export, we're basically caching the 
			// lazy instance for *one* particular instantiation. 				
			return FeaturesGlobalContainer.Instance
				.GetExports<IFeatureExtension, IFeatureMetadata>()
				.First(e => e.Metadata.FeatureId == registration.FeatureId)
				.Value;
		}

		/// <summary>
		/// Imports the exported features that are installed. Used to build 
		/// the <see cref="RegisteredFeatures"/>.
		/// </summary>
		/// <remarks>
		/// Imported features must have a <see cref="CreationPolicy.NonShared"/> 
		/// policy applied, otherwise, they are ignored.
		/// </remarks>
		[ImportMany(RequiredCreationPolicy = CreationPolicy.NonShared)]
		public IEnumerable<Lazy<IFeatureExtension, IFeatureMetadata>> ExportedFeatures { get; set; }
	}
}