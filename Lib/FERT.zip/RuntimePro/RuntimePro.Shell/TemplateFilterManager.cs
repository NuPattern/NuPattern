﻿using System;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	internal class TemplateFilterManager : IDisposable
	{
		private IServiceProvider serviceProvider;
		private IVsRegisterNewDialogFilters filterService;
		private uint itemsFilterCookie;
		private uint projectsFilterCookie;

		public TemplateFilterManager(IServiceProvider serviceProvider, FeatureTemplateFilter filter)
		{
			Guard.NotNull(() => serviceProvider, serviceProvider);
			Guard.NotNull(() => filter, filter);

			this.serviceProvider = serviceProvider;

			this.filterService = (IVsRegisterNewDialogFilters)serviceProvider.GetService(typeof(SVsRegisterNewDialogFilters));
			ErrorHandler.ThrowOnFailure(this.filterService.RegisterAddNewItemDialogFilter(filter, out itemsFilterCookie));
			ErrorHandler.ThrowOnFailure(this.filterService.RegisterNewProjectDialogFilter(filter, out projectsFilterCookie));
		}

		public void Dispose()
		{
			if (this.itemsFilterCookie != 0)
			{
				filterService.UnregisterAddNewItemDialogFilter(this.itemsFilterCookie);
				this.itemsFilterCookie = 0;
			}

			if (this.projectsFilterCookie != 0)
			{
				filterService.UnregisterNewProjectDialogFilter(this.projectsFilterCookie);
				this.projectsFilterCookie = 0;
			}
		}
	}
}