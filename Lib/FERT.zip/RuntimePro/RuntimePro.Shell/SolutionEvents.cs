﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using EnvDTE;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class HierarchyEventArgs : EventArgs
	{
		public HierarchyEventArgs(IVsHierarchy hierarchy)
		{
			this.Hierarchy = hierarchy;
		}

		public IVsHierarchy Hierarchy { get; private set; }
	}

	public class SolutionEvents : IDisposable, IVsSolutionEvents, IVsSolutionEvents3
	{
		public event EventHandler SolutionOpened = (sender, args) => { };
		public event EventHandler SolutionClosed = (sender, args) => { };
		public event EventHandler<HierarchyEventArgs> ProjectOpened = (sender, args) => { };

		IVsSolution vsSolution;
		ISolution solution;
		IServiceProvider serviceProvider;
		IFeatureManager featureManager;
		uint cookie;
		bool isDisposed;
		bool isSolutionOpen;

		public SolutionEvents(IServiceProvider serviceProvider, IFeatureManager featureManager)
		{
			Guard.NotNull(() => serviceProvider, serviceProvider);
			Guard.NotNull(() => featureManager, featureManager);

			this.serviceProvider = serviceProvider;
			this.solution = new VsIde.VsSolution(serviceProvider);
			this.isSolutionOpen = this.solution.IsOpen;
			this.featureManager = featureManager;

			this.featureManager.IsOpenedChanged += OnFeatureManagerIsOpenedChanged;

			this.vsSolution = (IVsSolution)serviceProvider.GetService(typeof(SVsSolution));
			ErrorHandler.ThrowOnFailure(vsSolution.AdviseSolutionEvents(this, out cookie));
		}

		public void Dispose()
		{
			if (isDisposed) return;

			var solution = (IVsSolution)serviceProvider.GetService(typeof(SVsSolution));
			if (solution != null)
				ErrorHandler.ThrowOnFailure(solution.UnadviseSolutionEvents(cookie));

			isDisposed = true;
		}

		void OnFeatureManagerIsOpenedChanged(object sender, EventArgs e)
		{
			if (this.featureManager.IsOpened && !isSolutionOpen)
			{
				// Solution was opened by the manager. Raise event.
				isSolutionOpen = true;
				SolutionOpened(this, EventArgs.Empty);
			}
		}

		int IVsSolutionEvents.OnAfterCloseSolution(object pUnkReserved)
		{
			if (isSolutionOpen)
			{
				isSolutionOpen = false;
				SolutionClosed(this, EventArgs.Empty);
			}

			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnAfterLoadProject(IVsHierarchy pStubHierarchy, IVsHierarchy pRealHierarchy)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnAfterOpenProject(IVsHierarchy pHierarchy, int fAdded)
		{
			ProjectOpened(this, new HierarchyEventArgs(pHierarchy));
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnAfterOpenSolution(object pUnkReserved, int fNewSolution)
		{
			if (!isSolutionOpen)
			{
				// If solution wasn't open already, that is, the feature manager 
				// didn't open before, do it now.
				isSolutionOpen = true;
				SolutionOpened(this, EventArgs.Empty);
			}

			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnBeforeCloseProject(IVsHierarchy pHierarchy, int fRemoved)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnBeforeCloseSolution(object pUnkReserved)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnBeforeUnloadProject(IVsHierarchy pRealHierarchy, IVsHierarchy pStubHierarchy)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnQueryCloseProject(IVsHierarchy pHierarchy, int fRemoving, ref int pfCancel)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnQueryCloseSolution(object pUnkReserved, ref int pfCancel)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents.OnQueryUnloadProject(IVsHierarchy pRealHierarchy, ref int pfCancel)
		{
			return VSConstants.S_OK;
		}

		#region Unused

		int IVsSolutionEvents3.OnAfterCloseSolution(object pUnkReserved)
		{
			return ((IVsSolutionEvents)this).OnAfterCloseSolution(pUnkReserved);
		}

		int IVsSolutionEvents3.OnAfterClosingChildren(IVsHierarchy pHierarchy)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents3.OnAfterLoadProject(IVsHierarchy pStubHierarchy, IVsHierarchy pRealHierarchy)
		{
			return ((IVsSolutionEvents)this).OnAfterLoadProject(pStubHierarchy, pRealHierarchy);
		}

		int IVsSolutionEvents3.OnAfterMergeSolution(object pUnkReserved)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents3.OnAfterOpenProject(IVsHierarchy pHierarchy, int fAdded)
		{
			return ((IVsSolutionEvents)this).OnAfterOpenProject(pHierarchy, fAdded);
		}

		int IVsSolutionEvents3.OnAfterOpenSolution(object pUnkReserved, int fNewSolution)
		{
			return ((IVsSolutionEvents)this).OnAfterOpenSolution(pUnkReserved, fNewSolution);			
		}

		int IVsSolutionEvents3.OnAfterOpeningChildren(IVsHierarchy pHierarchy)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents3.OnBeforeCloseProject(IVsHierarchy pHierarchy, int fRemoved)
		{
			return ((IVsSolutionEvents)this).OnBeforeCloseProject(pHierarchy, fRemoved);
		}

		int IVsSolutionEvents3.OnBeforeCloseSolution(object pUnkReserved)
		{
			return ((IVsSolutionEvents)this).OnBeforeCloseSolution(pUnkReserved);
		}

		int IVsSolutionEvents3.OnBeforeClosingChildren(IVsHierarchy pHierarchy)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents3.OnBeforeOpeningChildren(IVsHierarchy pHierarchy)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents3.OnBeforeUnloadProject(IVsHierarchy pRealHierarchy, IVsHierarchy pStubHierarchy)
		{
			return ((IVsSolutionEvents)this).OnBeforeUnloadProject(pRealHierarchy, pStubHierarchy);
		}

		int IVsSolutionEvents3.OnQueryCloseProject(IVsHierarchy pHierarchy, int fRemoving, ref int pfCancel)
		{
			return ((IVsSolutionEvents)this).OnQueryCloseProject(pHierarchy, fRemoving, pfCancel);
		}

		int IVsSolutionEvents3.OnQueryCloseSolution(object pUnkReserved, ref int pfCancel)
		{
			return ((IVsSolutionEvents)this).OnQueryCloseSolution(pUnkReserved, pfCancel);
		}

		int IVsSolutionEvents3.OnQueryUnloadProject(IVsHierarchy pRealHierarchy, ref int pfCancel)
		{
			return ((IVsSolutionEvents)this).OnQueryUnloadProject(pRealHierarchy, pfCancel);
		}

		int IVsSolutionEvents2.OnAfterCloseSolution(object pUnkReserved)
		{
			return ((IVsSolutionEvents)this).OnAfterCloseSolution(pUnkReserved);
		}

		int IVsSolutionEvents2.OnAfterLoadProject(IVsHierarchy pStubHierarchy, IVsHierarchy pRealHierarchy)
		{
			return ((IVsSolutionEvents)this).OnAfterLoadProject(pStubHierarchy, pRealHierarchy);
		}

		int IVsSolutionEvents2.OnAfterMergeSolution(object pUnkReserved)
		{
			return VSConstants.S_OK;
		}

		int IVsSolutionEvents2.OnAfterOpenProject(IVsHierarchy pHierarchy, int fAdded)
		{
			return ((IVsSolutionEvents)this).OnAfterOpenProject(pHierarchy, fAdded);
		}

		int IVsSolutionEvents2.OnAfterOpenSolution(object pUnkReserved, int fNewSolution)
		{
			return ((IVsSolutionEvents)this).OnAfterOpenSolution(pUnkReserved, fNewSolution);
		}

		int IVsSolutionEvents2.OnBeforeCloseProject(IVsHierarchy pHierarchy, int fRemoved)
		{
			return ((IVsSolutionEvents)this).OnBeforeCloseProject(pHierarchy, fRemoved);
		}

		int IVsSolutionEvents2.OnBeforeCloseSolution(object pUnkReserved)
		{
			return ((IVsSolutionEvents)this).OnBeforeCloseSolution(pUnkReserved);
		}

		int IVsSolutionEvents2.OnBeforeUnloadProject(IVsHierarchy pRealHierarchy, IVsHierarchy pStubHierarchy)
		{
			return ((IVsSolutionEvents)this).OnBeforeUnloadProject(pRealHierarchy, pStubHierarchy);
		}

		int IVsSolutionEvents2.OnQueryCloseProject(IVsHierarchy pHierarchy, int fRemoving, ref int pfCancel)
		{
			return ((IVsSolutionEvents)this).OnQueryCloseProject(pHierarchy, fRemoving, pfCancel);
		}

		int IVsSolutionEvents2.OnQueryCloseSolution(object pUnkReserved, ref int pfCancel)
		{
			return ((IVsSolutionEvents)this).OnQueryCloseSolution(pUnkReserved, pfCancel);
		}

		int IVsSolutionEvents2.OnQueryUnloadProject(IVsHierarchy pRealHierarchy, ref int pfCancel)
		{
			return ((IVsSolutionEvents)this).OnQueryUnloadProject(pRealHierarchy, pfCancel);
		}

		#endregion
	}
}