﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using System.Diagnostics;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using System.IO;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	///  Manages the output of feature trace messages to the 
	///  VS output window.
	/// </summary>
	public class FeatureXmlOutputManager : IDisposable
	{
		ISolution solution;
		EnvDTE.DTE dte;
		TraceListener listener;
		SolutionEvents solutionEvents;
		IFeatureManager featureManager;

		public FeatureXmlOutputManager(IServiceProvider serviceProvider, IFeatureManager featureManager)
		{
			Guard.NotNull(() => serviceProvider, serviceProvider);
			Guard.NotNull(() => featureManager, featureManager);

			this.solution = new VsSolution(serviceProvider);
			this.solutionEvents = new SolutionEvents(serviceProvider, featureManager);
			this.featureManager = featureManager;
			this.dte = (EnvDTE.DTE)serviceProvider.GetService(typeof(EnvDTE.DTE));

			this.solutionEvents.ProjectOpened += OnProjectOpened;
			this.solutionEvents.SolutionOpened += OnSolutionOpened;
			this.solutionEvents.SolutionClosed += OnSolutionClosed;
		}

		public void Dispose()
		{
			this.solutionEvents.Dispose();
		}

		// Whichever happens first.
		private void OnProjectOpened(object sender, HierarchyEventArgs e)
		{
			if (listener == null)
				InitializeListener();
		}

		private void OnSolutionOpened(object sender, EventArgs args)
		{
			if (listener == null)
				InitializeListener();
		}

		private void InitializeListener()
		{
            string traceFile;

            if (solution.PhysicalPath == null)
            {
                traceFile = Path.Combine(
                "c:\\",
                "Features.svclog");
            }
            else
            {
                traceFile = Path.Combine(
                Path.GetDirectoryName(solution.PhysicalPath),
                "Features.svclog");
                }
			CheckOutIfNeeded(traceFile);

			listener = new TraceRecordXmlListener(traceFile, "Features");
			listener.TraceOutputOptions = TraceOptions.Timestamp | TraceOptions.LogicalOperationStack | TraceOptions.ThreadId;
			listener.Filter = new EventTypeFilter(
				SourceLevels.ActivityTracing |
				SourceLevels.Critical |
				SourceLevels.Error |
				SourceLevels.Information |
				SourceLevels.Warning);

			Tracer.AddListener("*", listener);
		}

		private void OnSolutionClosed(object sender, EventArgs e)
		{
			// Yes, VS can call close without ever calling open, this 
			// happens when the "invisible" solution is "opened" (i.e. 
			// VS just opened and doesn't have a solution yet).
			if (listener != null)
			{
				Tracer.RemoveListener("*", listener);
				listener.Flush();
				listener.Close();
				listener = null;
			}
		}

		private void CheckOutIfNeeded(string fileName)
		{
			if (File.Exists(fileName))
			{
				if (dte.SourceControl != null &&
					dte.SourceControl.IsItemUnderSCC(fileName) &&
					!dte.SourceControl.IsItemCheckedOut(fileName))
				{
					dte.SourceControl.CheckOutItem(fileName);
				}
				else
				{
					File.SetAttributes(fileName, FileAttributes.Normal);
				}
			}
		}
	}
}
