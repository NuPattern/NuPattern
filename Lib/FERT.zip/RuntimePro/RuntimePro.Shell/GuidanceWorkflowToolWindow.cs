﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;
using Microsoft.VisualStudio.Shell.Interop;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Tool window for the guidance workflow.
	/// </summary>
	[Guid("71A61EB1-B9A0-4C7E-9D5C-9AE9AF5DC0D3")]
	public class GuidanceWorkflowToolWindowProXX : ToolWindowPane
	{
		private FrameworkElement control;
		private GuidanceWorkflowMediator workflowMediator;

		/// <summary>
		/// Standard constructor for the tool window.
		/// </summary>
		public GuidanceWorkflowToolWindowProXX() :
			base(null)
		{
			this.Caption = Resources.GuidanceWorkflowToolWindowTitle;
			// Set the image that will appear on the tab of the window frame
			// when docked with an other window
			// The resource ID correspond to the one defined in the resx file
			// while the Index is the offset in the bitmap strip. Each image in
			// the strip being 16x16.
			this.BitmapResourceID = 301;
			this.BitmapIndex = 0;
			this.control = new GuidanceWorkflowPanelView();
		}

		/// <summary>
		/// Gets the control that should be hosted in the Tool Window.
		/// </summary>
		/// <value>the control that should be hosted in the Tool Window.</value>
		public override object Content
		{
			get { return this.control; }
		}

		internal GuidanceWorkflowPanelViewModel DataContext { get; private set; }

		protected override void Initialize()
		{
			base.Initialize();

			this.DataContext = new GuidanceWorkflowPanelViewModel(this.GetService<IFeatureManager>());
			this.control.DataContext = this.DataContext;

			this.workflowMediator = new GuidanceWorkflowMediator(this.DataContext);
		}

		//private void OnCurrentNodeChanged(object sender, EventArgs e)
		//{
		//    var trackSelection = (IVsTrackSelectionEx)this.GetService(typeof(SVsTrackSelectionEx));
		//    if (trackSelection != null)
		//    {
		//        var selectedObjects = new List<NodeViewModel> { this.viewModel.CurrentNode };
		//        this.selectionContainer.SelectedObjects = selectedObjects;
		//        this.selectionContainer.SelectableObjects = selectedObjects;
		//        trackSelection.OnSelectChange((ISelectionContainer)selectionContainer);
		//    }
		//}
	}
}