﻿using System;
using System.ComponentModel.Composition;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;
using Microsoft.FeatureExtensionToolWindows;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	internal class GuidanceWorkflowMediator
	{
		private GuidanceWorkflowPanelViewModel workflowPanelViewModel;
		private IGuidanceToolWindow browserToolWindow;
	    private ToolWindowPane browserToolWindowPane;

		internal GuidanceWorkflowMediator(GuidanceWorkflowPanelViewModel workflowPanelViewModel)
		{
			FeatureCompositionService.Instance.SatisfyImportsOnce(this);
			this.workflowPanelViewModel = workflowPanelViewModel;
			this.workflowPanelViewModel.CurrentNodeChanged += this.OnCurrentNodeChanged;
		}

		[Import(typeof(SVsServiceProvider))]
		private SVsServiceProvider ServiceProvider { get; set; }

		private IGuidanceToolWindow GetBrowserTool()
		{
			if (this.browserToolWindow == null)
			{
				var guidanceWindowsService = this.ServiceProvider.GetService<IGuidanceWindowsService>();
				if (guidanceWindowsService != null)
				{
					this.browserToolWindow = (IGuidanceToolWindow) guidanceWindowsService.ShowGuidanceBrowser();
				    this.browserToolWindowPane = this.browserToolWindow.WindowPane;
				}
			}

			var frame = (IVsWindowFrame)this.browserToolWindowPane.Frame;
			int onScreen;
			frame.IsOnScreen(out onScreen);
			if (onScreen == 0)
			{
				frame.Show();
			}
			else
			{
				frame.ShowNoActivate();
			}

			return this.browserToolWindow;
		}

		private void OnCurrentNodeChanged(object sender, NodeChangedEventArgs e)
		{
			var guidanceBrowserToolWindow = this.GetBrowserTool();
			((GuidanceBrowserViewModel)guidanceBrowserToolWindow.DataContext).Node = e.CurrentNode;
		}
	}
}