using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.ComponentModelHost;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Properties;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.VsIde;
using System.Globalization;
using System.IO;
using EnvDTE;
using Microsoft.FeatureExtensionToolWindows;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
    [PackageRegistration(UseManagedResourcesOnly = true)]
    [Guid(ShellConstants.PackageGuid)]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    //[ProvideToolWindow(typeof(GuidanceWorkflowToolWindowPro), Style = VsDockStyle.Tabbed, Window = EnvDTE.Constants.vsWindowKindToolbox)] 
    //[ProvideToolWindow(typeof(GuidanceBrowserToolWindowPro), Style = VsDockStyle.Tabbed, Window = EnvDTE.Constants.vsWindowKindOutput)] 
    [ProvideService(typeof(IFeatureManager), ServiceName = "FeatureManager")]
    [ProvideService(typeof(IFeatureCompositionService), ServiceName = "FeatureCompositionService")]
    [ProvideService(typeof(IGuidanceWindowsService), ServiceName = "GuidanceWindows")]
    [ProvideAutoLoad(UIContextGuids.NoSolution)]



    public class ShellPackage : Package, IGuidanceWindowsService
    {
        private const int IdleTimeout = 5000;
        private const int GuidanceEvalTimeGovernor = 1; // In Seconds

        private static readonly ITraceSource tracer = Tracer.GetSourceFor<ShellPackage>();

        private SolutionEvents solutionEvents;
        private TemplateFilterManager filterManager;
        private FeatureXmlOutputManager xmlFileLoggingManager;
        private FeatureOutputWindowManager outputWindowLoggingManager;
        private VsIdleTaskHost idleTaskHost;
        private bool showWindows = false;

        [Import]
        public IFeatureManager FeatureManager { get; set; }

        [Import]
        public IFeatureCompositionService FeatureCompositionService { get; set; }

        [ImportMany(typeof(ILaunchPoint))]
        public IEnumerable<Lazy<ILaunchPoint>> LaunchPoints { get; set; }


        protected override void Initialize()
        {
            base.Initialize();

            // Features made load the editor before ours aasemblies are loaded
            AppDomain.CurrentDomain.AssemblyResolve += this.OnAssemblyResolve;

            try
            {
                // Doing this from the root VS container forces creation of the feature manager and associated 
                // components at the root container, and be reused from the extensibility pack.
                ((IComponentModel)this.GetService<SComponentModel>()).DefaultCompositionService.SatisfyImportsOnce(this);
            }
            catch (Exception ex)
            {
                Tracer.GetSourceFor<ShellPackage>().TraceError(ex, "Failed to satisfy imports");
                throw;
            }


            var serviceContainer = (IServiceContainer)this;
            serviceContainer.AddService(typeof(IFeatureManager), this.FeatureManager, true);
            serviceContainer.AddService(typeof(IFeatureCompositionService), this.FeatureCompositionService, true);
            serviceContainer.AddService(typeof(IGuidanceWindowsService), this, true);

            this.solutionEvents = new SolutionEvents(this, this.FeatureManager);
            this.solutionEvents.SolutionOpened += this.OnSolutionOpened;
            this.solutionEvents.SolutionClosed += this.OnSolutionClosed;

            this.RegisterFeatureTemplateFilter();
            this.RegisterGuidanceToolWindows();
            this.RegisterTraceManagers();

            // If initializing other packages launchpoints worked, 
            // they wouldn't need to do this themselves.
            this.RegisterRefreshGuidanceStates();
            FeatureManager.InstantiatedFeaturesChanged += this.OnInstantiatedFeaturesChanged;
            FeatureManager.ActiveFeatureChanged += this.OnActiveFeatureChanged;

            //
            // Check to see if we're running on an operating system older than Vista
            //
            string localAppData = System.Environment.GetEnvironmentVariable("LOCALAPPDATA");

            if (localAppData == null || localAppData == string.Empty)
            {
                IVsUIShell uiShell = (IVsUIShell)GetService(typeof(SVsUIShell));
                Guid clsid = Guid.Empty;
                int result;
                Microsoft.VisualStudio.ErrorHandler.ThrowOnFailure(uiShell.ShowMessageBox(
                           0,
                           ref clsid,
                           "Feature Builder Runtime",
                           string.Format(CultureInfo.CurrentCulture, "{0}", "The Environment variable LocalAppData must be manually configured for Windows XP and Windows Server 2003."),
                           string.Empty,
                           0,
                           OLEMSGBUTTON.OLEMSGBUTTON_OK,
                           OLEMSGDEFBUTTON.OLEMSGDEFBUTTON_FIRST,
                           OLEMSGICON.OLEMSGICON_CRITICAL,
                           0,        // false
                           out result));
            }
        }



        private void OnInstantiatedFeaturesChanged(object sender, EventArgs args)
        {
            this.showWindows = true;
        }

        private void OnActiveFeatureChanged(object sender, EventArgs args)
        {
            var activeFeature = FeatureManager.ActiveFeature;
            if (activeFeature != null && this.showWindows && activeFeature.GuidanceWorkflow != null)
            {
                var toolWindow = this.ShowGuidanceExplorer();
                this.ShowGuidanceBrowser();

                var toolWindowContext = toolWindow as IGuidanceToolWindow;
                this.showWindows = false;

                var workflowViewModel = ((GuidanceWorkflowPanelViewModel)toolWindowContext.DataContext).Workflows.FirstOrDefault(wfw => wfw.Model == activeFeature.GuidanceWorkflow);

                if (workflowViewModel != null)
                {
                    ((GuidanceWorkflowPanelViewModel)toolWindowContext.DataContext).CurrentWorkflow = workflowViewModel;

                    var focusedAction = activeFeature.GuidanceWorkflow.Successors
                        .Traverse(s => s.Successors)
                        .OfType<IGuidanceAction>()
                        .FirstOrDefault(action => !string.IsNullOrEmpty(action.Link));
                    if (focusedAction != null)
                    {
                        activeFeature.GuidanceWorkflow.Focus(focusedAction);
                        workflowViewModel.GoToFocusedAction();
                    }
                }
            }
        }

        private Assembly OnAssemblyResolve(object sender, ResolveEventArgs args)
        {
            return args.Name == typeof(IFeatureExtension).Assembly.FullName ? typeof(IFeatureExtension).Assembly : null;
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);

            if (disposing)
            {
                if (this.solutionEvents != null)
                    this.solutionEvents.Dispose();
                if (this.idleTaskHost != null)
                    this.idleTaskHost.Dispose();
                if (this.outputWindowLoggingManager != null)
                    this.outputWindowLoggingManager.Dispose();
                if (this.xmlFileLoggingManager != null)
                    this.xmlFileLoggingManager.Dispose();
                if (this.filterManager != null)
                    this.filterManager.Dispose();
            }
        }

        protected override int QueryClose(out bool canClose)
        {
            var result = base.QueryClose(out canClose);
            if (canClose)
                solutionEvents.Dispose();

            return result;
        }

        private void AddCommand<T>(OleMenuCommandService menuService, int toolCommandId) where T : ToolWindowPane
        {
            var toolWindowCommandId = new CommandID(ShellConstants.ShellPackageCommandSet, toolCommandId);
            menuService.AddCommand(new MenuCommand((s, e) => this.ShowToolWindow<T>(), toolWindowCommandId));
        }

        private void InitializeVsLaunchPoints()
        {
            var menuCommandService = this.GetService<IMenuCommandService>() as OleMenuCommandService;
            if (menuCommandService != null)
            {
                foreach (var launchPoint in this.LaunchPoints.Select(lp => lp.Value).OfType<VsLaunchPoint>())
                {
                    menuCommandService.AddCommand(launchPoint);
                }
            }
        }

        private void OnSolutionClosed(object sender, EventArgs e)
        {
            this.FeatureManager.Close();
        }

        private void OnSolutionOpened(object sender, EventArgs args)
        {
            if (!this.FeatureManager.IsOpened)
                this.FeatureManager.Open(new SolutionDataState(new VsSolution(this)));
        }

        private void RegisterFeatureTemplateFilter()
        {
            var filter = new FeatureTemplateFilter(
                new VsSolution(this),
                this.FeatureManager,
                this.LaunchPoints);

            this.filterManager = new TemplateFilterManager(this, filter);
        }

        private void RegisterGuidanceToolWindows()
        {
            // Add our command handlers for menu (commands must exist in the .vsct file)
            var menuCommandService = this.GetService<IMenuCommandService>() as OleMenuCommandService;
            if (menuCommandService != null)
            {
                // Create the commands for the tool window
                //this.AddCommand<GuidanceWorkflowToolWindowPro>(menuCommandService, ShellConstants.GuidanceWorkflowToolCommandId);
                //this.AddCommand<GuidanceBrowserToolWindowPro>(menuCommandService, ShellConstants.GuidanceBrowserToolCommandId);
            }
        }

        private void RegisterRefreshGuidanceStates()
        {
            var conditionsEvaluator = new GuidanceConditionsEvaluator(this.FeatureManager);
            this.idleTaskHost = new VsIdleTaskHost(this, () => conditionsEvaluator.EvaluateGraphs(), TimeSpan.FromSeconds(GuidanceEvalTimeGovernor));
            this.idleTaskHost.Start(TimeSpan.FromMilliseconds(IdleTimeout));
        }

        private void RegisterTraceManagers()
        {
            string path = Path.Combine(Environment.ExpandEnvironmentVariables("%LocalAppData%"), @"Microsoft\VisualStudio\10.0\Extensions\Microsoft\Feature Extension Runtime\1.0\enablelogging.txt");
            if (System.IO.File.Exists(path))
            {
                this.xmlFileLoggingManager = new FeatureXmlOutputManager(this, this.FeatureManager);
            }
            this.outputWindowLoggingManager = new FeatureOutputWindowManager(this);
        }

        private T ShowToolWindow<T>() where T : ToolWindowPane
        {

            var toolWindow = this.FindToolWindow(typeof(T), 0, true) as T;
            if (toolWindow == null || toolWindow.Frame == null)
            {
                throw new NotSupportedException(Resources.CanNotCreateWindow);
            }

            var windowFrame = (IVsWindowFrame)toolWindow.Frame;
            ErrorHandler.ThrowOnFailure(windowFrame.Show());
            return toolWindow;
        }


        public object ShowGuidanceExplorer()
        {
            var service = ServiceProvider.GlobalProvider.GetService(typeof(IGuidanceWindowsService2));
            var fbToolWindowService = service as IGuidanceWindowsService2;
            var workflowDataContext = new GuidanceWorkflowPanelViewModel(
                this.GetService<IFeatureManager>());
            object toolWindow = fbToolWindowService.ShowGuidanceExplorer(new GuidanceWorkflowPanelView(),
                                                                         workflowDataContext,
                                                                         new GuidanceWorkflowMediator(workflowDataContext));
            return toolWindow;
        }

        public object ShowGuidanceBrowser()
        {
            var service = ServiceProvider.GlobalProvider.GetService(typeof(IGuidanceWindowsService2));
            var fbToolWindowService = service as IGuidanceWindowsService2;

            object toolWindow = fbToolWindowService.ShowGuidanceBrowser(new GuidanceBrowserView(),
                                                                        new GuidanceBrowserViewModel(this.GetService<IFeatureManager>(), this.GetService<IFxrUriReferenceService>()));
            return toolWindow;
        }
    }
}
