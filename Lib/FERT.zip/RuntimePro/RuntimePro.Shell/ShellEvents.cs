﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.Shell;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	public class ShellEvents : IVsShellPropertyEvents, IDisposable
	{
		private uint shellCookie;
		private IVsShell shellService;

		public event EventHandler ShellInitialized = (sender, args) => { };

		public ShellEvents(IServiceProvider serviceProvider)
		{
			Guard.NotNull(() => serviceProvider, serviceProvider);

			this.shellService = (IVsShell)serviceProvider.GetService(typeof(SVsShell));
			ErrorHandler.ThrowOnFailure(
				shellService.AdviseShellPropertyChanges(this, out shellCookie));
		}

		public void Dispose()
		{
		}

		public int OnShellPropertyChange(int propid, object var)
		{
			if (propid == (int)__VSSPROPID.VSSPROPID_Zombie)
			{
				if ((bool)var == false)
				{
					ErrorHandler.ThrowOnFailure(shellService.UnadviseShellPropertyChanges(this.shellCookie));
					this.shellCookie = 0;

					ShellInitialized(this, EventArgs.Empty);
				}
			}

			return VSConstants.S_OK;
		}
	}
}
