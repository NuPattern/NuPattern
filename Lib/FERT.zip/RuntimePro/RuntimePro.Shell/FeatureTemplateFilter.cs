﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.Modeling.ExtensionEnablement;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.Diagnostics;
using Microsoft.VisualStudio.TeamArchitect.PowerTools.Features.VsTemplateSchema;

namespace Microsoft.VisualStudio.TeamArchitect.PowerTools.Features
{
	/// <summary>
	/// Filters item templates based on the feature status
	/// </summary>
	internal class FeatureTemplateFilter : IVsFilterAddProjectItemDlg, IVsFilterNewProjectDlg
	{
		private static readonly ITraceSource tracer = Tracer.GetSourceFor<FeatureTemplateFilter>();

		private ISolution solution;
		private IFeatureManager featureManager;
		private IEnumerable<Lazy<ILaunchPoint>> launchPoints;

		public FeatureTemplateFilter(ISolution solution, IFeatureManager manager, IEnumerable<Lazy<ILaunchPoint>> launchPoints)
		{
			this.solution = solution;
			this.featureManager = manager;
			this.launchPoints = launchPoints;
		}

		// The .vstemplate patching behavior needs to also be available via the ITemplateService, 
		// otherwise we risk getting out of sync with what happens when you go via API 
		// instead of the Add New dialog.
		private bool IsTemplateAvailable(string templateFilename)
		{
			// Our templates will never be under the VS IDE path.
			// This is a cheap and quick optimization.
			if (templateFilename.StartsWith(AppDomain.CurrentDomain.BaseDirectory))
				return true;

			try
			{
				var registration = this.featureManager.FindFeature(templateFilename);

				// The template does not belong to a feature
				if (registration == null)
					return true;

				var template = VsTemplateFile.Read(templateFilename);

				if (VsTemplateFile.IsFeatureExtensionProject(template, registration))
				{
					template = ForceTemplateIdEqualsFeatureId(template, registration);

					// If template is the feature (modeling) state project, 
					// show as long as it doesn't have an explicit hide.
					return (template.TemplateData.Hidden != true);

					// Here's where we'd add selective feature instantiation 
					// depending on the context? Although filtering its instantiation 
					// template is not the entire story, as we'd also need to disable 
					// all other templates that can potentially instantiate the feature
					// that is, all those without a launchpoint.
				}

				var templateLaunchPoint = this.launchPoints.Find(template.TemplateData);
				if (templateLaunchPoint == null)
				{
					return true;
				}

				// Let the launchpoint decide how to check.
				return templateLaunchPoint.CanExecute(null);
			}
			catch
			{
				return true;
			}
		}

		private IVsTemplate ForceTemplateIdEqualsFeatureId(IVsTemplate template, IFeatureRegistration registration)
		{
			if (template.TemplateData.TemplateID != registration.FeatureId)
			{
				tracer.TraceWarning("Template ID {0} does not match feature ID {1}. Attempting to fix it. Please contact feature author.",
					template.TemplateData.TemplateID, registration.FeatureId);

				((VSTemplate)template).TemplateData.TemplateID = registration.FeatureId;
				VsTemplateFile.Write(template);
				return VsTemplateFile.Read(template.PhysicalPath);
			}

			return template;
		}

		public int FilterListItemByLocalizedName(string pszLocalizedName, out int pfFilter)
		{
			pfFilter = 0;

			return VSConstants.S_OK;
		}

		public int FilterListItemByTemplateFile(string pszTemplateFile, out int pfFilter)
		{
			pfFilter = IsTemplateAvailable(pszTemplateFile) ? 0 : 1;

			return VSConstants.S_OK;
		}

		public int FilterTreeItemByLocalizedName(string pszLocalizedName, out int pfFilter)
		{
			// Filter out our category.
			//pfFilter = pszLocalizedName == FeatureProjectFlavorFactory.FlavorName ? 1 : 0;
            pfFilter = 0;
			return VSConstants.S_OK;
		}

		public int FilterTreeItemByTemplateDir(string pszTemplateDir, out int pfFilter)
		{
			pfFilter = 0;

			return VSConstants.S_OK;
		}

		public int FilterListItemByLocalizedName(ref Guid rguidProjectItemTemplates, string pszLocalizedName, out int pfFilter)
		{
			pfFilter = 0;

			return VSConstants.S_OK;
		}

		public int FilterListItemByTemplateFile(ref Guid rguidProjectItemTemplates, string pszTemplateFile, out int pfFilter)
		{
			pfFilter = IsTemplateAvailable(pszTemplateFile) ? 0 : 1;

			return VSConstants.S_OK;
		}

		public int FilterTreeItemByLocalizedName(ref Guid rguidProjectItemTemplates, string pszLocalizedName, out int pfFilter)
		{
			pfFilter = 0;

			return VSConstants.S_OK;
		}

		public int FilterTreeItemByTemplateDir(ref Guid rguidProjectItemTemplates, string pszTemplateDir, out int pfFilter)
		{
			pfFilter = 0;

			return VSConstants.S_OK;
		}

		private class MenuCommand : IMenuCommand
		{
			public bool Enabled { get; set; }
			public string Text { get; set; }
			public bool Visible { get; set; }
		}
	}
}